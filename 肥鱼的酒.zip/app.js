(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const { World, BeatPulse, clamp } = window.DollPhysics;
  // Transparent foreground: the browser composites video underneath without copying it into Canvas.
  const canvas = $('wallpaper'), ctx = canvas.getContext('2d', { alpha: true });
  ctx.imageSmoothingEnabled = true;
  if ('imageSmoothingQuality' in ctx) ctx.imageSmoothingQuality = 'medium';
  const world = new World();
  const beatPulse = new BeatPulse();

  // 每个编号的娃娃可以挑选不同的形象。第一个形象是默认值，也是旧版单图素材路径。
  const DOLL_IMAGES = [
    { value: 'glm', label: 'GLM（灰狼女仆）', file: 'assets/doll-glm.png' },
    { value: 'deepseek', label: 'DeepSeek（鲸鱼娘）', file: 'assets/doll-deepseek.png' },
    { value: 'claude', label: 'Claude（橘发书娘）', file: 'assets/doll-claude.png' },
    { value: 'gemini', label: 'Gemini（星纹猫娘）', file: 'assets/doll-gemini.png' },
    { value: 'gpt', label: 'GPT（白龙娘）', file: 'assets/doll-gpt.png' },
    { value: 'grok', label: 'Grok（金发小恶魔）', file: 'assets/doll-grok.png' },
  ];
  const IMAGE_FILES = DOLL_IMAGES.map(image => image.file);
  const DEFAULT_IMAGE = DOLL_IMAGES[0].value;
  const pickImage = index => (DOLL_IMAGES[index] || DOLL_IMAGES[0]).value;
  // 内置背景视频（随壁纸一起分发，位于 assets 目录）。
  // WE web wallpapers require an open codec: VP8 + Vorbis in WebM, 1080p/30fps.
  const BACKGROUND_VIDEO_FILE = 'assets/background-video.webm';
  const BACKGROUND_VIDEO_LABEL = '默认视频 · 肥鱼最伟大的壁纸';
  // 内置默认音乐随 assets 目录一起分发，开箱即播，且只有这一份。
  // 默认音乐刻意用 MP3：WE 内置网页服务器对 .m4a 的 MIME 支持不保证，
  // 一旦 Content-Type 不对，CEF 里的 <audio> 会直接拒绝解码（表现为「没有音乐」）。
  // MP3 是 WE 各版本都稳的格式，实测换回 mp3 后宿主里恢复播放，别改回 m4a。
  const DEFAULT_MUSIC_FILE = 'assets/default-music.mp3';
  const DEFAULT_MUSIC_LABEL = '邦友的酒 DJ';

  const defaults = { count: 6, size: 180, speed: 85, strength: 0.15, collisions: true, musicenabled: true, musicvolume: 60,
    rotation: 1, stretch: 0.15, sensitivity: 1, throwforce: 1, decay: 3, draganimation: 1, stationary: false,
    spinmin: 0.45, spinmax: 1.35, beatboost: 0.8, collisionbox: 0.46, renderquality: 1,
    ...Object.fromEntries(Array.from({ length: 8 }, (_, i) => ['dollsize' + (i + 1), 0])),
    ...Object.fromEntries(Array.from({ length: 8 }, (_, i) => ['dollimage' + (i + 1), pickImage(i)])),
    ...Object.fromEntries(Array.from({ length: 8 }, (_, i) => ['dollfile' + (i + 1), ''])),
    backgroundcolor: '#ffffff', backgroundimage: '', backgroundfit: 'cover',
    // 默认用内置视频做背景并循环播放；视频关掉后回落到图片，再回落到纯色。
    backgroundmode: 'video', videoenabled: true, videoaudio: false, videofit: 'cover',
    // 视频画面放大与位置偏移：1 = 原始尺寸，>1 放大；位移按视口宽高的百分比（-100 ~ 100）。
    videoscale: 1, videox: 0, videoy: 0 };
  const ranges = { count: [1, 8], size: [100, 600], speed: [0, 200], strength: [0, 0.55], musicvolume: [0, 100],
    rotation: [0, 3], stretch: [0, 0.15], sensitivity: [0.5, 2], throwforce: [0, 3], decay: [0.5, 8], draganimation: [0.5, 2],
    spinmin: [0, 3], spinmax: [0, 3], beatboost: [0, 3], collisionbox: [0.15, 0.6],
    videoscale: [1, 3], videox: [-100, 100], videoy: [-100, 100] };
  const settings = { ...defaults };
  const host = typeof window.wallpaperRegisterAudioListener === 'function';
  const player = $('player');
  const sprites = new Map(), alphaCache = new Map();
  const customDolls = Array.from({ length: 8 }, () => ({ request: 0, image: null, source: '', ownedURL: null, label: '', error: '' }));
  // 娃娃形象值的解析结果缓存（value -> file）。draw() 每帧都查，避免线性扫 DOLL_IMAGES。
  const dollImageCache = new Map();
  let ready = false, frameId = 0, lastFrame = null, lastSimulation = null, frameAccumulator = 0, fps = 60, enginePaused = false, userPaused = false;
  let measureAt = null, renderedFrames = 0;
  let audioLevel = 0, audioAt = -Infinity, envelope = 0, demo = false, resumeMusic = false, autoplayArmed = false;
  let audioContext, analyser, spectrum, drag = null;
  let musicName = DEFAULT_MUSIC_LABEL, musicFailure = '', musicRequest = 0;
  let backgroundImage = null, backgroundURL = null, backgroundRequest = 0;
  let backgroundVideo = null, backgroundVideoName = BACKGROUND_VIDEO_LABEL, backgroundVideoFailed = false;
  let backgroundVideoHasFrame = false, videoHold = null, videoHoldReady = false;
  let backgroundVideoRequest = 0;
  let selectedDoll = 0, highlight = true;

  function syncMotionState() {
    if (host) return;
    const reasons = [];
    if (userPaused) reasons.push('动画已暂停');
    if (settings.stationary) reasons.push('固定位置已开启，停止漂浮与甩出');
    if (settings.speed === 0) reasons.push('移动速度为 0');
    $('motion-status').hidden = reasons.length === 0;
    $('motion-message').textContent = reasons.join(' · ');
  }

  function formatValue(key, value) {
    if (key === 'count') return value + ' 个';
    if (key === 'size') return value + ' px';
    if (key === 'speed') return value + ' px/s';
    if (key === 'collisionbox') return Math.round(value * 100) + '%';
    if (['strength', 'stretch'].includes(key)) return Math.round(value * 100) + '%';
    if (key === 'musicvolume') return value + '%';
    if (key === 'decay') return value + ' 秒';
    if (['spinmin', 'spinmax'].includes(key)) return value + ' 圈/秒';
    if (key === 'videoscale') return value + ' 倍';
    if (key === 'videox' || key === 'videoy') return (value > 0 ? '+' : '') + value + '%';
    return value + ' 倍';
  }
  function dollImage(index) {
    if (customDolls[index]?.image) return customDolls[index].image;
    const wanted = settings['dollimage' + (index + 1)];
    // draw() 每帧都调这里，热点路径上避免线性查找：先查缓存，未命中才扫表并记住结果。
    let file = dollImageCache.get(wanted);
    if (!file) {
      file = (DOLL_IMAGES.find(image => image.value === wanted) || DOLL_IMAGES[0]).file;
      dollImageCache.set(wanted, file);
    }
    // 目标精灵还没加载完时，退回任意一张已就绪的精灵，避免这一帧整只娃娃消失。
    // 一张都没就绪时返回 undefined，由调用方 continue 跳过这只娃娃这一帧。
    return sprites.get(file) || sprites.values().next().value;
  }
  function syncImageAspects() {
    for (let i = 0; i < world.bodies.length; i++) {
      const image = dollImage(i), body = world.bodies[i];
      body.imageAspect = image?.width && image?.height ? image.width / image.height : 1;
      if (!body.dragged) world.walls(body, false);
    }
  }
  function normalizeFilePath(value) {
    const path = String(value || '').trim();
    return path.length > 1 && ((path[0] === '"' && path.at(-1) === '"') || (path[0] === "'" && path.at(-1) === "'"))
      ? path.slice(1, -1) : path;
  }
  function fileLabel(value) {
    const name = String(value).replace(/\\/g, '/').split('/').pop();
    try { return decodeURIComponent(name); } catch { return name; }
  }
  function syncAssetNotice() {
    const messages = customDolls.map((record, i) => record.error ? '娃娃 ' + (i + 1) + '：' + record.error : '').filter(Boolean);
    if (musicFailure) messages.push(musicFailure);
    $('asset-notice').textContent = messages.join(' · '); $('asset-notice').hidden = messages.length === 0;
  }
  function disposeCustomDoll(record) {
    if (record.image) {
      alphaCache.delete(record.image);
      if (typeof record.image.close === 'function') record.image.close();
    }
    if (record.ownedURL) URL.revokeObjectURL(record.ownedURL);
    record.image = null; record.ownedURL = null;
  }
  function setCustomDoll(index, source, label = '', ownedURL = null) {
    releaseDrag(false);
    const record = customDolls[index], request = ++record.request;
    disposeCustomDoll(record);
    record.source = source; record.label = label; record.ownedURL = ownedURL; record.error = '';
    syncImageAspects(); syncSelection(); syncAssetNotice(); draw();
    if (!source) return;
    const candidate = new Image();
    const finish = image => {
      if (request !== record.request) { if (typeof image.close === 'function') image.close(); return; }
      if (!image.width || !image.height) { if (typeof image.close === 'function') image.close(); fail(); return; }
      record.image = image; ready = true;
      syncImageAspects(); syncSelection(); draw();
    };
    const fail = () => {
      if (request !== record.request) return;
      record.error = '图片未能加载，已使用内置形象。请检查文件。';
      syncSelection(); syncAssetNotice(); draw();
    };
    candidate.onload = () => {
      if (typeof createImageBitmap === 'function') createImageBitmap(candidate).then(finish).catch(() => finish(candidate));
      else finish(candidate);
    };
    candidate.onerror = fail; candidate.src = source;
  }
  function alphaData(image) {
    if (!image) return null;
    if (alphaCache.has(image)) return alphaCache.get(image);
    let pixels = null;
    try {
      const buffer = document.createElement('canvas');
      buffer.width = image.width; buffer.height = image.height;
      const surface = buffer.getContext('2d'); surface.drawImage(image, 0, 0);
      pixels = surface.getImageData(0, 0, image.width, image.height).data;
    } catch { /* Some file:// browsers disallow pixel reads; rectangle picking remains available. */ }
    alphaCache.set(image, pixels);
    return pixels;
  }
  function loadSprites() {
    for (const file of IMAGE_FILES) {
      // 提前解码素材；后续的缩放和旋转仍需要渲染，不能据此保证宿主帧率。
      const finish = source => { sprites.set(file, source); ready = true; syncImageAspects(); draw(); };
      if (typeof createImageBitmap === 'function') {
        const image = new Image();
        image.onload = () => {
          // 用自然尺寸建位图；失败（如 file:// 或尺寸为 0）则退回原始 <img>。
          createImageBitmap(image).then(finish).catch(() => finish(image));
        };
        image.onerror = () => { $('load-error').hidden = false; };
        image.src = file;
      } else {
        const image = new Image();
        image.onload = () => finish(image);
        image.onerror = () => { $('load-error').hidden = false; };
        image.src = file;
        // 已从缓存同步解码完成的浏览器会在这里就拿到尺寸，先标记可用避免首帧空白。
        if (image.complete && image.naturalWidth) finish(image);
      }
    }
  }

  function syncSelection() {
    if (host) return;
    selectedDoll = Math.min(selectedDoll, settings.count - 1);
    const select = $('selected-doll');
    if (select.options.length !== settings.count) {
      select.replaceChildren(...Array.from({ length: settings.count }, (_, i) => new Option('娃娃 ' + (i + 1), String(i))));
    }
    select.value = String(selectedDoll);
    const requested = settings['dollsize' + (selectedDoll + 1)];
    $('individual-size').value = requested;
    $('individual-size-value').value = requested ? requested + ' px' : '跟随全局';
    const chosen = settings['dollimage' + (selectedDoll + 1)];
    const selectImage = $('individual-image');
    if (selectImage.options.length !== DOLL_IMAGES.length) {
      selectImage.replaceChildren(...DOLL_IMAGES.map(image => new Option(image.label, image.value)));
    }
    if (DOLL_IMAGES.some(image => image.value === chosen)) selectImage.value = chosen;
    const actual = Math.round(world.bodies[selectedDoll]?.size || settings.size);
    $('individual-status').textContent = '娃娃 ' + (selectedDoll + 1) + ' · 当前显示约 ' + actual + ' px。0 表示跟随全局；空间不足时按比例缩小。';
    const custom = customDolls[selectedDoll];
    $('custom-doll-status').textContent = custom.source ? (custom.error || (custom.image ? '正在使用自选图片 · ' : '正在加载自选图片 · ') + custom.label) : '正在使用内置形象 · 可为这只娃娃导入自己的图片';
  }

  function parseBackgroundColor(value) {
    const text = String(value).trim();
    if (/^#[0-9a-f]{6}$/i.test(text)) return text.toLowerCase();
    const channels = text.split(/\s+/).map(Number);
    if (channels.length !== 3 || !channels.every(Number.isFinite)) return null;
    return '#' + channels.map(v => Math.round(clamp(v, 0, 1) * 255).toString(16).padStart(2, '0')).join('');
  }
  function hostImageURL(value) {
    const raw = normalizeFilePath(value);
    if (/^(blob|data):/i.test(raw)) return raw;
    if (/^file:/i.test(raw)) return raw.replace(/\\/g, '/');
    const path = raw.replace(/\\/g, '/').replace(/^\/([a-z]:\/)/i, '$1');
    const parts = path.split('/').map((part, i) => i === 0 && /^[a-z]:$/i.test(part) ? part : encodeURIComponent(part));
    // Imported project-relative files must resolve beside index.html, not at the disk root.
    if (/^[a-z]:\//i.test(path)) return 'file:///' + parts.join('/');
    if (path.startsWith('//')) return 'file:' + parts.join('/');
    if (path.startsWith('/')) return 'file://' + parts.join('/');
    return parts.join('/');
  }
  function setBackgroundImage(source, label = '背景图片', ownedURL = null) {
    const request = ++backgroundRequest;
    if (backgroundURL) URL.revokeObjectURL(backgroundURL);
    backgroundURL = ownedURL;
    if (!source) {
      backgroundImage = null; $('background-status').textContent = '纯色背景 · 选择图片后优先显示图片'; draw(); return;
    }
    $('background-status').textContent = '正在加载背景图片…';
    const candidate = new Image();
    candidate.onload = () => {
      if (request !== backgroundRequest) return;
      backgroundImage = candidate; $('background-status').textContent = label + ' · 完整显示时空白使用背景颜色'; draw();
    };
    candidate.onerror = () => {
      if (request !== backgroundRequest) return;
      backgroundImage = null; $('background-status').textContent = '图片未能加载，已显示所选背景颜色。'; draw();
    };
    candidate.src = source;
  }
  // Native video underneath the transparent foreground; no per-frame foreground video copies.
  function ensureBackgroundVideo() {
    if (backgroundVideo) return backgroundVideo;
    const video = document.createElement('video');
    video.muted = !settings.videoaudio; video.defaultMuted = !settings.videoaudio;
    // Start through playBackgroundVideo only, so late loads respect pause and background mode.
    video.loop = true; video.autoplay = false; video.playsInline = true;
    video.preload = 'auto'; video.setAttribute('aria-hidden', 'true');
    video.id = 'background-video'; video.hidden = true;
    video.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;object-fit:cover;pointer-events:none;z-index:0;transform-origin:50% 50%;';
    // Same z-index, earlier DOM order: a retained frame under the native video covers seek gaps.
    videoHold = document.createElement('canvas'); videoHold.id = 'video-hold'; videoHold.hidden = true;
    videoHold.style.cssText = video.style.cssText; videoHold.setAttribute('aria-hidden', 'true');
    document.body.appendChild(videoHold);
    const retryPlay = () => {
      if (video.error || backgroundVideoFailed) return;
      captureVideoFrame(); $('background-status').textContent = backgroundVideoLabel(); playBackgroundVideo(); draw();
    };
    video.addEventListener('loadeddata', retryPlay);
    video.addEventListener('canplay', retryPlay);
    video.addEventListener('loadedmetadata', retryPlay);
    video.addEventListener('timeupdate', () => captureVideoFrame());
    video.addEventListener('seeking', () => captureVideoFrame(true));
    video.addEventListener('error', () => { if (video.error) videoFailure(videoErrorText(video.error)); });
    document.body.appendChild(video); backgroundVideo = video;
    return video;
  }
  function captureVideoFrame(force = false) {
    const video = backgroundVideo;
    if (!video || !videoHold || video.readyState < 2 || !video.videoWidth || video.error || backgroundVideoFailed) return;
    backgroundVideoHasFrame = true;
    // One initial snapshot, then only the loop tail/seek: never copy video in the foreground loop.
    const nearEnd = Number.isFinite(video.duration) && video.duration - video.currentTime <= 0.75;
    if (videoHoldReady && !force && !nearEnd) return;
    const scale = Math.min(1, 1280 / video.videoWidth, 720 / video.videoHeight);
    const width = Math.max(1, Math.round(video.videoWidth * scale)), height = Math.max(1, Math.round(video.videoHeight * scale));
    try {
      if (videoHold.width !== width) videoHold.width = width;
      if (videoHold.height !== height) videoHold.height = height;
      videoHold.getContext('2d').drawImage(video, 0, 0, width, height);
      videoHoldReady = true; syncVideoLayer();
    } catch { /* Preserve any prior snapshot; native video playback remains usable. */ }
  }
  function backgroundVideoLabel() {
    const name = backgroundVideoName;
    const audio = settings.videoaudio ? '视频原声开' : '视频静音';
    const seconds = Number.isFinite(backgroundVideo.duration) ? backgroundVideo.duration.toFixed(1) + 's' : '—';
    const zoom = settings.videoscale !== 1 ? ' · 放大 ' + settings.videoscale + ' 倍' : '';
    const offset = (settings.videox || settings.videoy) ? ' · 位置 ' + settings.videox + '% / ' + settings.videoy + '%' : '';
    return '视频背景循环播放 · ' + name + ' · ' + seconds + ' · ' + audio + zoom + offset;
  }
  function videoFailure(message) {
    backgroundVideoFailed = true;
    backgroundVideoHasFrame = false; videoHoldReady = false;
    if (videoHold) videoHold.hidden = true;
    $('background-status').textContent = message + ' 已回退到图片或纯色。';
    $('video-notice').textContent = message; $('video-notice').hidden = false;
    if (backgroundVideo) backgroundVideo.hidden = true;
    draw();
  }
  function videoErrorText(error) {
    const descriptions = { 1: '视频加载被中止', 2: '读取视频时发生错误', 3: '视频解码失败',
      4: '未找到可播放的视频资源（路径、读取权限或格式问题）' };
    const video = backgroundVideo;
    const code = error?.code || error?.name || '未知';
    const selected = BACKGROUND_VIDEO_FILE;
    const source = video?.currentSrc || video?.src || '尚未设置';
    const support = typeof video?.canPlayType === 'function' ? video.canPlayType('video/webm; codecs="vp8"') || '未声明支持' : '未知';
    return ['HTML 壁纸 · 内置视频加载失败', (descriptions[error?.code] || '视频加载失败') + ' · 错误 ' + code,
      '选定文件：' + selected, '实际地址：' + source,
      '读取状态：' + video?.networkState + ' / 就绪状态：' + video?.readyState + ' / VP8 支持：' + support,
      error?.message ? '浏览器详情：' + error.message : '',
      '请保留壁纸包的 assets 文件夹；内置视频不可用时可切换图片或纯色背景。'].filter(Boolean).join('\n');
  }
  // Readiness can dip while a looping video seeks. Only source changes/errors clear the frame latch.
  function videoBackgroundActive() {
    return settings.backgroundmode === 'video' && settings.videoenabled && !!backgroundVideo &&
      (backgroundVideoHasFrame || (backgroundVideo.readyState >= 2 && backgroundVideo.videoWidth > 0)) &&
      !backgroundVideo.error && !backgroundVideoFailed;
  }
  // 放大与位移走 CSS 变换交给合成器：不额外增加每帧的前景绘制开销。
  // 锚点固定在视口中心，所以「放大 2 倍」= 从中心向四周各扩一倍；位移按视口宽高的百分比换算。
  function videoTransform() {
    const zoom = clamp(Number(settings.videoscale) || 1, 1, 3);
    const offsetX = clamp(Number(settings.videox) || 0, -100, 100) / 100 * innerWidth;
    const offsetY = clamp(Number(settings.videoy) || 0, -100, 100) / 100 * innerHeight;
    return 'translate(' + offsetX.toFixed(2) + 'px,' + offsetY.toFixed(2) + 'px) scale(' + zoom.toFixed(4) + ')';
  }
  function syncVideoLayer() {
    if (!backgroundVideo) return;
    if (backgroundVideo.readyState >= 2 && backgroundVideo.videoWidth > 0 && !backgroundVideo.error && !backgroundVideoFailed) backgroundVideoHasFrame = true;
    backgroundVideo.hidden = !videoBackgroundActive();
    if (backgroundVideo.style.objectFit !== settings.videofit) backgroundVideo.style.objectFit = settings.videofit;
    // 默认状态（1 倍、无位移）清空 transform，让宿主走最省的纯合成路径。
    const transform = settings.videoscale === 1 && !settings.videox && !settings.videoy ? '' : videoTransform();
    if (backgroundVideo.style.transform !== transform) backgroundVideo.style.transform = transform;
    if (videoHold) {
      videoHold.hidden = backgroundVideo.hidden || !videoHoldReady;
      if (videoHold.style.objectFit !== settings.videofit) videoHold.style.objectFit = settings.videofit;
      if (videoHold.style.transform !== transform) videoHold.style.transform = transform;
    }
  }
  function playBackgroundVideo() {
    if (settings.backgroundmode !== 'video' || !settings.videoenabled || !active()) return;
    const video = ensureBackgroundVideo();
    if (!video.src || !video.paused || backgroundVideoFailed) return;
    const request = backgroundVideoRequest;
    const started = video.play();
    if (started && typeof started.catch === 'function') started.catch(error => {
      if (request !== backgroundVideoRequest) return;
      if (error && error.name === 'AbortError') return;
      if (error && error.name === 'NotSupportedError') videoFailure(videoErrorText(video.error || error));
      else armAutoplayUnlock();
    });
  }
  function setBackgroundVideo(source, label = '默认视频') {
    ++backgroundVideoRequest;
    const video = ensureBackgroundVideo();
    backgroundVideoHasFrame = false; videoHoldReady = false;
    if (videoHold) videoHold.hidden = true;
    backgroundVideoName = label; backgroundVideoFailed = false; $('video-notice').hidden = true;
    video.pause(); video.removeAttribute('src'); video.load();
    if (!source) {
      $('background-status').textContent = '背景视频已清除，回退到图片或纯色背景。'; draw(); return;
    }
    video.src = source; video.load();
    $('background-status').textContent = '正在加载背景视频…';
    playBackgroundVideo();
  }

  function configure() {
    world.rotation = settings.rotation; world.decay = settings.decay; world.dragAnimation = settings.draganimation;
    world.stretch = settings.stretch; world.stationary = settings.stationary;
    world.collisionScale = settings.collisionbox; world.beatBoost = settings.beatboost;
    // 两个滑块可能被拖成反序，取小值为下限、大值为上限，保证区间始终有效。
    world.spinMin = Math.min(settings.spinmin, settings.spinmax);
    world.spinMax = Math.max(settings.spinmin, settings.spinmax);
    world.configure(innerWidth, innerHeight, settings.size, settings.speed, settings.count,
      Array.from({ length: 8 }, (_, i) => settings['dollsize' + (i + 1)]));
    syncImageAspects();
    syncSelection(); syncMotionState();
  }
  function resize() {
    releaseDrag(false);
    // Bound high-DPI foreground work; video keeps its own native compositing layer.
    const pixelBudget = 3840 * 2160;
    const ratio = Math.min(devicePixelRatio || 1, settings.renderquality, Math.sqrt(pixelBudget / Math.max(1, innerWidth * innerHeight)));
    canvas.width = Math.round(innerWidth * ratio); canvas.height = Math.round(innerHeight * ratio);
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.imageSmoothingEnabled = true;
    if ('imageSmoothingQuality' in ctx) ctx.imageSmoothingQuality = 'medium';
    configure(); syncVideoLayer(); draw();
  }
  function drawBackground() {
    if (videoBackgroundActive()) return;
    const source = backgroundImage;
    if (!source) return;
    const width = source.videoWidth || source.naturalWidth || source.width;
    const height = source.videoHeight || source.naturalHeight || source.height;
    if (!width || !height) return;
    const fit = settings.backgroundfit;
    const scale = fit === 'contain' ? Math.min(innerWidth / width, innerHeight / height) : Math.max(innerWidth / width, innerHeight / height);
    // 静态图片 cover 时仅绘制可见的源区域；视频由独立层处理。
    const drawWidth = width * scale, drawHeight = height * scale;
    // 目标框超出视口的量（cover 时通常有；contain 时为 0）。
    const overflowX = Math.max(0, drawWidth - innerWidth), overflowY = Math.max(0, drawHeight - innerHeight);
    if (overflowX > 0.5 || overflowY > 0.5) {
      // cover：从源里裁掉最终会被画布切掉的部分，画到裁后的目标矩形上。
      const sourceX = overflowX / 2 / scale, sourceY = overflowY / 2 / scale;
      const sourceWidth = width - overflowX / scale, sourceHeight = height - overflowY / scale;
      ctx.drawImage(source, sourceX, sourceY, sourceWidth, sourceHeight, 0, 0, innerWidth, innerHeight);
      return;
    }
    // contain：源全用，居中留边。
    ctx.drawImage(source, (innerWidth - drawWidth) / 2, (innerHeight - drawHeight) / 2, drawWidth, drawHeight);
  }
  function draw() {
    syncVideoLayer();
    ctx.clearRect(0, 0, innerWidth, innerHeight);
    document.body.style.backgroundColor = settings.backgroundcolor;
    if (!videoBackgroundActive()) {
      ctx.fillStyle = settings.backgroundcolor; ctx.fillRect(0, 0, innerWidth, innerHeight);
    }
    drawBackground();
    if (!ready) return;
    // 娃娃绘制热路径：尽量少做临时对象与重复调用，宿主里每帧省下的时间直接决定是否掉帧。
    const highlightOn = !host && highlight && !$('settings').hidden;
    const bodies = world.bodies;
    for (let i = 0; i < bodies.length; i++) {
      const body = bodies[i];
      const image = dollImage(i); if (!image) continue;
      const geometry = world.geometry(body);
      const width = geometry.width, height = geometry.height, offsetY = geometry.offsetY;
      ctx.save(); ctx.translate(body.x, body.y); ctx.rotate(body.angle);
      ctx.drawImage(image, -width / 2, offsetY - height / 2, width, height);
      if (highlightOn && i === selectedDoll) {
        ctx.strokeStyle = '#5b7ebd'; ctx.lineWidth = 1.5;
        ctx.strokeRect(-width / 2 - 5, offsetY - height / 2 - 5, width + 10, height + 10);
      }
      ctx.restore();
      if (highlightOn && i === selectedDoll) {
        ctx.fillStyle = '#37568c'; ctx.font = '600 13px "Microsoft YaHei", sans-serif'; ctx.textAlign = 'center';
        ctx.fillText('娃娃 ' + (i + 1), body.x, body.y - geometry.hy - 12);
      }
    }
  }
  function consumeAudio(values) {
    let bass = 0, volume = 0;
    for (let i = 0; i < 64; i++) {
      const energy = (clamp(Number(values[i]) || 0, 0, 1) + clamp(Number(values[i + 64]) || 0, 0, 1)) / 2;
      volume += energy; if (i < 12) bass += energy;
    }
    audioLevel = clamp((bass / 12 * 0.82 + volume / 64 * 0.18) * 2.4, 0, 1); audioAt = performance.now();
  }
  function initAudio() {
    if (audioContext) return;
    const AudioAPI = window.AudioContext || window.webkitAudioContext;
    if (!AudioAPI) return;
    audioContext = new AudioAPI(); analyser = audioContext.createAnalyser();
    analyser.fftSize = 2048; analyser.smoothingTimeConstant = 0.55;
    spectrum = new Uint8Array(analyser.frequencyBinCount);
    const source = audioContext.createMediaElementSource(player);
    source.connect(analyser); analyser.connect(audioContext.destination);
  }
  async function playMusic() {
    if (!settings.musicenabled || enginePaused) return;
    const request = musicRequest;
    try {
      initAudio(); if (audioContext) audioContext.resume().catch(() => {});
      await player.play(); if (request !== musicRequest) return;
      $('audio-status').textContent = '正在播放 · ' + musicName;
      $('music-start').hidden = true;
    } catch {
      if (request !== musicRequest || musicFailure) return;
      // 浏览器自动播放被拦截：挂上一次性手势监听，用户第一次点击/按键就自动开始播放。
      $('audio-status').textContent = musicName + '已就绪 · 点击画面任意处开始播放';
      $('music-start').hidden = false;
      armAutoplayUnlock();
    }
  }
  function armAutoplayUnlock() {
    if (autoplayArmed) return; autoplayArmed = true;
    const unlock = () => {
      autoplayArmed = false;
      for (const event of ['pointerdown', 'keydown', 'touchstart']) window.removeEventListener(event, unlock, true);
      if (settings.musicenabled && player.paused && !enginePaused && !demo) playMusic();
      if (backgroundVideo && backgroundVideo.paused) playBackgroundVideo();
    };
    for (const event of ['pointerdown', 'keydown', 'touchstart']) window.addEventListener(event, unlock, true);
  }
  // 只播放内置默认音乐。自选本地音乐功能已按要求彻底移除：
  // 它会把选中的文件存进 IndexedDB 并在启动时自动恢复，一旦那条旧记录失效
  // （换了目录、清了缓存、blob 解不出来），内置音乐就会被顶掉，表现为「没有音乐」。
  // 别再把它加回来，也不要恢复任何 IndexedDB 读取逻辑。
  function loadDefaultMusic(start = true) {
    ++musicRequest; player.pause();
    musicName = DEFAULT_MUSIC_LABEL; musicFailure = ''; syncAssetNotice();
    player.src = DEFAULT_MUSIC_FILE; player.loop = true;
    player.volume = settings.musicvolume / 100; player.load();
    beatPulse.reset(); audioLevel = 0; audioAt = -Infinity;
    $('audio-status').textContent = '音乐已就绪 · ' + musicName;
    if (enginePaused) resumeMusic = start && settings.musicenabled;
    if (start && settings.musicenabled && !enginePaused) playMusic();
  }
  function getLevel(now) {
    if (analyser && audioContext.state === 'running' && !player.paused && !player.ended && !player.error) {
      analyser.getByteFrequencyData(spectrum);
      let bass = 0, volume = 0;
      const bassBins = Math.max(1, Math.round(260 / (audioContext.sampleRate / analyser.fftSize)));
      for (let i = 0; i < spectrum.length; i++) { volume += spectrum[i] / 255; if (i < bassBins) bass += spectrum[i] / 255; }
      return clamp(bass / bassBins * 0.82 + volume / spectrum.length * 0.18, 0, 1);
    }
    if (!host && demo) return Math.pow(Math.max(0, Math.sin(now / 1000 * Math.PI * 4)), 5);
    return now - audioAt < 250 ? audioLevel : 0;
  }
  // 保留宿主可见性处理：宿主按 setPaused 暂停，普通浏览器按 document.hidden 暂停。
  // 不把 VM 中模拟隐藏状态的结果当作真实桌面性能测量。
  function active() { return !enginePaused && !userPaused && !(document.hidden && !host); }
  // Retain fractional frame time rather than resetting the phase after every render.
  function tick(now) {
    frameId = 0; if (!active()) return;
    if (lastFrame === null) { lastFrame = now; lastSimulation = now; }
    frameAccumulator += clamp(now - lastFrame, 0, 100); lastFrame = now;
    const frameBudget = 1000 / fps;
    // Video advances independently. A skipped foreground frame does no video copies or redraws.
    if (frameAccumulator < frameBudget - 0.5) {
      frameId = requestAnimationFrame(tick);
      return;
    }
    frameAccumulator = Math.max(0, frameAccumulator - Math.max(1, Math.floor((frameAccumulator + 0.5) / frameBudget)) * frameBudget);
    const dt = clamp((now - lastSimulation) / 1000, 0, 0.1); lastSimulation = now;
    const pulse = beatPulse.step(getLevel(now), dt, now, settings.sensitivity);
    const target = settings.strength === 0 ? 0 : pulse * (pulse >= 0 ? settings.strength : settings.stretch);
    const smoothing = 1 - Math.exp(-dt / 0.012);
    envelope += (target - envelope) * smoothing;
    // 节拍加速用 pulse 的绝对值：压扁段和拉伸段都算在加速里。
    world.step(dt, settings.collisions, envelope, settings.strength, Math.abs(pulse)); draw();
    renderedFrames++;
    if (measureAt === null) measureAt = now;
    if (now - measureAt >= 1000) {
      $('performance-status').textContent = '前景约 ' + Math.round(renderedFrames * 1000 / (now - measureAt)) + ' FPS · 目标 ' + fps + ' FPS · 画布 ' + canvas.width + ' × ' + canvas.height;
      measureAt = now; renderedFrames = 0;
    }
    frameId = requestAnimationFrame(tick);
  }
  function resume() {
    if (frameId) cancelAnimationFrame(frameId); frameId = 0; lastFrame = null; lastSimulation = null; frameAccumulator = 0; measureAt = null; renderedFrames = 0;
    if (backgroundVideo) { if (active()) playBackgroundVideo(); else backgroundVideo.pause(); }
    if (active()) frameId = requestAnimationFrame(tick);
  }
  function hitTest(x, y) {
    for (let i = world.bodies.length - 1; i >= 0; i--) {
      const body = world.bodies[i], image = dollImage(i); if (!image) continue;
      const { width, height, offsetY } = world.geometry(body);
      const dx = x - body.x, dy = y - body.y, c = Math.cos(body.angle), s = Math.sin(body.angle);
      const u = (dx * c + dy * s) / width + 0.5, v = (-dx * s + dy * c - offsetY) / height + 0.5;
      if (u < 0 || u >= 1 || v < 0 || v >= 1) continue;
      const alpha = alphaData(image);
      if (alpha && alpha[(Math.floor(v * image.height) * image.width + Math.floor(u * image.width)) * 4 + 3] < 32) continue;
      return body;
    }
    return null;
  }
  function rememberDrag() {
    const now = performance.now();
    drag.samples.push({ x: drag.body.x, y: drag.body.y, time: now });
    while (drag.samples.length > 2 && drag.samples[1].time < now - 100) drag.samples.shift();
    drag.lastMove = now;
  }
  function releaseDrag(throwIt = true) {
    if (!drag) return;
    const first = drag.samples[0], last = drag.samples[drag.samples.length - 1];
    const dt = (last.time - first.time) / 1000;
    const fresh = performance.now() - drag.lastMove < 100;
    world.endDrag(drag.body, throwIt && fresh && dt > 0.008 ? (last.x - first.x) / dt * settings.throwforce : 0,
      throwIt && fresh && dt > 0.008 ? (last.y - first.y) / dt * settings.throwforce : 0);
    const pointerId = drag.pointerId; drag = null;
    if (canvas.hasPointerCapture(pointerId)) canvas.releasePointerCapture(pointerId);
    canvas.style.cursor = 'default';
  }
  canvas.addEventListener('pointerdown', event => {
    if (event.button !== 0 || drag || !ready) return;
    const body = hitTest(event.clientX, event.clientY); if (!body) return;
    selectedDoll = world.bodies.indexOf(body); syncSelection();
    event.preventDefault();
    const g = world.geometry(body), dx = event.clientX - body.x, dy = event.clientY - body.y;
    const c = Math.cos(body.angle), s = Math.sin(body.angle);
    world.beginDrag(body, { x: event.clientX, y: event.clientY,
      u: (dx * c + dy * s) / g.width + 0.5, v: (-dx * s + dy * c - g.offsetY) / g.height + 0.5 });
    drag = { body, pointerId: event.pointerId, ox: event.clientX - body.x, oy: event.clientY - body.y, samples: [],
      pointerX: event.clientX, pointerY: event.clientY, motionTime: performance.now() };
    rememberDrag(); canvas.setPointerCapture(event.pointerId); canvas.style.cursor = 'grabbing';
    if (settings.musicenabled && player.paused && !demo) playMusic();
  });
  canvas.addEventListener('pointermove', event => {
    if (drag && event.pointerId === drag.pointerId) {
      const now = performance.now(), dt = clamp((now - drag.motionTime) / 1000, 0.008, 0.1);
      world.dragMotion(drag.body, (event.clientX - drag.pointerX) / dt, (event.clientY - drag.pointerY) / dt,
        drag.pointerX - drag.body.x, drag.pointerY - drag.body.y);
      drag.pointerX = event.clientX; drag.pointerY = event.clientY; drag.motionTime = now;
      world.dragPointer(drag.body, event.clientX, event.clientY); rememberDrag(); draw();
    } else if (!drag) canvas.style.cursor = hitTest(event.clientX, event.clientY) ? 'grab' : 'default';
  });
  canvas.addEventListener('pointerup', event => { if (drag && event.pointerId === drag.pointerId) releaseDrag(); });
  for (const event of ['pointercancel', 'lostpointercapture']) canvas.addEventListener(event, () => releaseDrag(false));
  window.addEventListener('blur', () => releaseDrag(false));

  // 视频视图控件的 id 与 settings 键一一对应：videoscale → video-scale 等。
  const VIDEO_VIEW_CONTROLS = { videoscale: 'video-scale', videox: 'video-x', videoy: 'video-y' };
  function syncVideoViewControls() {
    if (host) return;
    for (const key of Object.keys(VIDEO_VIEW_CONTROLS)) {
      const input = $(VIDEO_VIEW_CONTROLS[key]);
      input.value = settings[key];
      $(VIDEO_VIEW_CONTROLS[key] + '-value').value = formatValue(key, settings[key]);
    }
  }
  function updateSetting(key, value) {
    if (/^dollfile[1-8]$/.test(key)) {
      const path = normalizeFilePath(value); settings[key] = path;
      setCustomDoll(Number(key.slice(8)) - 1, path ? hostImageURL(path) : '', fileLabel(path)); return;
    } else if (key === 'renderquality') {
      const quality = Number(value); if (![1, 1.5, 2].includes(quality)) return;
      settings[key] = quality; $('render-quality').value = String(quality); resize(); return;
    } else if (key in VIDEO_VIEW_CONTROLS) {
      const number = Number(value); if (!Number.isFinite(number)) return;
      settings[key] = clamp(number, ...ranges[key]); syncVideoViewControls();
      // 变换在合成器里生效，不必重画前景；但仍同步一次图层状态，保证视频关着时也一致。
      syncVideoLayer(); $('background-status').textContent = backgroundVideoLabel(); return;
    } else if (key === 'backgroundcolor') {
      const color = parseBackgroundColor(value); if (!color) return;
      settings[key] = color; $('background-color').value = color;
    } else if (key === 'backgroundfit') {
      if (!['cover', 'contain'].includes(value)) return;
      settings[key] = value; $('background-fit').value = value;
    } else if (key === 'backgroundimage') {
      settings[key] = String(value || ''); setBackgroundImage(settings[key] ? hostImageURL(settings[key]) : ''); return;
    } else if (key === 'backgroundmode') {
      if (!['video', 'image'].includes(value)) return;
      settings[key] = value; $('background-mode').value = value;
      if (value === 'video') playBackgroundVideo();
      else if (backgroundVideo) backgroundVideo.pause();
      $('background-status').textContent = value === 'video'
        ? (settings.videoenabled ? backgroundVideoLabel() : '视频背景已关闭 · 现在显示图片或纯色背景')
        : '图片背景 · 关闭视频后使用所选图片或纯色';
      draw(); return;
    } else if (key === 'videoenabled') {
      settings[key] = !!value; $('video-enabled').checked = settings[key];
      if (settings[key] && backgroundVideoFailed) setBackgroundVideo(BACKGROUND_VIDEO_FILE, BACKGROUND_VIDEO_LABEL);
      else if (settings[key]) playBackgroundVideo(); else if (backgroundVideo) backgroundVideo.pause();
      // 视频关闭后要立刻回到图片/纯色，所以绕过“视频优先”再画一次。
      $('background-status').textContent = settings[key]
        ? (settings.backgroundmode === 'video' ? backgroundVideoLabel() : '视频已就绪 · 当前背景模式为图片')
        : '视频背景已关闭 · 现在显示图片或纯色背景';
      draw(); return;
    } else if (key === 'videoaudio') {
      settings[key] = !!value; $('video-audio').checked = settings[key];
      if (backgroundVideo) { backgroundVideo.muted = !settings[key]; backgroundVideo.defaultMuted = !settings[key]; }
      $('background-status').textContent = backgroundVideoLabel(); return;
    } else if (key === 'videofit') {
      if (!['cover', 'contain'].includes(value)) return;
      settings[key] = value; $('video-fit').value = value; syncVideoLayer(); draw(); return;
    } else if (/^dollimage[1-8]$/.test(key)) {
      if (!DOLL_IMAGES.some(image => image.value === value)) return;
      settings[key] = value; syncSelection(); draw(); return;
    } else if (['collisions', 'musicenabled', 'stationary'].includes(key)) settings[key] = !!value;
    else {
      const range = /^dollsize[1-8]$/.test(key) ? [0, 600] : ranges[key]; if (!range) return;
      const number = Number(value); if (!Number.isFinite(number)) return;
      settings[key] = clamp(number, ...range); if (key === 'count') settings[key] = Math.round(settings[key]);
    }
    if (['count', 'size', 'speed', 'stationary', 'collisionbox', 'spinmin', 'spinmax'].includes(key) || /^dollsize/.test(key)) { releaseDrag(false); configure(); }
    if (key === 'rotation') world.rotation = settings.rotation;
    if (key === 'decay') world.decay = settings.decay;
    if (key === 'draganimation') world.dragAnimation = settings.draganimation;
    if (key === 'stretch') world.stretch = settings.stretch;
    if (key === 'beatboost') world.beatBoost = settings.beatboost;
    if (key === 'musicenabled') { if (settings.musicenabled) playMusic(); else player.pause(); }
    if (key === 'musicvolume') player.volume = settings.musicvolume / 100;
    if (!host && ranges[key]) { $(key).value = settings[key]; $(key + '-value').value = formatValue(key, settings[key]); }
    if (!host && ['stationary', 'collisions'].includes(key)) $(key).checked = settings[key];
    syncMotionState();
    draw();
  }
  window.wallpaperPropertyListener = {
    applyUserProperties(properties) { for (const key of Object.keys(defaults)) if (properties[key]) updateSetting(key, properties[key].value); },
    applyGeneralProperties(properties) { if (Number.isFinite(Number(properties.fps))) fps = clamp(Number(properties.fps), 1, 144); },
    setPaused(value) {
      const wasPaused = enginePaused; enginePaused = !!value; releaseDrag(false);
      if (enginePaused && !wasPaused) { resumeMusic = !player.paused; player.pause(); }
      else if (!enginePaused && resumeMusic && settings.musicenabled) { resumeMusic = false; playMusic(); }
      resume();
    }
  };
  if (host) {
    window.wallpaperRegisterAudioListener(consumeAudio);
  }
  else {
    $('preview').hidden = false;
    $('render-quality').addEventListener('change', () => updateSetting('renderquality', $('render-quality').value));
    $('background-color').addEventListener('input', () => updateSetting('backgroundcolor', $('background-color').value));
    $('background-fit').addEventListener('change', () => updateSetting('backgroundfit', $('background-fit').value));
    $('background-image').addEventListener('change', () => {
      const file = $('background-image').files[0]; if (!file) return;
      const url = URL.createObjectURL(file); settings.backgroundimage = url;
      setBackgroundImage(url, file.name, url);
    });
    $('background-clear').addEventListener('click', () => { $('background-image').value = ''; updateSetting('backgroundimage', ''); });
    $('background-mode').addEventListener('change', () => updateSetting('backgroundmode', $('background-mode').value));
    $('video-enabled').addEventListener('change', () => updateSetting('videoenabled', $('video-enabled').checked));
    $('video-audio').addEventListener('change', () => updateSetting('videoaudio', $('video-audio').checked));
    $('video-fit').addEventListener('change', () => updateSetting('videofit', $('video-fit').value));
    $('video-scale').addEventListener('input', () => updateSetting('videoscale', $('video-scale').value));
    $('video-x').addEventListener('input', () => updateSetting('videox', $('video-x').value));
    $('video-y').addEventListener('input', () => updateSetting('videoy', $('video-y').value));
    $('video-view-reset').addEventListener('click', () => {
      for (const key of Object.keys(VIDEO_VIEW_CONTROLS)) { settings[key] = defaults[key]; }
      syncVideoViewControls(); syncVideoLayer(); $('background-status').textContent = backgroundVideoLabel();
    });
    $('settings-toggle').addEventListener('click', () => {
      $('settings').hidden = !$('settings').hidden;
      $('settings-toggle').setAttribute('aria-expanded', String(!$('settings').hidden));
      draw();
    });
    // 通用滑杆：settings 键名 == 元素 id。video-* 三项的 id 带连字符，已在上面单独绑定，
    // 必须跳过，否则 $('videoscale') 取到 null 会在初始化时直接抛错、整个脚本挂掉。
    for (const key of Object.keys(ranges)) {
      if (key in VIDEO_VIEW_CONTROLS) continue;
      const input = $(key); if (!input) continue;
      input.addEventListener('input', () => updateSetting(key, $(key).value));
    }
    $('selected-doll').addEventListener('change', () => { selectedDoll = Number($('selected-doll').value); syncSelection(); draw(); });
    $('individual-size').addEventListener('input', () => updateSetting('dollsize' + (selectedDoll + 1), $('individual-size').value));
    $('individual-reset').addEventListener('click', () => updateSetting('dollsize' + (selectedDoll + 1), 0));
    $('individual-image').addEventListener('change', () => {
      const wanted = $('individual-image').value;
      updateSetting('dollfile' + (selectedDoll + 1), ''); updateSetting('dollimage' + (selectedDoll + 1), wanted);
    });
    $('custom-doll-file').addEventListener('change', () => {
      const file = $('custom-doll-file').files[0]; if (!file) return;
      if (!file.type.startsWith('image/') && !/\.(png|jpe?g|webp|gif|svg|bmp)$/i.test(file.name)) return;
      const url = URL.createObjectURL(file);
      settings['dollfile' + (selectedDoll + 1)] = url; setCustomDoll(selectedDoll, url, file.name, url);
      $('custom-doll-file').value = '';
    });
    $('custom-doll-clear').addEventListener('click', () => updateSetting('dollfile' + (selectedDoll + 1), ''));
    $('individual-image-reset').addEventListener('click', () => {
      updateSetting('dollfile' + (selectedDoll + 1), ''); updateSetting('dollimage' + (selectedDoll + 1), pickImage(selectedDoll));
    });
    $('all-images').addEventListener('click', () => {
      releaseDrag(false);
      for (let i = 0; i < defaults.count; i++) { settings['dollimage' + (i + 1)] = pickImage(i); updateSetting('dollfile' + (i + 1), ''); }
      configure(); draw();
    });
    $('highlight').addEventListener('change', () => { highlight = $('highlight').checked; draw(); });
    $('stationary').addEventListener('change', () => updateSetting('stationary', $('stationary').checked));
    $('motion-resume').addEventListener('click', () => {
      releaseDrag(false); userPaused = false; $('pause').textContent = '暂停动画';
      updateSetting('stationary', false);
      if (settings.speed === 0) updateSetting('speed', defaults.speed);
      syncMotionState(); resume();
    });
    $('rearrange').addEventListener('click', () => { releaseDrag(false); world.rearrange(); draw(); });
    $('reroll-spin').addEventListener('click', () => {
      releaseDrag(false);
      for (const body of world.bodies) if (!body.dragged) world.chooseSpin(body);
    });
    $('collisions').addEventListener('change', () => updateSetting('collisions', $('collisions').checked));
    $('demo').addEventListener('change', () => {
      demo = $('demo').checked; if (demo) player.pause();
      $('audio-status').textContent = demo ? '节奏演示 · 模拟 120 BPM' : '音乐已暂停 · 可点播放';
    });
    $('pause').addEventListener('click', () => {
      releaseDrag(false); userPaused = !userPaused; $('pause').textContent = userPaused ? '继续动画' : '暂停动画'; syncMotionState(); resume();
    });
    $('reset').addEventListener('click', () => {
      releaseDrag(false); Object.assign(settings, defaults); demo = false; $('demo').checked = false;
      for (let i = 0; i < customDolls.length; i++) setCustomDoll(i, '');
      userPaused = false; $('pause').textContent = '暂停动画';
      for (const key of Object.keys(ranges)) { $(key).value = settings[key]; $(key + '-value').value = formatValue(key, settings[key]); }
      selectedDoll = 0; highlight = true; $('highlight').checked = true; $('stationary').checked = false;
      $('collisions').checked = true; envelope = 0; beatPulse.reset(); world.bodies = []; configure(); draw(); resume(); loadDefaultMusic();
      $('background-color').value = defaults.backgroundcolor; $('background-fit').value = defaults.backgroundfit;
      $('background-image').value = ''; setBackgroundImage('');
      $('background-mode').value = defaults.backgroundmode; $('video-fit').value = defaults.videofit;
      syncVideoViewControls(); syncVideoLayer();
      $('render-quality').value = String(defaults.renderquality); resize();
      $('video-enabled').checked = defaults.videoenabled; $('video-audio').checked = defaults.videoaudio;
      setBackgroundVideo(BACKGROUND_VIDEO_FILE, BACKGROUND_VIDEO_LABEL); syncSelection();
    });
  }
  $('music-start').addEventListener('click', () => { demo = false; $('demo').checked = false; settings.musicenabled = true; playMusic(); });
  player.addEventListener('play', () => {
    beatPulse.reset();
    demo = false; $('demo').checked = false; $('music-start').hidden = true;
    try { initAudio(); if (audioContext) audioContext.resume().catch(() => {}); } catch {}
  });
  player.addEventListener('error', () => {
    musicFailure = '音乐未能加载：' + musicName + '。请检查 assets/default-music.mp3 是否随包分发。';
    $('audio-status').textContent = musicFailure; syncAssetNotice();
  });
  window.addEventListener('resize', resize);
  document.addEventListener('visibilitychange', () => {
    releaseDrag(false); resume();
    // 回到前台时补一次播放：音频和视频在后台被浏览器暂停后不会自己恢复。
    if (!document.hidden && settings.musicenabled && player.paused && !enginePaused && !demo) playMusic();
    if (!document.hidden && backgroundVideo && backgroundVideo.paused && settings.backgroundmode === 'video' && settings.videoenabled) playBackgroundVideo();
  });
  window.addEventListener('pagehide', () => {
    for (const record of customDolls) { ++record.request; disposeCustomDoll(record); }
    if (backgroundURL) URL.revokeObjectURL(backgroundURL);
  });
  loadSprites();
  // 启动只加载内置默认音乐，不做任何 IndexedDB 恢复（自选音乐功能已移除）。
  resize(); resume(); loadDefaultMusic();
  // 默认背景就是循环播放的内置视频；视频不可用时自动回退到纯色。
  setBackgroundVideo(BACKGROUND_VIDEO_FILE, BACKGROUND_VIDEO_LABEL);
  // 测试用只读钩子：仅暴露物理世界与节拍脉冲供自动化验证读取，不影响画面逻辑。
  window.__wbTest = { world, beatPulse, settings, configure, draw, videoTransform,
    backgroundVideo: () => backgroundVideo, videoHold: () => videoHold, videoBackgroundActive, playBackgroundVideo, syncVideoLayer };
})();

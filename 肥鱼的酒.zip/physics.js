(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.DollPhysics = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  function deformationCycle(phase) {
    const smooth = t => t * t * (3 - 2 * t);
    if (phase < 0.44) return 1;
    if (phase < 0.60) return 1 - 2 * smooth((phase - 0.44) / 0.16);
    if (phase < 0.88) return -1;
    return -1 + smooth(clamp((phase - 0.88) / 0.12, 0, 1));
  }
  class BeatPulse {
    constructor() { this.reset(); }
    reset() { this.previous = 0; this.baseline = 0; this.pulse = 0; this.lastBeat = -Infinity; this.cycleAt = null; this.pending = false; }
    step(level, dt, now, sensitivity = 1) {
      level = clamp(level, 0, 1);
      this.baseline += (level - this.baseline) * (1 - Math.exp(-dt / 0.4));
      const rise = level - this.previous;
      if (level > 0.035 / sensitivity && rise > Math.max(0.015, this.baseline * 0.035) / sensitivity && now - this.lastBeat > 120) {
        this.pending = true; this.lastBeat = now;
      }
      this.previous = level;
      // Finish each full-amplitude cycle. Nearby beats queue one next cycle rather than interrupting it.
      if (this.cycleAt === null || now - this.cycleAt >= 500) {
        this.cycleAt = this.pending ? now : null; this.pending = false;
      }
      if (this.cycleAt === null) this.pulse = 0;
      else {
        this.pulse = deformationCycle((now - this.cycleAt) / 500);
      }
      return this.pulse;
    }
  }
  class World {
    constructor(random = Math.random) {
      this.random = random; this.width = 1; this.height = 1; this.size = 180; this.speed = 85; this.bodies = [];
      this.rotation = 1; this.decay = 3; this.dragAnimation = 1; this.stretch = 0.15; this.stationary = false;
      this.collisionScale = 0.46; this.spinMin = 0.45; this.spinMax = 1.35; this.beatBoost = 0.8;
      this.ejected = [];
    }
    chooseSpin(body) {
      const low = Math.min(this.spinMin, this.spinMax), high = Math.max(this.spinMin, this.spinMax);
      body.restSpin = (this.random() < 0.5 ? -1 : 1) * (low + this.random() * (high - low));
      body.spin = body.restSpin;
    }
    configure(width, height, size, speed, count, sizes = []) {
      this.width = Math.max(1, width); this.height = Math.max(1, height);
      const previousSpeed = this.speed; this.speed = speed;
      const cols = Math.min(count, Math.ceil(Math.sqrt(count * this.width / this.height)));
      const rows = Math.ceil(count / cols);
      const requested = Array.from({ length: count }, (_, i) => sizes[i] || size);
      const largest = Math.max(...requested);
      const fit = Math.min(1, this.width / cols / 1.45 / largest, this.height / rows / 1.45 / largest);
      this.size = size * fit;
      const radius = this.size * 0.60;
      if (this.bodies.length !== count) {
        const previous = this.bodies;
        this.bodies = Array.from({ length: count }, (_, i) => {
          if (previous[i]) return previous[i];
          const direction = this.random() * Math.PI * 2;
          const body = { x: ((i % cols) + 0.5) * this.width / cols,
            y: (Math.floor(i / cols) + 0.5) * this.height / rows,
            vx: Math.cos(direction) * speed, vy: Math.sin(direction) * speed,
            r: radius, angle: 0, spin: 0, squash: 0, spring: 0, dragged: false, boost: false,
            squeeze: 0, squeezeDir: null, ejectCharge: 0, previousSqueeze: 0,
            dragCharge: 0, dragTime: 0, dragMoved: 0 };
          this.chooseSpin(body); return body;
        });
      }
      for (const [i, body] of this.bodies.entries()) {
        body.size = requested[i] * fit; body.r = body.size * this.collisionScale;
        if (previousSpeed !== speed && !body.dragged && !body.boost) this.setSpeed(body, speed);
        this.walls(body, false);
      }
      for (let pass = 0; pass < 20; pass++) this.resolve(false, 1 / 120, false);
    }
    rearrange() {
      const cols = Math.min(this.bodies.length, Math.ceil(Math.sqrt(this.bodies.length * this.width / this.height)));
      const rows = Math.ceil(this.bodies.length / cols);
      for (const [i, body] of this.bodies.entries()) {
        body.x = ((i % cols) + 0.5) * this.width / cols;
        body.y = (Math.floor(i / cols) + 0.5) * this.height / rows;
        body.boost = false; this.setSpeed(body, this.speed); this.walls(body, false);
      }
      for (let pass = 0; pass < 20; pass++) this.resolve(false, 1 / 120, false);
    }
    setSpeed(body, speed) {
      const current = Math.hypot(body.vx, body.vy);
      if (current > 0.0001) { body.vx *= speed / current; body.vy *= speed / current; }
      else { const direction = this.random() * Math.PI * 2; body.vx = Math.cos(direction) * speed; body.vy = Math.sin(direction) * speed; }
    }
    geometry(body) {
      const size = body.size || this.size;
      const aspect = Number.isFinite(body.imageAspect) && body.imageAspect > 0 ? body.imageAspect : 1;
      const baseWidth = size * Math.min(1, aspect), baseHeight = size / Math.max(1, aspect);
      let width = baseWidth * (1 + body.squash), height = baseHeight * (1 - body.squash);
      const c = Math.abs(Math.cos(body.angle)), s = Math.abs(Math.sin(body.angle));
      const fit = Math.min(1, this.width * 0.9 / (width * c + height * s), this.height * 0.9 / (width * s + height * c));
      // Keep rotation and compression inside the viewport without changing their proportions.
      width *= fit; height *= fit;
      const offsetY = (baseHeight * fit - height) / 2;
      return { width, height, offsetY, dx: -offsetY * Math.sin(body.angle), dy: offsetY * Math.cos(body.angle),
        hx: (width * c + height * s) / 2, hy: (width * s + height * c) / 2 };
    }
    walls(body, bounce = true) {
      const geometry = this.geometry(body);
      const left = Math.max(body.r, geometry.hx - geometry.dx), right = this.width - Math.max(body.r, geometry.hx + geometry.dx);
      const top = Math.max(body.r, geometry.hy - geometry.dy), bottom = this.height - Math.max(body.r, geometry.hy + geometry.dy);
      let hit = false;
      if (body.x < left) { body.x = left; if (bounce && body.vx < 0) { body.vx = -body.vx; hit = true; } }
      if (body.x > right) { body.x = right; if (bounce && body.vx > 0) { body.vx = -body.vx; hit = true; } }
      if (body.y < top) { body.y = top; if (bounce && body.vy < 0) { body.vy = -body.vy; hit = true; } }
      if (body.y > bottom) { body.y = bottom; if (bounce && body.vy > 0) { body.vy = -body.vy; hit = true; } }
      if (hit && !body.dragged) this.chooseSpin(body);
    }
    resolve(bounce = true, h = 1 / 120, live = true) {
      for (const body of this.bodies) if (!body.dragged) body.squeeze = 0;
      for (let i = 0; i < this.bodies.length; i++) for (let j = i + 1; j < this.bodies.length; j++) {
        const a = this.bodies[i], b = this.bodies[j];
        let dx = b.x - a.x, dy = b.y - a.y;
        const dist = Math.hypot(dx, dy), min = a.r + b.r;
        if (dist >= min) continue;
        if (dist < 0.0001) { dx = 1; dy = 0; }
        const nx = dx / (dist < 0.0001 ? 1 : dist), ny = dy / (dist < 0.0001 ? 1 : dist);
        const ia = a.dragged ? 0 : 1 / (a.r * a.r), ib = b.dragged ? 0 : 1 / (b.r * b.r), total = ia + ib;
        if (!total) continue;
        const overlap = min - dist;
        const correction = (overlap + 0.001) / total;
        a.x -= nx * correction * ia; a.y -= ny * correction * ia;
        b.x += nx * correction * ib; b.y += ny * correction * ib;
        // 被抓住的娃娃顶住别人时：压得越深越扁，逼到墙角就攒“弹出去”的力气。
        const pressed = this.size * 0.5;
        if (overlap > pressed * 0.06) {
          const pressure = Math.min(1, (overlap - pressed * 0.06) / (pressed * 0.94));
          if (a.dragged && !b.dragged) { b.squeeze = Math.max(b.squeeze || 0, pressure); b.squeezeDir = { x: nx, y: ny }; }
          else if (b.dragged && !a.dragged) { a.squeeze = Math.max(a.squeeze || 0, pressure); a.squeezeDir = { x: -nx, y: -ny }; }
        }
        const closing = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
        if (bounce && closing < 0) {
          const impulse = 2 * closing / total;
          a.vx += impulse * nx * ia; a.vy += impulse * ny * ia;
          b.vx -= impulse * nx * ib; b.vy -= impulse * ny * ib;
          // Different masses change both speeds; let each smoothly return to its normal speed.
          if (ia && Math.abs(Math.hypot(a.vx, a.vy) - this.speed) > 0.1) a.boost = true;
          if (ib && Math.abs(Math.hypot(b.vx, b.vy) - this.speed) > 0.1) b.boost = true;
        }
      }
      for (const body of this.bodies) {
        this.walls(body, bounce);
        // 贴到墙角且还被压扁时，攒够进度就从侧边“啵”地弹出。
        // live=false 用于布局/重排的迭代求解，不参与弹出判定。
        if (live) this.eject(body, h);
      }
    }
    // 被挤到角落的娃娃：压力 + 贴边持续累积，达到阈值后朝空的法线方向一次性弹走。
    eject(body, h = 1 / 120) {
      if (body.dragged) { body.ejectCharge = 0; return; }
      const squeeze = body.squeeze || 0;
      if (squeeze < 0.35) { body.ejectCharge = (body.ejectCharge || 0) * 0.92; return; }
      const dir = body.squeezeDir || { x: 0, y: 0 };
      // 累积速度和正常速度脱钩，保证任何速度设置下都大约要憋 0.6～1 秒才会弹。
      const rate = 1.6 * h;
      body.ejectCharge = (body.ejectCharge || 0) + squeeze * rate;
      if (body.ejectCharge < 1) return;
      body.ejectCharge = 0; body.squeeze = 0;
      // 朝被压的反方向弹，贴边时把朝墙的那一半速度折回，保证能真正离开角落。
      let ex = dir.x, ey = dir.y;
      const canvas = this.geometry(body);
      const wallHit = [];
      if (body.x <= Math.max(body.r, canvas.hx - canvas.dx) + 1) wallHit.push('l');
      if (body.x >= this.width - Math.max(body.r, canvas.hx + canvas.dx) - 1) wallHit.push('r');
      if (body.y <= Math.max(body.r, canvas.hy - canvas.dy) + 1) wallHit.push('t');
      if (body.y >= this.height - Math.max(body.r, canvas.hy + canvas.dy) - 1) wallHit.push('b');
      if (wallHit.length) { if (wallHit.includes('l') && ex < 0) ex = 0; if (wallHit.includes('r') && ex > 0) ex = 0;
        if (wallHit.includes('t') && ey < 0) ey = 0; if (wallHit.includes('b') && ey > 0) ey = 0; }
      const len = Math.hypot(ex, ey) || 1;
      const launch = clamp(this.speed * 9, 420, 1400);
      body.vx = ex / len * launch; body.vy = ey / len * launch;
      body.boost = true;
      if (this.ejected) this.ejected.push(body);
    }
    // 测试与调试用：返回本帧真正弹出的娃娃并清空队列。
    takeEjected() { const out = this.ejected || []; this.ejected = []; return out; }
    beginDrag(body, grip = null) {
      body.dragged = true; body.vx = 0; body.vy = 0; body.boost = false;
      body.grip = grip;
      body.dragPhase = 0;
      body.dragSpeed = 0; body.previousDragVx = 0; body.previousDragVy = 0;
      // 拖拽时间越长、走过的距离越远，旋转越猛：用 dragCharge 累积一个 0→1 的进度。
      body.dragCharge = 0; body.dragTime = 0;
      body.dragSpinTarget = Math.sign(body.spin || 1) * Math.max(1.2, Math.abs(body.spin) * 3);
      body.dragSpin = body.dragSpinTarget;
    }
    dragMotion(body, vx, vy, offsetX = 0, offsetY = 0) {
      const speed = Math.hypot(vx, vy); if (speed < 2) return;
      const previous = Math.hypot(body.previousDragVx, body.previousDragVy);
      const turn = previous > 10 ? (body.previousDragVx * vy - body.previousDragVy * vx) / (previous * speed) : 0;
      const torque = offsetX * vy - offsetY * vx;
      let direction;
      if (Math.abs(turn) > 0.06) direction = Math.sign(turn);
      else if (Math.abs(torque) > speed * (body.size || this.size) * 0.02) direction = Math.sign(torque);
      else direction = Math.sign(Math.abs(vx) >= Math.abs(vy) ? vx : vy);
      // 鼠标越快给的基础转速越高；具体倍数在 step 里再按 dragCharge 逐渐放大。
      body.dragSpinTarget = direction * (1.2 + Math.min(speed / 130, 10));
      body.dragSpeed = Math.min(speed, 3000);
      body.dragMoved = (body.dragMoved || 0) + speed;
      body.previousDragVx = vx; body.previousDragVy = vy;
    }
    moveDrag(body, x, y) { body.x = x; body.y = y; this.walls(body, false); }
    dragPointer(body, x, y) {
      if (!body.grip) return;
      body.grip.x = x; body.grip.y = y; this.followPointer(body);
    }
    followPointer(body) {
      const g = this.geometry(body), grip = body.grip;
      const lx = (grip.u - 0.5) * g.width, ly = g.offsetY + (grip.v - 0.5) * g.height;
      const c = Math.cos(body.angle), s = Math.sin(body.angle);
      body.x = grip.x - (lx * c - ly * s); body.y = grip.y - (lx * s + ly * c);
      this.walls(body, false);
    }
    endDrag(body, vx = 0, vy = 0) {
      if (body.dragged) {
        body.spin = body.dragSpin;
        body.restSpin = Math.sign(body.spin || 1) * Math.abs(body.restSpin);
      }
      body.dragged = false; body.grip = null; body.vx = vx; body.vy = vy;
      if (this.stationary) { this.setSpeed(body, this.speed); body.boost = false; return; }
      const speed = Math.hypot(vx, vy);
      this.setSpeed(body, clamp(speed, this.speed, 2000));
      body.boost = Math.hypot(body.vx, body.vy) > this.speed + 0.1;
    }
    step(dt, collisions, targetSquash, squashStrength = targetSquash, beatBoost = 0) {
      targetSquash = clamp(targetSquash, -this.stretch, 0.55);
      squashStrength = clamp(squashStrength, 0, 0.55);
      beatBoost = clamp(beatBoost, 0, 1);
      // 节拍加速：按节拍脉冲把整体速度连续推高，脉冲结束后交给下面的 decay 平滑回落。
      const boostTarget = this.speed * (1 + this.beatBoost * beatBoost);
      if (beatBoost > 0.01) for (const body of this.bodies) {
        if (body.dragged) continue;
        const current = Math.hypot(body.vx, body.vy);
        if (current < boostTarget) {
          this.setSpeed(body, Math.min(boostTarget, current + (boostTarget - current) * (1 - Math.exp(-dt / 0.05))));
          body.boost = true;
        }
      }
      const fastest = Math.max(this.speed, boostTarget, ...this.bodies.map(b => Math.hypot(b.vx, b.vy)));
      const smallest = Math.min(this.size, ...this.bodies.map(b => b.size || this.size));
      const steps = Math.max(1, Math.ceil(dt / (1 / 120)), Math.ceil(fastest * dt / Math.max(1, smallest * 0.2)));
      const h = dt / steps;
      for (let k = 0; k < steps; k++) {
        for (const body of this.bodies) {
          if (!body.dragged) {
            if (body.boost && beatBoost <= 0.01) {
              const current = Math.hypot(body.vx, body.vy);
              const next = this.speed + (current - this.speed) * Math.exp(-4.8 / this.decay * h);
              this.setSpeed(body, next);
              if (Math.abs(next - this.speed) < 0.1) { this.setSpeed(body, this.speed); body.boost = false; }
            }
            if (!this.stationary) { body.x += body.vx * h; body.y += body.vy * h; }
            body.spin += (body.restSpin - body.spin) * (1 - Math.exp(-1.8 * h));
            body.angle = (body.angle + body.spin * this.rotation * h) % (Math.PI * 2);
          } else {
            body.dragSpeed *= Math.exp(-h / 0.12);
            // 拖拽越久、动得越多，旋转越猛：dragCharge 从 0 慢慢爬到 1，转速随之上不封顶地放大。
            body.dragTime = (body.dragTime || 0) + h;
            body.dragMoved = (body.dragMoved || 0) * Math.exp(-h / 1.2);
            const chargeTarget = Math.min(1, body.dragTime / 1.6) * 0.7 + Math.min(1, body.dragMoved / 2600) * 0.3;
            body.dragCharge = (body.dragCharge || 0) + (chargeTarget - (body.dragCharge || 0)) * (1 - Math.exp(-h / 0.55));
            const ramp = 1 + body.dragCharge * 5.5;
            const idleSpin = Math.sign(body.dragSpinTarget || 1) * 1.2 * ramp;
            body.dragSpinTarget += (idleSpin - body.dragSpinTarget) * (1 - Math.exp(-h / 0.18));
            body.dragSpin += (body.dragSpinTarget - body.dragSpin) * (1 - Math.exp(-h / 0.035));
            body.angle = (body.angle + body.dragSpin * this.rotation * h) % (Math.PI * 2);
          }
          if (body.dragged) {
            const dragResponse = 0.025 / this.dragAnimation / (1 + Math.min(body.dragSpeed / 800, 1));
            body.dragPhase = (body.dragPhase + h * 2 * this.dragAnimation * (1 + Math.min(body.dragSpeed / 1800, 0.55))) % 1;
            const cycle = deformationCycle(body.dragPhase);
            const dragTarget = squashStrength === 0 ? 0 : cycle * (cycle >= 0 ? squashStrength : this.stretch);
            body.squash += (dragTarget - body.squash) * (1 - Math.exp(-h / dragResponse)); body.spring = 0;
          } else if ((body.squeeze || 0) > 0.02) {
            // 被顶住时放弃节拍弹簧，改成持续压扁：越挤越扁，最多压到上限。
            const targetSqueezed = Math.min(0.5, 0.14 + body.squeeze * 0.38);
            const speed = body.squeeze > (body.previousSqueeze || 0) ? 0.035 : 0.25;
            body.squash += (targetSqueezed - body.squash) * (1 - Math.exp(-h / speed));
            body.spring = 0;
          } else {
            body.spring += (1000 * (targetSquash - body.squash) - 52 * body.spring) * h;
            body.squash = clamp(body.squash + body.spring * h, -this.stretch, 0.55);
          }
          body.previousSqueeze = body.squeeze || 0;
          body.squash = clamp(body.squash, -this.stretch, 0.55);
          if ((body.squash <= -this.stretch && body.spring < 0) || (body.squash >= 0.55 && body.spring > 0)) body.spring = 0;
          if (body.dragged && body.grip) this.followPointer(body);
          this.walls(body);
        }
        if (collisions) for (let pass = 0; pass < 3; pass++) this.resolve(!this.stationary, h, true);
      }
    }
  }
  return { World, BeatPulse, deformationCycle, clamp };
});

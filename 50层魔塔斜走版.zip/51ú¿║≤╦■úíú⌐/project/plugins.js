var plugins_bb40132b_638b_4a9f_b028_d3fe47acc8d1 = 
{
    "init": function () {

		console.log("插件编写测试");

		this._afterLoadResources = function () {
			// 本函数将在所有资源加载完毕后，游戏开启前被执行
			// 可以在这个函数里面对资源进行一些操作。
			// 若需要进行切分图片，可以使用 core.splitImage() 函数，或直接在全塔属性-图片切分中操作
			// 
			core.ui.statusBar.init();
		}

		// 可以在任何地方（如afterXXX或自定义脚本事件）调用函数，方法为 core.plugin.xxx();
		// 从V2.6开始，插件中用this.XXX方式定义的函数也会被转发到core中，详见文档-脚本-函数的转发。
	},
    "resizeTo11": function () {
		if (main.mode == 'editor') {
			return;
		}

		// 在不修改libs的情况下将页面适配为11x11
		core.__SIZE__ = 11;
		core.__PIXELS__ = core.__SIZE__ * 32;
		core.__HALF_SIZE__ = 5;
		// core.bigmap.width = core.__SIZE__;
		// core.bigmap.height = core.__SIZE__;
		core.actions.SIZE = core.__SIZE__;
		core.actions.HSIZE = core.__HALF_SIZE__;
		core.actions.LAST = core.__SIZE__ - 1;
		core.actions.CHOICES_LEFT = 3;
		core.actions.CHOICES_RIGHT = core.actions.LAST - core.actions.CHOICES_LEFT;
		core.ui.SIZE = core.__SIZE__;
		core.ui.HSIZE = core.__HALF_SIZE__;
		core.ui.LAST = core.__SIZE__ - 1;
		core.ui.PIXEL = core.__PIXELS__;
		core.ui.HPIXEL = core.__PIXELS__ / 2;
	},
    "statusBar": function () {
	main.dom.floorMsgGroup.style.display = 'none';
	main.dom.statusBar.style.display = 'none';
	main.dom.toolBar.style.display = 'none';

	var outerBackground = document.createElement('canvas');
	outerBackground.style.position = 'absolute';
	outerBackground.style.zIndex = 5;
	outerBackground.width = 640;
	outerBackground.height = 422;
	outerBackground.id = 'outerBackground';
	main.dom.outerBackground = outerBackground;
	main.dom.startPanel.insertAdjacentElement('afterend', outerBackground);

	var outerUI = document.createElement('canvas');
	outerUI.style.position = 'absolute';
	outerUI.style.zIndex = 165;
	outerUI.width = 640;
	outerUI.height = 422;
	outerUI.id = 'outerUI';
	main.dom.outerUI = outerUI;
	outerBackground.insertAdjacentElement('afterend', outerUI);
	setTimeout(function () {
		// Should be executed immediately after init()
		main.canvas.outerUI = outerUI.getContext('2d');
	});
	outerUI.onclick = function (e) {
		try {
			e.preventDefault();
			if (!core.isPlaying()) return false;
			var left = core.dom.gameGroup.offsetLeft + 3;
			var top = core.dom.gameGroup.offsetTop + 3;
			var px = parseInt((e.clientX - left) / core.domStyle.scale),
				py = parseInt((e.clientY - top) / core.domStyle.scale);
			core.ui.statusBar.onclick(px, py);
		} catch (ee) {
			main.log(ee);
		}
	}

	var _resize_gameGroup = function (obj) {
		var gameGroup = core.dom.gameGroup;
		gameGroup.style.width = obj.totalWidth + "px";
		gameGroup.style.height = obj.totalHeight + "px";
		gameGroup.style.left = (obj.clientWidth - obj.totalWidth) / 2 + "px";
		gameGroup.style.top = (obj.clientHeight - obj.totalHeight) / 2 + "px";

		core.dom.musicBtn.style.right = (obj.clientWidth - obj.totalWidth) / 2 + "px";
		core.dom.musicBtn.style.bottom = (obj.clientHeight - obj.totalHeight) / 2 - 27 + "px";
		core.dom.enlargeBtn.style.right = (obj.clientWidth - obj.totalWidth) / 2 + 31 + "px";
		core.dom.enlargeBtn.style.bottom = (obj.clientHeight - obj.totalHeight) / 2 - 27 + "px";

		main.dom.startBackground.src = main.styles.startBackground;
	}

	var _resize_canvas = function (obj) {
		main.dom.outerBackground.style.width = obj.totalWidth + 'px';
		main.dom.outerBackground.style.height = obj.totalHeight + 'px';
		main.dom.outerUI.style.width = obj.totalWidth + 'px';
		main.dom.outerUI.style.height = obj.totalHeight + 'px';

		var innerSize = (obj.canvasWidth * core.domStyle.scale) + "px";
		for (var i = 0; i < core.dom.gameCanvas.length; ++i)
			core.dom.gameCanvas[i].style.width = core.dom.gameCanvas[i].style.height = innerSize;
		core.dom.gif.style.width = core.dom.gif.style.height = innerSize;
		core.dom.gif2.style.width = core.dom.gif2.style.height = innerSize;
		core.dom.gameDraw.style.width = core.dom.gameDraw.style.height = innerSize;
		core.dom.gameDraw.style.top = obj.borderHeight * core.domStyle.scale + "px";
		core.dom.gameDraw.style.right = (obj.borderWidth + obj.barWidth + 1) * core.domStyle.scale + "px";

		// resize bigmap
		core.bigmap.canvas.forEach(function (cn) {
			var ratio = core.canvas[cn].canvas.hasAttribute('isHD') ? core.domStyle.ratio : 1;
			core.canvas[cn].canvas.style.width = core.canvas[cn].canvas.width / ratio * core.domStyle.scale + "px";
			core.canvas[cn].canvas.style.height = core.canvas[cn].canvas.height / ratio * core.domStyle.scale + "px";
		});
		// resize dynamic canvas
		for (var name in core.dymCanvas) {
			var ctx = core.dymCanvas[name],
				canvas = ctx.canvas;
			var ratio = canvas.hasAttribute('isHD') ? core.domStyle.ratio : 1;
			canvas.style.width = canvas.width / ratio * core.domStyle.scale + "px";
			canvas.style.height = canvas.height / ratio * core.domStyle.scale + "px";
			canvas.style.left = parseFloat(canvas.getAttribute("_left")) * core.domStyle.scale + "px";
			canvas.style.top = parseFloat(canvas.getAttribute("_top")) * core.domStyle.scale + "px";
		}
		// resize next
		main.dom.next.style.width = main.dom.next.style.height = 5 * core.domStyle.scale + "px";
		main.dom.next.style.borderBottomWidth = main.dom.next.style.borderRightWidth = 4 * core.domStyle.scale + "px";

	}

	core.control.resize = function () {
		if (main.mode == 'editor') return;

		var clientWidth = main.dom.body.clientWidth,
			clientHeight = main.dom.body.clientHeight;
		var canvasWidth = core.__PIXELS__,
			barWidth = 125;
		var borderWidth = 19,
			borderHeight = 24,
			infoBarHeight = 22;

		var horizontalMaxRatio = clientHeight / (canvasWidth + infoBarHeight + 2 * borderHeight);

		core.domStyle.isVertical = false;
		core.domStyle.availableScale = [];
		[1, 1.25, 1.5, 1.75, 2].forEach(function (v) {
			if (clientWidth >= v * (canvasWidth + barWidth * 2 + borderWidth * 2) && horizontalMaxRatio >= v) {
				core.domStyle.availableScale.push(v);
			}
		});

		if (core.domStyle.availableScale.indexOf(core.domStyle.scale) < 0) {
			core.domStyle.scale = Math.min(1, horizontalMaxRatio);
		} else if (core.getLocalStorage('scale') == null && core.domStyle.availableScale.length >= 2) {
			core.domStyle.scale = core.domStyle.availableScale[core.domStyle.availableScale.length - 2];
			core.setLocalStorage('scale', core.domStyle.scale);
		}

		var totalWidth = (canvasWidth + 2 * barWidth + 2 * borderWidth) * core.domStyle.scale;
		var totalHeight = (canvasWidth + 2 * borderHeight + infoBarHeight) * core.domStyle.scale;

		var obj = {
			clientWidth: clientWidth,
			clientHeight: clientHeight,
			canvasWidth: canvasWidth,
			barWidth: barWidth,
			borderWidth: borderWidth,
			borderHeight: borderHeight,
			infoBarHeight: infoBarHeight,
			totalWidth: totalWidth,
			totalHeight: totalHeight,
			globalAttribute: core.status.globalAttribute || core.initStatus.globalAttribute,
		};

		_resize_gameGroup(obj);
		_resize_canvas(obj);

		if (core.status.automaticRoute == null) core.status.automaticRoute = {};
		core.control.setViewport(32, 32);
		core.updateStatusBar();
	}

	function statusBar() {
		this.itemMx = [
			["book", "wand", "fly"],
			["cross", "superPotion", "pickaxe"],
			["bomb", "centerFly", "upFly"],
			["downFly", "knife", "snow"],
			["bigKey", "earthquake", "coin"],
		];
	}

	statusBar.prototype.init = function () {
		var bgctx = document.getElementById("outerBackground").getContext("2d");
		var bg = core.material.images.images["statusBackground.jpg"];
		bgctx.drawImage(bg, 0, 0, 640, 400);
		bgctx.fillStyle = "#676767";
		bgctx.fillRect(0, 400, 640, 22);
		core.setTextAlign('outerUI', 'center');

		this.toolbarAction = [
			[main.core.openKeyBoard, main.core.openQuickShop, function () { core.insertAction([{ type: "insert", name: "游戏说明" }]); }],
			[main.core.save, main.core.load, main.core.openSettings]
		];
		this.replayAction = [
			[core.triggerReplay, core.stopReplay, core.rewindReplay],
			[core.speedDownReplay, core.speedUpReplay, core.saveReplay]
		];
	}

	statusBar.prototype.update = function () {
		this._update_props();
		this._update_items();
		this._update_equips();
		this._update_keys();
		this._update_infoWindow();
	}

	// 更新属性
	statusBar.prototype._update_props = function (updatedFloorTitle) {
		core.clearMap("outerUI", 10, 0, 105, 170);
		var tc = "#E1E1E1";
		core.setFont("outerUI", 'bold 16px Verdana');
		// 设置楼层名
		if (!updatedFloorTitle && core.status.floorId) {
			updatedFloorTitle = core.status.maps[core.status.floorId].title;
		}
		if (updatedFloorTitle) {
			core.fillText("outerUI", updatedFloorTitle, 62, 61, tc);
		}

		var statusList = ['hp', 'atk', 'def', 'money'];
		var curh = 93;
		core.setTextAlign('outerUI', 'right');
		statusList.forEach(function (item) {
			// 四舍五入
			core.status.hero[item] = Math.round(core.status.hero[item]);
			// 大数据格式化
			core.fillText("outerUI", core.getRealStatus(item), 110, curh, tc);
			curh += 24;
		});
		var nandu = core.getFlag("nandu", 0);
		var nandu2 = core.getFlag("难度", "");
		var nandu3 = core.getFlag("难度颜色", "#000000");
		core.setTextAlign('outerUI', 'center');
		if (nandu != 0) {
			core.fillText("outerUI", nandu2, 61, 29, nandu3);
		}
	}

	statusBar.prototype._update_items = function () {
		core.clearMap("outerUI", 10, 180, 105, 185);
		for (var i = 0; i < this.itemMx.length; i++) {
			for (var j = 0; j < this.itemMx[i].length; j++) {
				var item = this.itemMx[i][j];
				if (core.hasItem(item)) {
					var icon = core.material.icons.items[item],
						image = core.material.images.items;
					var posx = 13 + j * 33,
						posy = 190 + i * 32;
					core.drawImage('outerUI', image, 0, 32 * icon, 32, 32, posx, posy, 32, 32);
					if (core.itemCount(item) > 1)
						core.fillText('outerUI', core.itemCount(item), posx + 25, posy + 28, '#FFFFFF', "bold 12px Verdana");
					// if (this.selectId == item)
					//     core.strokeRect('outerUI', posx + 17, posy - 4, 40, 40, '#FFD700');
				}
			}
		}
	}

	statusBar.prototype._update_equips = function () {
		core.clearMap("outerUI", 525, 0, 105, 135);
		core.setFont("outerUI", 'bold 16px Verdana');
		//写塔名
		var motaName = core.getFlag("motaName", "");
		core.fillText("outerUI", motaName, 575, 29, "#FFFFFF");

		var drawEquip = function (baseX, baseY, id, color, back) {
			if (!id) core.fillText("outerUI", back, baseX + 50, baseY + 22, color);
			else {
				core.fillText("outerUI", core.material.items[id].name, baseX + 32, baseY + 22, color);
				var icon = core.material.icons.items[id];
				core.drawImage('outerUI', core.material.images.items, 0, 32 * icon, 32, 32, baseX + 64, baseY, 32, 32);
			}
		}
		drawEquip(525, 48, core.getFlag("nowWeapon"), "#FFCFAE", "无武器");
		drawEquip(525, 96, core.getFlag("nowShield"), "#D1CEFF", "无防具");
	}

	statusBar.prototype._update_keys = function () {
		core.clearMap("outerUI", 525, 140, 105, 75);
		var todraw = [],
			keyList = ['yellowKey', 'blueKey', 'redKey'];
		keyList.forEach(function (key, i) {
			todraw[i] = core.itemCount(key);
		});
		var baseX = 528,
			baseY = 142,
			dn = 2,
			dc = 0;
		while (dn >= 0 && dc < 28) {
			if (todraw[dn]) {
				this.drawKey(keyList[dn], baseX + (dc % 7) * 14, baseY + parseInt(dc / 7) * 17);
				todraw[dn]--, dc++;
			} else dn--;
		}
	}

	statusBar.prototype.drawKey = function (key, x, y) {
		var sx = 3,
			sy = 0;
		if (key == "blueKey") sx += 16;
		else if (key == "yellowKey") sy += 16;
		core.drawImage("outerUI", core.statusBar.icons.keys, sx, sy, 10, 16, x, y, 10, 16);
	}

	statusBar.prototype._update_infoWindow = function () {
		core.clearMap("outerUI", 525, 220, 105, 100);
		this.selectedItem = null;
	}

	statusBar.prototype.showInfo = function (itemId) {
		core.clearMap("outerUI", 525, 220, 105, 100);
		var icon = core.material.icons.items[itemId];
		core.fillText("outerUI", core.material.items[itemId].name, 525 + 32, 220 + 25, "#D1CEFF");
		core.drawImage('outerUI', core.material.images.items, 0, 32 * icon, 32, 32, 525 + 64, 224, 32, 32);
		core.ui.drawTextContent("outerUI", core.material.items[itemId].text, {
			left: 526,
			top: 256,
			maxWidth: 105,
			color: "#D1CEFF"
		});
		this.selectedItem = itemId;
	}

	statusBar.prototype._update_toolBox = function () {
		core.clearMap("outerUI", 520, 310, 115, 80);
		var tools = [];
		if (core.isReplaying()) {
			tools = [
				[core.status.replay.pausing ? "play" : "pause", "stop", "rewind"],
				["speedDown", "speedUp", "save"],
			]
		} else {
			tools = [
				["keyboard", "shop", "help"],
				["save", "load", "settings"],
			]
		}
		for (var i = 0; i < tools.length; i++) {
			for (var j = 0; j < tools[i].length; j++) {
				core.drawIcon("outerUI", tools[i][j], 525 + j * 34, 318 + i * 34, 32, 32);
			}
		}
	}

	statusBar.prototype.onclick = function (x, y) {
		if (x <= 112 && x >= 13 && y <= 350 && y >= 190) {
			if (core.isReplaying() || core.status.lockControl || core.isMoving()) return;
			var itemId = this.itemMx[parseInt((y - 190) / 32)][parseInt((x - 13) / 33)];
			if (!core.hasItem(itemId)) return;
			if (core.material.items[itemId].cls == "constants") {
				switch (itemId) {
				case "book":
					core.openBook(true);
					break;
				case "fly":
					core.useFly(true);
					break;
				case "wand":
					core.insertAction({
						type: "useItem",
						id: itemId
					});
					break;
				case "snow":
					core.useItem("snow");
					break;
				default:
					this.showInfo(itemId);
				}
			} else if (itemId != this.selectedItem) {
				this.showInfo(itemId);
			} else {
				switch (itemId) {
				case "centerFly":
					core.ui._drawCenterFly();
					break;
				default:
					core.useItem(itemId);
				}
			}
			return;
		}
		if (x <= 625 && x >= 525 && y <= 382 && y >= 317) {
			var row = parseInt((x - 525) / 32),
				col = parseInt((y - 317) / 32);
			if (core.isReplaying()) {
				this.replayAction[col][row].call(core);
			} else if (core.isPlaying()) {
				this.toolbarAction[col][row].call(core, true);
			}
			return;
		}
	}

	statusBar.prototype.print = function (text, cnt) {
		if (!text) {
			var _this = this;
			setTimeout(function () {
				if (!_this.infocnt) core.clearMap("outerUI", 0, 400, 640, 22);
			}, 200);
			this.infocnt = 0;
			return;
		}
		core.clearMap("outerUI", 0, 400, 640, 22);
		core.setFont("outerUI", 'bold 16px Verdana');
		core.setTextAlign('outerUI', 'left');
		core.fillText("outerUI", text, 10, 416, "#E1E1E1");
		core.setTextAlign('outerUI', 'center');
		this.infocnt = cnt || 1;
	}

	statusBar.prototype.infoRules = [
		{ id: "lava", text: "岩浆好热啊!" },
		{ id: "upFloor", text: "你看到了楼梯" },
		{ id: "downFloor", text: "你看到了楼梯" },
		{ id: "blueShop", text: "你看到了一个祭坛" },
		{ id: "man", text: "你看到了一个老人" },
		{ id: "woman", text: "你看到了一个商人" },
		{ id: "fairy", text: "你看到了一个商人" },
		{ id: "thief", text: "你看到了一个小偷" },
	]

	statusBar.prototype.printEnvironmentInfo = function () {
		if (!this.infocnt) {
			var ids = [];
			for (var i in core.status.thisMap.blocks) {
				var block = core.status.thisMap.blocks[i];
				if (!block.disable && core.nearHero(block.x, block.y)) ids.push(block.event.id);
			}
			for (var i in this.infoRules) {
				if (ids.indexOf(this.infoRules[i].id) >= 0) {
					this.print(this.infoRules[i].text);
					return;
				}
			}
		}
	}

	statusBar.prototype.clearInfo = function (etype) {
		if (this.infocnt == 1) this.print();
		else if (this.infocnt > 1) this.infocnt--;
	}

	core.ui.statusBar = new statusBar();

	core.control.clearStatusBar = function () {
		core.clearMap("outerUI");
	}
	// init() called in `afterLoadResources`.
},
    "override": function () {

		core.statusBar.icons = {
			'floor': 0,
			'name': null,
			'lv': 1,
			'hpmax': 2,
			'hp': 3,
			'atk': 4,
			'def': 5,
			'mdef': 6,
			'money': 7,
			'experience': 8,
			'up': 9,
			'book': 10,
			'fly': 11,
			'toolbox': 12,
			'keyboard': 13,
			'shop': 14,
			'save': 15,
			'load': 16,
			'settings': 17,
			'play': 18,
			'pause': 19,
			'stop': 20,
			'speedDown': 21,
			'speedUp': 22,
			'rewind': 23,
			'equipbox': 24,
			'mana': 25,
			'skill': 26,
			'paint': 27,
			'erase': 28,
			'empty': 29,
			'exit': 30,
			'btn1': 31,
			'btn2': 32,
			'btn3': 33,
			'btn4': 34,
			'btn5': 35,
			'btn6': 36,
			'btn7': 37,
			'btn8': 38,
			'keys': 39,
			'help': 40,
			'battle': 41
		};

		core.actions._clickCenterFly = function (x, y) {
			var posX = core.status.event.data.posX,
				posY = core.status.event.data.posY;
			core.ui.closePanel();
			if (x == posX && y == posY) {
				if (core.canUseItem('centerFly')) {
					core.useItem('centerFly');
				} else {
					core.drawTip('当前不能使用中心对称飞行器');
				}
			} else core.drawTip('取消使用');
		}

		var _clickSL = core.actions._clickSL;
		core.actions._clickSL = function (x, y) {
			var page = core.status.event.data.page,
				offset = core.status.event.data.offset;
			var index = page * 10 + offset;

			// 上一页
			if ((x == this.HSIZE - 1 || x == this.HSIZE - 2) && y == this.LAST) {
				core.ui._drawSLPanel(10 * (page - 1) + offset);
				return;
			}
			// 下一页
			if ((x == this.HSIZE + 1 || x == this.HSIZE + 2) && y == this.LAST) {
				core.ui._drawSLPanel(10 * (page + 1) + offset);
				return;
			}
			if ((x == this.HSIZE - 3 || x == this.HSIZE + 3) && y == this.LAST) {
				return;
			}
			_clickSL.call(this, x, y);
		}

		var _sys_longClick_lockControl = core.actions._sys_longClick_lockControl;
		core.actions._sys_longClick_lockControl = function (x, y) {
			if (!core.status.lockControl) return false;

			// 长按SL上下页快速翻页
			if (["save", "load", "replayLoad", "replayRemain"].indexOf(core.status.event.id) >= 0) {
				if (y == this.LAST && x <= this.HSIZE + 3 && x >= this.HSIZE - 3) {
					core.actions._clickSL(x, y);
					return true;
				}
			}
			return _sys_longClick_lockControl.call(this, x, y);
		}
		core.registerAction('longClick', '_sys_longClick_lockControl', core.actions._sys_longClick_lockControl, 50);

		core.control._moveHero_moving = function () {
			core.status.heroStop = false;
			core.status.automaticRoute.moveDirectly = false;
			var move = function () {
				if (!core.status.heroStop) {
					if (core.hasFlag('debug') && core.status.ctrlDown) {
						if (core.status.heroMoving != 0) return;
						// 检测是否穿出去
						var nx = core.nextX(),
							ny = core.nextY();
						if (nx < 1 || nx >= core.bigmap.width - 1 || ny < 1 || ny >= core.bigmap.height - 1) return;
						core.eventMoveHero([core.getHeroLoc('direction')], core.values.moveSpeed, move);
					} else {
						core.moveAction();
						setTimeout(move, 50);
					}
				}
			}
			move();
		}

		core.control._drawHero_updateViewport = function (x, y, offset) { }

		var _drawThumbnail_drawTempCanvas = core.maps._drawThumbnail_drawTempCanvas;
		core.maps._drawThumbnail_drawTempCanvas = function (floorId, blocks, options) {
			if (main.mode == 'editor') {
				_drawThumbnail_drawTempCanvas.call(this, floorId, blocks, options);
				return;
			}

			var width = core.floors[floorId].width;
			var height = core.floors[floorId].height;
			// 绘制到tempCanvas上面
			var tempCanvas = core.bigmap.tempCanvas;
			options.v2 = false;
			tempCanvas.canvas.width = width * 32;
			tempCanvas.canvas.height = height * 32;
			options.ctx = tempCanvas;

			var hasHero = core.status.hero != null,
				flags = null;
			if (options.flags) {
				if (!hasHero) core.status.hero = {};
				flags = core.status.hero.flags;
				core.status.hero.flags = options.flags;
			}
			this._drawThumbnail_realDrawTempCanvas(floorId, blocks, options);

			if (!hasHero) delete core.status.hero;
			else if (flags != null) core.status.hero.flags = flags;
			tempCanvas.setTransform(1, 0, 0, 1, 0, 0);
		}

		var _drawThumbnail_drawToTarget = core.maps._drawThumbnail_drawToTarget;
		core.maps._drawThumbnail_drawToTarget = function (floorId, options) {
			if (main.mode == 'editor') {
				_drawThumbnail_drawToTarget.call(this, floorId, options);
				return;
			}

			var ctx = core.getContextByName(options.ctx);
			if (ctx == null) return;
			var x = options.x || 0,
				y = options.y || 0,
				size = options.size || core.__PIXELS__;
			var tempCanvas = core.bigmap.tempCanvas;
			core.drawImage(ctx, tempCanvas.canvas, 32, 32, core.__PIXELS__, core.__PIXELS__, x, y, size, size);
		}

		var _drawWindowSkin = core.ui.drawWindowSkin;
		core.ui.drawWindowSkin = function (background, ctx, x, y, w, h, direction, px, py) {
			_drawWindowSkin.call(this, background, ctx, x, y, w, h, direction, px, py);

			var c = parseInt(w / 2);
			core.drawImage(ctx, background, 160, 90, 16, 6, x + c - 8, y, 16, 6);
		}

		var _drawPagination = ui.prototype.drawPagination;
		core.ui.drawPagination = function (page, totalPage, y) {
			if (["save", "load", "replayLoad", "replayRemain", "replaySince"].indexOf(core.status.event.id) >= 0) {
				if (totalPage <= 1) return;
				if (y == null) y = this.LAST;

				core.setFillStyle('ui', '#DDDDDD');
				var length = core.calWidth('ui', page, this._buildFont(15, true));

				core.setTextAlign('ui', 'left');
				core.fillText('ui', page, parseInt((this.PIXEL - length) / 2), y * 32 + 19);

				core.setTextAlign('ui', 'center');
				if (page > 1)
					core.fillText('ui', '上一页', this.HPIXEL - 48, y * 32 + 19);
				if (page < totalPage)
					core.fillText('ui', '下一页', this.HPIXEL + 48, y * 32 + 19);
				return;
			}
			_drawPagination.call(this, page, totalPage, y);
		}

		core.ui._drawCenterFly = function () {
			core.lockControl();
			core.status.event.id = 'centerFly';
			var fillstyle = 'rgba(255,0,0,0.5)';
			if (core.canUseItem('centerFly')) fillstyle = 'rgba(0,255,0,0.5)';
			var toX = core.bigmap.width - 1 - core.getHeroLoc('x'),
				toY = core.bigmap.height - 1 - core.getHeroLoc('y');
			this.clearUI();
			core.fillRect('ui', 0, 0, this.PIXEL, this.PIXEL, '#000000');
			core.drawThumbnail(null, null, { heroLoc: core.status.hero.loc, heroIcon: core.status.hero.image, ctx: 'ui', centerX: toX, centerY: toY });
			var offsetX = 1,
				offsetY = 1;
			core.fillRect('ui', (toX - offsetX) * 32, (toY - offsetY) * 32, 32, 32, fillstyle);
			core.status.event.data = { "x": toX, "y": toY, "posX": toX - offsetX, "posY": toY - offsetY };
			core.playSound('打开界面');
			core.drawTip("请确认当前" + core.material.items['centerFly'].name + "的位置", 'centerFly');
			return;
		}

		core.ui.drawHelp = function () {
			core.clearUI();
			core.status.event.id = 'help';
			core.lockControl();
			core.setAlpha('ui', 1);
			core.fillRect('ui', 0, 0, this.PIXEL, this.PIXEL, '#FFFFFF');
			core.drawImage('ui', core.material.images.keyboard, 0, 0, 416, 416, 0, 0, 352, 352);
		}

		core.actions._getClickLoc = function (x, y) {
			var size = 32 * core.domStyle.scale;
			var left = main.dom.gameDraw.offsetLeft + main.dom.gameGroup.offsetLeft;
			var top = main.dom.gameDraw.offsetTop + main.dom.gameGroup.offsetTop;
			var loc = { 'x': Math.max(x - left, 0), 'y': Math.max(y - top, 0), 'size': size };
			return loc;
		}

		core.enemys.getDamageString = function (enemy, x, y, floorId) {
			if (typeof enemy == 'string') enemy = core.material.enemys[enemy];
			var damage = this.getDamage(enemy, x, y, floorId);

			var color = '#000000';

			if (damage == null) {
				damage = "???";
				color = '#FF2222';
			} else {
				if (core.hasFlag('addhp')) {
					if (damage < core.status.hero.hp) color = '#11FF11';
					else color = '#FF2222';
				} else if (damage <= 0) color = '#11FF11';
				else if (damage < core.status.hero.hp / 3) color = '#FFFFFF';
				else if (damage < core.status.hero.hp * 2 / 3) color = '#FFFF00';
				else if (damage < core.status.hero.hp) color = '#FF9933';
				else color = '#FF2222';

				damage = core.formatBigNumber(damage, true);
				if (core.enemys.hasSpecial(enemy, 19))
					damage += "+";
				if (core.enemys.hasSpecial(enemy, 21))
					damage += "-";
				if (core.enemys.hasSpecial(enemy, 11))
					damage += "^";
			}

			return {
				"damage": damage,
				"color": color
			};
		}

		core.ui._drawBook_drawDamage = function (index, enemy, offset, position) {
			core.setTextAlign('ui', 'center');
			var damage = enemy.damage,
				color = '#FFFF00';
			if (damage == null) {
				damage = '不可攻击';
				color = '#FF2222';
			}
			if (damage == 0) {
				damage = '无危险';
				color = '#11FF11';
			} else {
				if (damage >= core.status.hero.hp) color = '#FF2222';
				else if (damage >= core.status.hero.hp * 2 / 3) color = '#FF9933';
				else if (damage <= 0) color = '#11FF11';
				damage = core.formatBigNumber(damage);
				if (core.enemys.hasSpecial(enemy, 19)) damage += "+";
				if (core.enemys.hasSpecial(enemy, 21)) damage += "-";
				if (core.enemys.hasSpecial(enemy, 11)) damage += "^";
			}
			if (enemy.notBomb) damage += "[b]";
			core.fillText('ui', damage, offset, position, color, this._buildFont(13, true));
		}

		core.control.checkBlock = function () {
			var x = core.getHeroLoc('x'),
				y = core.getHeroLoc('y'),
				loc = x + "," + y;
			var damage = core.status.checkBlock.damage[loc];
			if (damage) {
				core.status.hero.hp -= damage;
				core.drawTip("你没有神圣盾不能防御，受到 " + damage + " 点魔法伤害");
				core.playSound('zone.mp3');
				this._checkBlock_disableQuickShop();
				core.status.hero.statistics.extraDamage += damage;
				if (core.status.hero.hp <= 0) {
					core.status.hero.hp = 0;
					core.updateStatusBar();
					core.events.lose();
					return;
				} else {
					core.updateStatusBar();
				}
			}
			this._checkBlock_ambush(core.status.checkBlock.ambush[loc]);
			this._checkBlock_repulse(core.status.checkBlock.repulse[loc]);
		}

		core.registerSystemEvent("man", function (data, callback) {
			var a = parseInt(core.status.floorId.substring(2));
			var b = core.nextX();
			var c = core.nextY();
			core.insertAction([
				{ "type": "insert", "name": "对话", "args": [a, b, c, 0] },
			]);
			//console.log(data);
			if (callback) callback();
		});

		core.registerSystemEvent("woman", function (data, callback) {
			var name = core.status.floorId + '@' + core.nextX() + '@' + core.nextY() + '@' + 'A';
			if (core.getFlag(name, 0) == 1) {
				var a = parseInt(core.status.floorId.substring(2));
				var b = core.nextX();
				var c = core.nextY();
				core.insertAction([
					{ "type": "insert", "name": "对话", "args": [a, b, c, 1] },
				]);
			} else {
				core.insertAction([
					{ "type": "insert", "name": "商人", "args": [0] },
				]);
			}
			//console.log(data);
			if (callback) callback();
		});

		core.registerSystemEvent("specialwall", function (data, callback) {
			if (data.event.id == 'whiteWall' || core.getFlag('talking') > 0) {
				core.insertAction({ 'type': 'openDoor', loc: [data.x, data.y] });
				if (data.event.id != 'whiteWall') {
					core.setFlag('end', 1);
				}
				core.setFlag('talking', 0); //穿墙之后不能再次穿墙
			}
			//console.log(data);
			if (callback) callback();
		});

		core.registerSystemEvent("fakeWall", function (data, callback) {
			if (data.event.id == 'blueWall') {
				core.insertAction([
					{ "type": "openDoor", loc: [data.x, data.y] },
				]);
			}
			//console.log(data);
			if (callback) callback();
		});

		core.ui._drawWindowSelector = function (background, x, y, w, h) {
			w = Math.round(w) + 48;
			h = Math.round(h);
			var ctx = core.ui.createCanvas("_selector", x - 24, y, w, h, 165);
			ctx.canvas.id = '';
			this._drawSelector(ctx, background, w, h);
		}

		core.ui._drawSelector = function (ctx, background, w, h, left, top) {
			left = left || 0;
			top = top || 0;
			ctx = this.getContextByName(ctx);
			if (!ctx) return;
			if (typeof background == 'string')
				background = core.material.images.images[background];
			if (!(background instanceof Image)) return;
			// badge
			ctx.drawImage(background, 132, 68, 24, 24, left + 4, top + 4, 24, 24);
			ctx.drawImage(background, 132, 68, 24, 24, w - left - 28, top + 4, 24, 24);
		}

		core.ui.drawTip = function (text, id, clear) {
			core.ui.statusBar.print(text);
		}

		core.ui.clearMap = function (name, x, y, width, height) {
			if (name == 'all') {
				for (var m in core.canvas) {
					core.canvas[m].clearRect(0, 0, core.bigmap.width * 32, core.bigmap.height * 32);
				}
				core.clearMap("outerUI");
				core.dom.gif.innerHTML = "";
				core.removeGlobalAnimate();
			} else {
				var ctx = this.getContextByName(name);
				if (ctx) ctx.clearRect(x || 0, y || 0, width || ctx.canvas.width, height || ctx.canvas.height);
			}
		}

		core.control._updateStatusBar_setToolboxIcon = function () {
			core.ui.statusBar._update_toolBox();
		}

		var _changeFloor_getInfo = core.events._changeFloor_getInfo;
		core.events._changeFloor_getInfo = function (floorId, stair, heroLoc, time) {
			var info = _changeFloor_getInfo.call(this, floorId, stair, heroLoc, time);
			if (info == null) return null;
			info.time = 0;
			info.origin = floorId;
			return info;
		}

		core.events._changeFloor_afterChange = function (info, callback) {
			if (!info.locked) core.unlockControl();
			core.status.replay.animate = false;
			core.events.afterChangeFloor(info.floorId);

			if (info.origin == ':before') core.ui.statusBar.print('走下了楼梯')
			else if (info.origin == ':next') core.ui.statusBar.print('登上了楼梯')
			if (callback) callback();
		}

		if (window.jsinterface && window.jsinterface.requestLandscape) {
			window.jsinterface.requestLandscape();
		}
	},
    "shop": function () {
		// 【全局商店】相关的功能
		// 
		// 打开一个全局商店
		// shopId：要打开的商店id；noRoute：是否不计入录像
		this.openShop = function (shopId, noRoute) {
			var shop = core.status.shops[shopId];
			// Step 1: 检查能否打开此商店
			if (!this.canOpenShop(shopId)) {
				core.drawTip("该商店尚未开启");
				return false;
			}

			// Step 2: （如有必要）记录打开商店的脚本事件
			if (!noRoute) {
				core.status.route.push("shop:" + shopId);
			}

			// Step 3: 检查道具商店 or 公共事件
			if (shop.item) {
				if (core.openItemShop) {
					core.openItemShop(shopId);
				} else {
					core.playSound('操作失败');
					core.insertAction("道具商店插件不存在！请检查是否存在该插件！");
				}
				return;
			}
			if (shop.commonEvent) {
				core.insertCommonEvent(shop.commonEvent, shop.args);
				return;
			}

			_shouldProcessKeyUp = true;

			// Step 4: 执行标准公共商店    
			core.insertAction(this._convertShop(shop));
			return true;
		}

		////// 将一个全局商店转变成可预览的公共事件 //////
		this._convertShop = function (shop) {
			return [
				{ "type": "function", "function": "function() {core.addFlag('@temp@shop', 1);}" },
				{
					"type": "while",
					"condition": "true",
					"data": [
						// 检测能否访问该商店
						{
							"type": "if",
							"condition": "core.isShopVisited('" + shop.id + "')",
							"true": [
								// 可以访问，直接插入执行效果
								{ "type": "function", "function": "function() { core.plugin._convertShop_replaceChoices('" + shop.id + "', false) }" },
							],
							"false": [
								// 不能访问的情况下：检测能否预览
								{
									"type": "if",
									"condition": shop.disablePreview,
									"true": [
										// 不可预览，提示并退出
										{ "type": "playSound", "name": "操作失败" },
										"当前无法访问该商店！",
										{ "type": "break" },
									],
									"false": [
										// 可以预览：将商店全部内容进行替换
										{ "type": "tip", "text": "当前处于预览模式，不可购买" },
										{ "type": "function", "function": "function() { core.plugin._convertShop_replaceChoices('" + shop.id + "', true) }" },
									]
								}
							]
						}
					]
				},
				{ "type": "function", "function": "function() {core.addFlag('@temp@shop', -1);}" }
			];
		}

		this._convertShop_replaceChoices = function (shopId, previewMode) {
			var shop = core.status.shops[shopId];
			var choices = (shop.choices || []).filter(function (choice) {
				if (choice.condition == null || choice.condition == '') return true;
				try { return core.calValue(choice.condition); } catch (e) { return true; }
			}).map(function (choice) {
				var ableToBuy = core.calValue(choice.need);
				return {
					"text": choice.text,
					"icon": choice.icon,
					"color": ableToBuy && !previewMode ? choice.color : [153, 153, 153, 1],
					"action": ableToBuy && !previewMode ? [{ "type": "playSound", "name": "商店" }].concat(choice.action) : [
						{ "type": "playSound", "name": "操作失败" },
						{ "type": "tip", "text": previewMode ? "预览模式下不可购买" : "购买条件不足" }
					]
				};
			}).concat({ "text": "离开", "action": [{ "type": "playSound", "name": "取消" }, { "type": "break" }] });
			core.insertAction({ "type": "choices", "text": shop.text, "choices": choices });
		}

		/// 是否访问过某个快捷商店
		this.isShopVisited = function (id) {
			if (!core.hasFlag("__shops__")) core.setFlag("__shops__", {});
			var shops = core.getFlag("__shops__");
			if (!shops[id]) shops[id] = {};
			return shops[id].visited;
		}

		/// 当前应当显示的快捷商店列表
		this.listShopIds = function () {
			return Object.keys(core.status.shops).filter(function (id) {
				return core.isShopVisited(id) || !core.status.shops[id].mustEnable;
			});
		}

		/// 是否能够打开某个商店
		this.canOpenShop = function (id) {
			if (this.isShopVisited(id)) return true;
			var shop = core.status.shops[id];
			if (shop.item || shop.commonEvent || shop.mustEnable) return false;
			return true;
		}

		/// 启用或禁用某个快捷商店
		this.setShopVisited = function (id, visited) {
			if (!core.hasFlag("__shops__")) core.setFlag("__shops__", {});
			var shops = core.getFlag("__shops__");
			if (!shops[id]) shops[id] = {};
			if (visited) shops[id].visited = true;
			else delete shops[id].visited;
		}

		/// 能否使用快捷商店
		this.canUseQuickShop = function (id) {
			// 如果返回一个字符串，表示不能，字符串为不能使用的提示
			// 返回null代表可以使用

			// 检查当前楼层的canUseQuickShop选项是否为false
			if (core.status.thisMap.canUseQuickShop === false)
				return '当前楼层不能使用快捷商店。';
			return null;
		}

		var _shouldProcessKeyUp = true;

		/// 允许商店X键退出
		core.registerAction('keyUp', 'shops', function (keycode) {
			if (!core.status.lockControl || core.status.event.id != 'action') return false;
			if ((keycode == 13 || keycode == 32) && !_shouldProcessKeyUp) {
				_shouldProcessKeyUp = true;
				return true;
			}

			if (!core.hasFlag("@temp@shop") || core.status.event.data.type != 'choices') return false;
			var data = core.status.event.data.current;
			var choices = data.choices;
			var topIndex = core.actions._getChoicesTopIndex(choices.length);
			if (keycode == 88 || keycode == 27) { // X, ESC
				core.actions._clickAction(core.actions.HSIZE, topIndex + choices.length - 1);
				return true;
			}
			return false;
		}, 60);

		/// 允许长按空格或回车连续执行操作
		core.registerAction('keyDown', 'shops', function (keycode) {
			if (!core.status.lockControl || !core.hasFlag("@temp@shop") || core.status.event.id != 'action') return false;
			if (core.status.event.data.type != 'choices') return false;
			var data = core.status.event.data.current;
			var choices = data.choices;
			var topIndex = core.actions._getChoicesTopIndex(choices.length);
			if (keycode == 13 || keycode == 32) { // Space, Enter
				core.actions._clickAction(core.actions.HSIZE, topIndex + core.status.event.selection);
				_shouldProcessKeyUp = false;
				return true;
			}
			return false;
		}, 60);

		// 允许长按屏幕连续执行操作
		core.registerAction('longClick', 'shops', function (x, y, px, py) {
			if (!core.status.lockControl || !core.hasFlag("@temp@shop") || core.status.event.id != 'action') return false;
			if (core.status.event.data.type != 'choices') return false;
			var data = core.status.event.data.current;
			var choices = data.choices;
			var topIndex = core.actions._getChoicesTopIndex(choices.length);
			if (x >= core.actions.CHOICES_LEFT && x <= core.actions.CHOICES_RIGHT && y >= topIndex && y < topIndex + choices.length) {
				core.actions._clickAction(x, y);
				return true;
			}
			return false;
		}, 60);
	},
    "宝石血瓶显值": function () {
	/* 宝石血瓶左下角显示数值
	 * 需要将 变量：itemDetail改为true才可正常运行
	 * 请尽量减少勇士的属性数量，否则可能会出现严重卡顿
	 * 注意：这里的属性必须是core.status.hero里面的，flag无法显示
	 * 如果不想显示，可以core.setFlag("itemDetail", false);
	 * 然后再core.getItemDetail();
	 * 如有bug在大群或造塔群@古祠
	 */

	// 谁tm在即捡即用效果里面调用带有含刷新状态栏的函数
	var origin = core.control.updateStatusBar;
	core.updateStatusBar = core.control.updateStatusBar = function () {
		if (core.getFlag('__statistics__')) return;
		else return origin.apply(core.control, arguments);
	}

	core.bigmap.threshold = 256;

	core.control.updateDamage = function (floorId, ctx) {
		floorId = floorId || core.status.floorId;
		if (!floorId || core.status.gameOver || main.mode != 'play') return;
		var onMap = ctx == null;

		// 没有怪物手册
		if (!core.hasItem('book')) return;
		core.status.damage.posX = core.bigmap.posX;
		core.status.damage.posY = core.bigmap.posY;
		if (!onMap) {
			var width = core.floors[floorId].width,
				height = core.floors[floorId].height;
			// 地图过大的缩略图不绘制显伤
			if (width * height > core.bigmap.threshold) return;
		}
		this._updateDamage_damage(floorId, onMap);
		this._updateDamage_extraDamage(floorId, onMap);
		core.getItemDetail(floorId); // 宝石血瓶详细信息
		this.drawDamage(ctx);
	};
	// 绘制地图显示
	control.prototype._drawDamage_draw = function (ctx, onMap) {
		if (!core.hasItem('book')) return;
		// *** 下一句话可以更改你想要的显示字体
		core.setFont(ctx, "bold 11px pixelmix");
		// ***
		core.setTextAlign(ctx, 'left');
		core.status.damage.data.forEach(function (one) {
			var px = one.px,
				py = one.py;
			if (onMap && core.bigmap.v2) {
				px -= core.bigmap.posX * 32;
				py -= core.bigmap.posY * 32;
				if (px < -32 * 2 || px > core.__PX__ + 32 || py < -32 || py > core.__PY__ + 32)
					return;
			}
			core.fillBoldText(ctx, one.text, px, py, one.color);
		});
		core.setTextAlign(ctx, 'center');
		core.status.damage.extraData.forEach(function (one) {
			var px = one.px,
				py = one.py;
			if (onMap && core.bigmap.v2) {
				px -= core.bigmap.posX * 32;
				py -= core.bigmap.posY * 32;
				if (px < -32 || px > core.__PX__ + 32 || py < -32 || py > core.__PY__ + 32)
					return;
			}
			core.fillBoldText(ctx, one.text, px, py, one.color);
		});
	};
	// 获取宝石信息 并绘制
	this.getItemDetail = function (floorId) {
		if (!core.getFlag("itemDetail")) return;
		floorId = floorId || core.status.thisMap.floorId;
		core.status.maps[floorId].blocks.forEach(function (block) {
			if (block.event.cls !== 'items' || block.event.id === 'superPotion') return;
			var x = block.x,
				y = block.y;
			// v2优化，只绘制范围内的部分
			if (core.bigmap.v2) {
				if (x < core.bigmap.posX - core.bigmap.extend || x > core.bigmap.posX + core.__SIZE__ + core.bigmap.extend ||
					y < core.bigmap.posY - core.bigmap.extend || y > core.bigmap.posY + core.__SIZE__ + core.bigmap.extend) {
					return;
				}
			}
			var id = block.event.id;
			var item = core.material.items[id];
			if (item.cls === 'equips') {
				// 装备也显示
				var diff = core.clone(item.equip.value || {});
				var per = item.equip.percentage;
				for (var name in per) {
					diff[name + 'per'] = per[name].toString() + '%';
				}
				drawItemDetail(diff, x, y);
				return;
			}
			var before = core.clone(core.status.hero);
			// 跟数据统计原理一样 执行效果 前后比较
			core.setFlag("__statistics__", true);
			let tmp = core.status.maps[floorId].ratio;
			let ans = '';
			if (item.itemEffect !== undefined && item.itemEffect !== null) ans = item.itemEffect.replace(/core.status.thisMap.ratio/g, tmp);
			try {
				eval(ans);
			} catch (error) {}
			var diff = compareObject(before, core.status.hero);
			core.status.hero = hero = before;
			flags = core.status.hero.flags;
			drawItemDetail(diff, x, y);
		});
	};
	// 比较两个对象之间每一项的数值差异（弱等于） 返回数值差异
	function compareObject(a, b) {
		a = a || {};
		b = b || {};
		var diff = {}; // 差异
		for (var name in a) {
			diff[name] = b[name] - (a[name] || 0);
			if (!diff[name]) diff[name] = void 0;
		}
		return diff;
	};
	// 绘制
	function drawItemDetail(diff, x, y) {
		var px = 32 * x + 2,
			py = 32 * y + 30;
		var content = "";
		// 获得数据和颜色
		var i = 0;
		for (var name in diff) {
			if (diff[name] === undefined) continue;
			var color = "#ffffff";
			if (typeof diff[name] === 'number')
				diff[name] = core.formatBigNumber(diff[name], true);
			switch (name) {
			case 'atk':
			case 'atkper':
				color = "#FF7A7A";
				break;
			case 'def':
			case 'defper':
				color = "#00E6F1";
				break;
			case 'mdef':
			case 'mdefper':
				color = "#6EFF83";
				break;
			case 'hp':
				color = "#A4FF00";
				break;
			case 'hpmax':
			case 'hpmaxper':
				color = "#FF9858";
				break;
			case 'mana':
				color = "#cc6666";
				break;
			case 'exp':
				color = "#EC8FC6";
				break;
			case 'money':
				color = "#EBE44E";
				break;
			}
			content = diff[name];
			// 绘制
			core.status.damage.data.push({ text: content, px: px, py: py - 10 * i, color: color });
			i++;
		}
	}

}
}
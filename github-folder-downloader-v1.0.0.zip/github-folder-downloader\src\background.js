/* GitHub 文件夹下载器 - service worker */
const CHANNEL = 'ghfd';

const jobs = new Map();
const pendingBlobUrls = new Map();
let offscreenReady = false;
let offscreenCreating = null;

if (chrome.downloads && chrome.downloads.onChanged) {
  chrome.downloads.onChanged.addListener((delta) => {
    if (!delta.state) return;
    const state = delta.state.current;
    if (state !== 'complete' && state !== 'interrupted') return;
    const url = pendingBlobUrls.get(delta.id);
    if (!url) return;
    pendingBlobUrls.delete(delta.id);
    chrome.runtime.sendMessage({ channel: CHANNEL, type: 'release', url }).catch(() => {});
  });
}

async function hasOffscreenDocument() {
  try {
    if (chrome.offscreen && typeof chrome.offscreen.hasDocument === 'function') {
      return await chrome.offscreen.hasDocument();
    }
  } catch (e) {
    // Fall through and try to create it.
  }
  return false;
}

async function ensureOffscreen() {
  if (offscreenReady) return;
  if (await hasOffscreenDocument()) {
    offscreenReady = true;
    return;
  }
  if (!offscreenCreating) {
    offscreenCreating = chrome.offscreen
      .createDocument({
        url: 'src/offscreen.html',
        reasons: ['BLOBS'],
        justification: '在后台生成并保存文件夹 ZIP 压缩包',
      })
      .finally(() => {
        offscreenCreating = null;
      });
  }
  try {
    await offscreenCreating;
  } catch (error) {
    // If another context created it in the meantime, that is fine.
    if (!(await hasOffscreenDocument())) throw error;
  }
  offscreenReady = true;
}

async function sendToOffscreen(message) {
  let lastError = null;
  for (let attempt = 0; attempt < 60; attempt++) {
    try {
      const response = await chrome.runtime.sendMessage(message);
      if (response && response.ok) return response;
      lastError = new Error((response && response.error) || '下载引擎未响应');
    } catch (error) {
      lastError = error;
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error('无法启动下载引擎' + (lastError ? '：' + lastError.message : ''));
}

function sanitizeJob(raw, tabId) {
  if (!raw || typeof raw !== 'object') throw new Error('无效的下载任务');
  const clean = {};
  for (const key of ['id', 'owner', 'repo', 'ref', 'path', 'folderName', 'pageUrl']) {
    if (typeof raw[key] !== 'string') raw[key] = '';
    clean[key] = String(raw[key] || '').slice(0, 500);
  }
  if (!/^[0-9a-f-]{8,64}$/i.test(clean.id)) throw new Error('无效的任务 ID');
  if (!clean.owner || !clean.repo || !clean.ref) throw new Error('页面信息不完整');
  if (!/^[\w.-]+$/.test(clean.owner) || !/^[\w.-]+$/.test(clean.repo)) throw new Error('仓库名称无效');
  clean.tabId = tabId;
  return clean;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.channel !== CHANNEL) return false;

  if (message.type === 'start') {
    let job;
    try {
      if (!sender.tab || typeof sender.tab.id !== 'number') throw new Error('请从 GitHub 页面发起下载');
      job = sanitizeJob(message.job, sender.tab.id);
    } catch (error) {
      sendResponse({ ok: false, error: error.message });
      return false;
    }

    jobs.set(job.id, { tabId: sender.tab.id });
    (async () => {
      await ensureOffscreen();
      await sendToOffscreen({ channel: CHANNEL, type: 'run', job });
      sendResponse({ ok: true });
    })().catch((error) => {
      jobs.delete(job.id);
      sendResponse({ ok: false, error: error.message || String(error), code: 'OFFSCREEN' });
    });
    return true;
  }

  if (message.type === 'cancel') {
    sendToOffscreen({ channel: CHANNEL, type: 'cancel', jobId: String(message.jobId || '') }).catch(() => {});
    sendResponse({ ok: true });
    return false;
  }

  if (message.type === 'save') {
    const url = String(message.url || '');
    const rawName = String(message.filename || 'download.zip');
    const filename = rawName
      .replace(/[\\/:*?"<>|\u0000-\u001f]/g, '-')
      .replace(/^[.\s]+/, '')
      .replace(/[.\s]+$/, '')
      .slice(0, 180) || 'download.zip';
    if (!url.startsWith('blob:chrome-extension://') || url.length > 2048) {
      sendResponse({ ok: false, error: '无效的文件地址' });
      return false;
    }
    chrome.downloads
      .download({
        url,
        filename,
        saveAs: false,
        conflictAction: 'uniquify',
      })
      .then((downloadId) => {
        pendingBlobUrls.set(downloadId, url);
        sendResponse({ ok: true, downloadId });
      })
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message.type === 'progress' || message.type === 'done' || message.type === 'error' || message.type === 'cancelled') {
    const entry = jobs.get(message.jobId);
    if (entry) {
      chrome.tabs.sendMessage(entry.tabId, message).catch(() => {});
      if (message.type !== 'progress') jobs.delete(message.jobId);
    }
    sendResponse({ ok: true });
    return false;
  }

  return false;
});

if (chrome.tabs && chrome.tabs.onRemoved) {
  chrome.tabs.onRemoved.addListener((tabId) => {
    for (const [jobId, entry] of jobs) {
      if (entry.tabId === tabId) jobs.delete(jobId);
    }
  });
}

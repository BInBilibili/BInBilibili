/* GitHub 文件夹下载器 - offscreen worker (fetch + zip + save) */
(() => {
  'use strict';

  const CHANNEL = 'ghfd';
  const queue = [];
  const known = new Set();
  const cancelled = new Set();
  let running = false;
  let current = null;

  function send(message) {
    try {
      const result = chrome.runtime.sendMessage({ channel: CHANNEL, ...message });
      if (result && typeof result.catch === 'function') result.catch(() => {});
    } catch (e) {
      // Service worker is restarting; the download itself is unaffected.
    }
  }

  function cancelJob(jobId) {
    if (!jobId) return;
    cancelled.add(jobId);
    if (current && current.job.id === jobId) {
      try { current.controller.abort(); } catch (e) {}
      return;
    }
    const index = queue.findIndex((job) => job.id === jobId);
    if (index >= 0) {
      queue.splice(index, 1);
      known.delete(jobId);
      send({ type: 'cancelled', jobId });
    }
  }

  async function runOne(job) {
    const controller = new AbortController();
    current = { job, controller };
    let lastPhase = '';
    let lastSent = 0;

    const update = (payload) => {
      if (!payload) return;
      const now = Date.now();
      if (payload.phase === lastPhase && now - lastSent < 130) return;
      lastPhase = payload.phase;
      lastSent = now;
      send({ type: 'progress', jobId: job.id, payload });
    };

    try {
      const result = await GHFD.runFolderJob(job, { signal: controller.signal, update });
      if (controller.signal.aborted) throw new DOMException('Aborted', 'AbortError');
      const saved = await saveBlob(result.blob, result.filename);
      const { blob, ...stats } = result;
      send({ type: 'done', jobId: job.id, result: { ...stats, downloadId: saved && saved.downloadId } });
    } catch (error) {
      if (controller.signal.aborted || (error && error.name === 'AbortError')) {
        send({ type: 'cancelled', jobId: job.id });
      } else {
        send({
          type: 'error',
          jobId: job.id,
          error: {
            message: (error && error.message) || '下载失败',
            code: (error && error.code) || 'UNKNOWN',
          },
        });
      }
    } finally {
      current = null;
      known.delete(job.id);
      cancelled.delete(job.id);
    }
  }

  async function saveBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    try {
      const response = await chrome.runtime.sendMessage({
        channel: CHANNEL,
        type: 'save',
        url,
        filename: filename || 'download.zip',
      });
      if (!response || !response.ok) {
        throw new Error((response && response.error) || '浏览器没有接受保存请求');
      }
      return response;
    } finally {
      // The service worker tells us when the download finishes; this is a fallback.
      setTimeout(() => URL.revokeObjectURL(url), 30 * 60 * 1000);
    }
  }

  async function pump() {
    if (running) return;
    running = true;
    try {
      while (queue.length) {
        const job = queue.shift();
        if (cancelled.has(job.id)) {
          cancelled.delete(job.id);
          known.delete(job.id);
          send({ type: 'cancelled', jobId: job.id });
          continue;
        }
        await runOne(job);
      }
    } finally {
      running = false;
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.channel !== CHANNEL) return false;

    if (message.type === 'run') {
      const job = message.job;
      if (!job || typeof job.id !== 'string' || !job.id) {
        sendResponse({ ok: false, error: '无效任务' });
        return false;
      }
      if (!known.has(job.id)) {
        known.add(job.id);
        queue.push(job);
        send({ type: 'progress', jobId: job.id, payload: { phase: 'queued', text: '准备中…' } });
        pump();
      }
      sendResponse({ ok: true });
      return false;
    }

    if (message.type === 'cancel') {
      cancelJob(String(message.jobId || ''));
      sendResponse({ ok: true });
      return false;
    }

    if (message.type === 'release') {
      if (typeof message.url === 'string') {
        try { URL.revokeObjectURL(message.url); } catch (e) {}
      }
      sendResponse({ ok: true });
      return false;
    }

    return false;
  });
})();

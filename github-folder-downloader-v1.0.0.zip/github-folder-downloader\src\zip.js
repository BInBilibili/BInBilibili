/*
 * Minimal ZIP writer/reader (store + deflate), no third-party code.
 * Writer: builds a standards-compliant ZIP with UTF-8 names.
 * Reader: parses central directory, supports ZIP64 EOCD (for >65535 entries).
 */
(function (global) {
  'use strict';

  const LOCAL_SIG = 0x04034b50;
  const CENTRAL_SIG = 0x02014b50;
  const EOCD_SIG = 0x06054b50;
  const ZIP64_EOCD_SIG = 0x06064b50;
  const ZIP64_LOCATOR_SIG = 0x07064b50;
  const MAX32 = 0xffffffff;
  const UTF8_FLAG = 0x0800;
  const encoder = new TextEncoder();

  let crcTable = null;
  function getCrcTable() {
    if (crcTable) return crcTable;
    crcTable = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      crcTable[n] = c >>> 0;
    }
    return crcTable;
  }

  function crc32(bytes) {
    const table = getCrcTable();
    let crc = 0xffffffff;
    for (let i = 0; i < bytes.length; i++) {
      crc = (crc >>> 8) ^ table[(crc ^ bytes[i]) & 0xff];
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  function dosDateTime(date = new Date()) {
    const year = Math.max(1980, date.getFullYear());
    return {
      date: ((year - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate(),
      time: (date.getHours() << 11) | (date.getMinutes() << 5) | (date.getSeconds() >> 1),
    };
  }

  function normalizeName(name) {
    const parts = String(name).replace(/\\/g, '/').split('/');
    const safe = [];
    for (const part of parts) {
      if (!part || part === '.') continue;
      if (part === '..') continue;
      safe.push(part);
    }
    return safe.join('/');
  }

  async function deflateRaw(bytes) {
    if (typeof CompressionStream === 'undefined') throw new Error('CompressionStream unavailable');
    const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream('deflate-raw'));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  async function inflateRaw(bytes) {
    if (typeof DecompressionStream === 'undefined') throw new Error('DecompressionStream unavailable');
    const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  class ZipBuilder {
    constructor(options = {}) {
      this.parts = [];
      this.central = [];
      this.offset = 0;
      this.count = 0;
      this.date = options.date || new Date();
      this.compressDefault = options.compress !== false;
    }

    async addFile(name, data, options = {}) {
      const safeName = normalizeName(name);
      if (!safeName) throw new Error('invalid zip entry name');
      const input = data instanceof Uint8Array ? data : new Uint8Array(data);
      if (input.length > MAX32) throw new Error('单个文件超过 4GB，暂不支持打包');

      let method = 0;
      let payload = input;

      if (options.compress !== false && this.compressDefault) {
        if (input.length > 0 && input.length < 64 * 1024 * 1024) {
          try {
            const compressed = await deflateRaw(input);
            if (compressed.length < input.length) {
              method = 8;
              payload = compressed;
            }
          } catch (e) {
            // Compression is optional; fall back to store.
          }
        }
      }

      this._addEntry(safeName, payload, method, crc32(input), input.length);
      return { name: safeName, originalSize: input.length, storedSize: payload.length, method };
    }

    addRawFile(name, payload, meta) {
      const safeName = normalizeName(name);
      if (!safeName) throw new Error('invalid zip entry name');
      const data = payload instanceof Uint8Array ? payload : new Uint8Array(payload);
      const method = meta.method;
      if (method !== 0 && method !== 8) throw new Error('不支持的 ZIP 压缩方式: ' + method);
      if (!Number.isInteger(meta.uncompSize) || meta.uncompSize < 0) throw new Error('无效的文件大小');
      if (!Number.isInteger(meta.crc) || meta.crc < 0 || meta.crc > 0xffffffff) throw new Error('无效的 CRC');
      this._addEntry(safeName, data, method, meta.crc, meta.uncompSize);
      return { name: safeName, originalSize: meta.uncompSize, storedSize: data.length, method };
    }

    _addEntry(safeName, payload, method, crc, uncompSize) {
      if (this.count >= 0xffff) throw new Error('文件数量超过 65535，暂不支持打包');
      if (uncompSize > MAX32) throw new Error('单个文件超过 4GB，暂不支持打包');
      if (payload.length > MAX32) throw new Error('单个文件超过 4GB，暂不支持打包');
      if (this.offset > MAX32) throw new Error('压缩包超过 4GB，暂不支持打包');

      const nameBytes = encoder.encode(safeName);
      const { date, time } = dosDateTime(this.date);

      const local = new Uint8Array(30 + nameBytes.length);
      const lv = new DataView(local.buffer);
      lv.setUint32(0, LOCAL_SIG, true);
      lv.setUint16(4, 20, true);
      lv.setUint16(6, UTF8_FLAG, true);
      lv.setUint16(8, method, true);
      lv.setUint16(10, time, true);
      lv.setUint16(12, date, true);
      lv.setUint32(14, crc, true);
      lv.setUint32(18, payload.length, true);
      lv.setUint32(22, uncompSize, true);
      lv.setUint16(26, nameBytes.length, true);
      lv.setUint16(28, 0, true);
      local.set(nameBytes, 30);

      this.parts.push(local, payload);
      this.central.push({
        nameBytes,
        method,
        time,
        date,
        crc,
        compSize: payload.length,
        uncompSize,
        offset: this.offset,
      });
      this.offset += local.length + payload.length;
      this.count++;
    }

    finish() {
      if (this.count >= 0xffff) throw new Error('文件数量超过 65535，暂不支持打包');
      if (this.offset > MAX32) throw new Error('压缩包超过 4GB，暂不支持打包');

      let centralSize = 0;
      for (const entry of this.central) centralSize += 46 + entry.nameBytes.length;

      const central = new Uint8Array(centralSize);
      const cv = new DataView(central.buffer);
      let p = 0;
      for (const entry of this.central) {
        cv.setUint32(p, CENTRAL_SIG, true);
        cv.setUint16(p + 4, 20, true); // version made by (MS-DOS, 2.0)
        cv.setUint16(p + 6, 20, true); // version needed
        cv.setUint16(p + 8, UTF8_FLAG, true);
        cv.setUint16(p + 10, entry.method, true);
        cv.setUint16(p + 12, entry.time, true);
        cv.setUint16(p + 14, entry.date, true);
        cv.setUint32(p + 16, entry.crc, true);
        cv.setUint32(p + 20, entry.compSize, true);
        cv.setUint32(p + 24, entry.uncompSize, true);
        cv.setUint16(p + 28, entry.nameBytes.length, true);
        cv.setUint16(p + 30, 0, true); // extra
        cv.setUint16(p + 32, 0, true); // comment
        cv.setUint16(p + 34, 0, true); // disk
        cv.setUint16(p + 36, 0, true); // internal attrs
        cv.setUint32(p + 38, (0o100644 << 16) >>> 0, true); // external attrs
        cv.setUint32(p + 42, entry.offset, true);
        central.set(entry.nameBytes, p + 46);
        p += 46 + entry.nameBytes.length;
      }

      const eocd = new Uint8Array(22);
      const ev = new DataView(eocd.buffer);
      ev.setUint32(0, EOCD_SIG, true);
      ev.setUint16(4, 0, true);
      ev.setUint16(6, 0, true);
      ev.setUint16(8, this.count, true);
      ev.setUint16(10, this.count, true);
      ev.setUint32(12, centralSize, true);
      ev.setUint32(16, this.offset, true);
      ev.setUint16(20, 0, true);

      this.parts.push(central, eocd);
      const blob = new Blob(this.parts, { type: 'application/zip' });
      return blob;
    }
  }

  function findEocd(bytes) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const min = Math.max(0, bytes.length - 65557);
    for (let i = bytes.length - 22; i >= min; i--) {
      if (view.getUint32(i, true) === EOCD_SIG) return i;
    }
    return -1;
  }

  function parseZipDirectory(bytes) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const eocd = findEocd(bytes);
    if (eocd < 0) throw new Error('不是有效的 ZIP 文件（找不到目录结尾）');

    let count = view.getUint16(eocd + 10, true);
    let cdSize = view.getUint32(eocd + 12, true);
    let cdOffset = view.getUint32(eocd + 16, true);

    if (count === 0xffff || cdSize === MAX32 || cdOffset === MAX32) {
      const locator = eocd - 20;
      if (locator >= 0 && view.getUint32(locator, true) === ZIP64_LOCATOR_SIG) {
        const z64Offset = Number(view.getBigUint64(locator + 8, true));
        if (z64Offset + 56 <= bytes.length && view.getUint32(z64Offset, true) === ZIP64_EOCD_SIG) {
          count = Number(view.getBigUint64(z64Offset + 32, true));
          cdSize = Number(view.getBigUint64(z64Offset + 40, true));
          cdOffset = Number(view.getBigUint64(z64Offset + 48, true));
        }
      }
    }

    if (cdOffset + cdSize > bytes.length) throw new Error('ZIP 目录数据损坏');
    if (count > 500000) throw new Error('ZIP 文件数量异常');

    const entries = [];
    let p = cdOffset;
    for (let i = 0; i < count; i++) {
      if (p + 46 > bytes.length || view.getUint32(p, true) !== CENTRAL_SIG) {
        throw new Error('ZIP 中央目录损坏');
      }
      const flags = view.getUint16(p + 8, true);
      const method = view.getUint16(p + 10, true);
      const crc = view.getUint32(p + 16, true);
      let compSize = view.getUint32(p + 20, true);
      let uncompSize = view.getUint32(p + 24, true);
      const nameLen = view.getUint16(p + 28, true);
      const extraLen = view.getUint16(p + 30, true);
      const commentLen = view.getUint16(p + 32, true);
      const localOffset = view.getUint32(p + 42, true);
      const nameStart = p + 46;
      if (nameStart + nameLen > bytes.length) throw new Error('ZIP 文件名越界');
      const name = new TextDecoder('utf-8').decode(bytes.subarray(nameStart, nameStart + nameLen));

      let realComp = compSize;
      let realUncomp = uncompSize;
      let realOffset = localOffset;
      if (compSize === MAX32 || uncompSize === MAX32 || localOffset === MAX32) {
        let e = nameStart + nameLen;
        const extraEnd = e + extraLen;
        while (e + 4 <= extraEnd) {
          const id = view.getUint16(e, true);
          const size = view.getUint16(e + 2, true);
          if (id === 0x0001) {
            let q = e + 4;
            const qEnd = Math.min(q + size, extraEnd);
            if (uncompSize === MAX32 && q + 8 <= qEnd) { realUncomp = Number(view.getBigUint64(q, true)); q += 8; }
            if (compSize === MAX32 && q + 8 <= qEnd) { realComp = Number(view.getBigUint64(q, true)); q += 8; }
            if (localOffset === MAX32 && q + 8 <= qEnd) { realOffset = Number(view.getBigUint64(q, true)); q += 8; }
          }
          e += 4 + size;
        }
      }

      entries.push({
        name,
        flags,
        method,
        crc,
        compSize: realComp,
        uncompSize: realUncomp,
        localOffset: realOffset,
        isDirectory: name.endsWith('/'),
      });
      p += 46 + nameLen + extraLen + commentLen;
    }
    return entries;
  }

  function readZipEntryRaw(bytes, entry) {
    if (entry.flags & 0x1) throw new Error('ZIP 条目已加密');
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const lh = entry.localOffset;
    if (lh + 30 > bytes.length || view.getUint32(lh, true) !== LOCAL_SIG) {
      throw new Error('ZIP 本地文件头损坏');
    }
    const nameLen = view.getUint16(lh + 26, true);
    const extraLen = view.getUint16(lh + 28, true);
    const start = lh + 30 + nameLen + extraLen;
    const end = start + entry.compSize;
    if (end > bytes.length) throw new Error('ZIP 数据越界');
    return {
      data: bytes.subarray(start, end),
      method: entry.method,
      crc: entry.crc,
      uncompSize: entry.uncompSize,
    };
  }

  async function extractZipEntry(bytes, entry) {
    const raw = readZipEntryRaw(bytes, entry);
    if (raw.method === 0) return raw.data;
    if (raw.method === 8) return await inflateRaw(raw.data);
    throw new Error('不支持的 ZIP 压缩方式: ' + raw.method);
  }

  global.GHFDZip = { ZipBuilder, crc32, parseZipDirectory, extractZipEntry, readZipEntryRaw, deflateRaw, inflateRaw };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = global.GHFDZip;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);

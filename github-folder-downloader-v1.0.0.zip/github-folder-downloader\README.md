# GitHub 文件夹下载器

不登录 GitHub，也能把仓库里的**任意一个文件夹**单独打包成 ZIP 下载。

![预览](docs/preview.png)

## 功能

- 打开任意 GitHub 仓库或文件夹页面，右下角出现绿色「下载此文件夹」按钮。
- 下载当前层文件夹的**全部内容**（含所有子文件夹），而不是只能下载整个仓库。
- 鼠标移到文件夹行上，会出现一个小下载图标，可直接下载该子文件夹，不用先点进去。
- 自动跳过无权限/已删除/子模块条目，并在结果里说明。
- 不登录、不填 Token、不上传代码；ZIP 在你的浏览器里本地生成。

## 安装（Edge / Chrome）

1. 解压 `github-folder-downloader.zip`（或直接使用当前文件夹）。
2. 打开浏览器扩展管理页：
   - Edge：地址栏输入 `edge://extensions`
   - Chrome：地址栏输入 `chrome://extensions`
3. 打开右上角（Edge 在左侧栏）的「开发人员模式 / Developer mode」。
4. 点击「加载解压缩的扩展 / Load unpacked」，选择包含 `manifest.json` 的文件夹。
   - 当前路径：`D:\仓库\github-folder-downloader`
5. 建议把扩展图标固定到工具栏，点开可以查看 GitHub 接口剩余额度。

> 需要 Chromium 116 或更新版本（Chrome / Edge 均可）。Firefox 不支持本扩展使用的 offscreen 能力。

## 使用

### 下载当前文件夹

打开例如：

```text
https://github.com/expressjs/express/tree/master/lib
```

等页面加载完，点右下角「下载此文件夹」。浏览器会直接保存：

```text
express-lib.zip
```

ZIP 内部顶层是文件夹名，例如 `lib/application.js`、`lib/express.js`。

### 直接下载某个子文件夹

在仓库/文件夹列表中，把鼠标移到文件夹那一行，点击右侧出现的下载图标。不会跳转页面，直接开始打包该子文件夹。

### 下载整个仓库

在仓库首页（例如 `https://github.com/octocat/Hello-World`）点同一个按钮，ZIP 名为 `仓库名-分支名.zip`。

## 工作原理

1. 用 GitHub 公开 REST API 的 `git/trees/{ref}?recursive=1` 拿到该分支的文件清单（1 次请求）。
2. 从 `raw.githubusercontent.com` 并发读取文件夹下的文件。
3. 在浏览器扩展的 offscreen 文档里生成标准 ZIP，再交给浏览器的下载管理器保存。

未登录访问 GitHub API 的限额是**每小时 60 次**。每次下载文件夹消耗 1 次（读取文件内容走 raw 域名，不占这 60 次）。扩展顶部弹窗会显示剩余次数。

如果接口额度用完，或仓库文件太多导致文件清单被截断，会自动改用备用方案：

1. 从 `codeload.github.com` 下载整个仓库的 ZIP（不占 API 额度）；
2. 在本地只提取目标文件夹，再重新打包。

备用方案不需要登录，但需要先下载整个仓库；仓库压缩包超过 300 MB 时会停止并提示。成功时 ZIP 文件名和信息与正常方案一致。

## 限制

- 仅支持**公开仓库**。私有仓库必须登录，本扩展不处理登录态。
- 子模块（submodule）不会下载其内容；Git LFS 文件只会得到指针文件（GitHub 未登录接口的限制）。
- 单个文件夹打包后上限约 1.5 GB；单文件超过 100 MB 时 GitHub raw 可能拒绝。
- 文件数超过 65,535 个的文件夹暂不支持打包（ZIP 格式限制）。
- 文件名会做 Windows 合法化处理；ZIP 内保留原始相对路径。
- GitHub 页面结构更新可能导致按钮找不到；刷新页面或更新扩展即可。

## 常见问题

**页面右下角没有按钮？**

- 确认当前页面是仓库首页或文件夹页面，不是单个文件页面（`/blob/`）。
- 刷新页面；刚安装扩展后已打开的 GitHub 标签页需要刷新一次。
- 确认扩展已启用，且地址是 `github.com`。

**提示「找不到仓库或分支」？**

- 未登录只能下载公开仓库；确认仓库没有设为私有。
- 确认分支/标签仍然存在，链接没有拼错。

**提示「GitHub 接口额度已用完」？**

- 等额度重置（弹窗会显示恢复时间），或让扩展自动走整仓 ZIP 提取方案。
- 共享出口 IP 可能被别人提前用完额度，这是 GitHub 对未登录请求的限制。

**下载失败/一直转圈？**

- 点击提示框里的「重试」；或刷新页面后重新点。
- 检查网络是否能访问 `api.github.com`、`raw.githubusercontent.com`、`codeload.github.com`。
- 如果网络需要代理，请确保浏览器代理覆盖这三个域名。

**为什么扩展要求「下载」权限？**

只用于把本地生成的 ZIP 交给浏览器保存。扩展不读取、不上传你的下载记录。

## 隐私

- 不收集、不上传任何数据。
- 不读取 GitHub 登录 Cookie，不使用 Token。
- 只请求你当前打开的公开仓库的 GitHub 接口和文件地址。
- ZIP 完全在本地生成。

## 开发与测试

核心逻辑不依赖浏览器，可直接用 Node 测试：

```powershell
node test/test-zip.mjs
$env:HTTPS_PROXY='http://127.0.0.1:7890'; $env:HTTP_PROXY='http://127.0.0.1:7890'
node --use-env-proxy test/test-core.mjs
```

浏览器端到端测试（需要 Edge，会临时加载扩展）：

```powershell
node test/e2e.mjs
node test/e2e-headful.mjs
```

说明：无头浏览器通过 CDP 下载时会把文件名改成随机 UUID（浏览器限制），真实浏览器中文件名正常；`e2e-headful.mjs` 会验证真实文件名和连续多次下载。

## 目录结构

```text
manifest.json          扩展清单（MV3）
src/background.js      Service Worker：任务调度、下载保存
src/content.js         页面注入：按钮、子文件夹图标、进度提示
src/content.css        注入 UI 样式
src/offscreen.html     offscreen 文档
src/offscreen.js       下载任务执行器
src/core.js            GitHub API / raw / 整仓 ZIP 备用逻辑
src/zip.js             无依赖 ZIP 读写实现
src/popup.*            工具栏弹窗（额度、说明）
icons/                 扩展图标
docs/                  截图
```

const quotaText = document.getElementById('quotaText');
const quotaBar = document.getElementById('quotaBar');
const quotaNote = document.getElementById('quotaNote');
const refresh = document.getElementById('refresh');

function formatReset(epochSeconds) {
  if (!epochSeconds) return '';
  const date = new Date(epochSeconds * 1000);
  return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
}

async function loadQuota() {
  refresh.disabled = true;
  quotaText.textContent = '正在查询…';
  quotaNote.textContent = '每次下载文件夹消耗 1 次接口额度';
  try {
    const response = await fetch('https://api.github.com/rate_limit', {
      headers: { Accept: 'application/vnd.github+json' },
      cache: 'no-store',
      credentials: 'omit',
    });
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const data = await response.json();
    const core = data && data.resources && data.resources.core;
    if (!core) throw new Error('bad data');
    const remaining = Number(core.remaining) || 0;
    const limit = Number(core.limit) || 60;
    quotaText.textContent = '剩余 ' + remaining + ' / ' + limit + ' 次';
    quotaBar.style.width = Math.max(2, Math.round((remaining / limit) * 100)) + '%';
    quotaBar.style.background = remaining <= 5 ? '#d1242f' : '';
    const reset = formatReset(core.reset);
    quotaNote.textContent = reset
      ? '额度按小时重置，约 ' + reset + ' 恢复'
      : '每次下载文件夹消耗 1 次接口额度';
  } catch (error) {
    quotaText.textContent = '暂时无法查询';
    quotaBar.style.width = '0%';
    quotaNote.textContent = '不影响下载，只是查不到剩余额度';
  } finally {
    refresh.disabled = false;
  }
}

refresh.addEventListener('click', loadQuota);
loadQuota();

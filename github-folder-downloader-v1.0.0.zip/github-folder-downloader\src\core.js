/*
 * Core download logic: GitHub tree API + raw files, with whole-repo ZIP fallback.
 * Runs inside the offscreen document (and Node tests).
 */
(function (global) {
  'use strict';

  const API_ROOT = 'https://api.github.com';
  const RAW_ROOT = 'https://raw.githubusercontent.com';
  const CODELOAD_ROOT = 'https://codeload.github.com';
  const MAX_OUTPUT_BYTES = 1.5 * 1024 * 1024 * 1024;
  const MAX_ARCHIVE_BYTES = 300 * 1024 * 1024;
  const CONCURRENCY = 8;
  const DOWNLOAD_TIMEOUT_MS = 60000;

  const TEXT_EXTENSIONS = new Set(
    ('txt md markdown rst adoc html htm xhtml css scss sass less styl js mjs cjs jsx ts tsx mts cts ' +
      'json jsonc json5 yml yaml toml ini cfg conf env properties xml svg vue svelte astro ' +
      'c h cc cpp cxx hpp hh cs java kt kts scala go rs rb php py pyw sh bash zsh fish bat cmd ps1 ' +
      'sql graphql gql proto cmake mk gradle sbt lock gitignore gitattributes dockerfile makefile ' +
      'tex bib csv tsv r lua pl pm dart ex exs erl hs clj cljs f90 f95 asm s v sv vhd').split(/\s+/)
  );
  const STORE_EXTENSIONS = new Set(
    ('png jpg jpeg gif webp avif ico bmp tif tiff psd pdf zip gz tgz bz2 xz 7z rar zst ' +
      'mp3 mp4 m4a m4v mov avi mkv webm flac ogg opus wav aac woff woff2 ttf otf eot ' +
      'jar war apk ipa dmg iso exe dll so dylib node wasm').split(/\s+/)
  );

  class AppError extends Error {
    constructor(message, code = 'ERROR', meta = {}) {
      super(message);
      this.name = 'AppError';
      this.code = code;
      Object.assign(this, meta);
    }
  }

  class FallbackError extends AppError {
    constructor(message, code = 'FALLBACK') {
      super(message, code);
      this.name = 'FallbackError';
    }
  }

  function abortError() {
    return new DOMException('Aborted', 'AbortError');
  }

  function checkAbort(signal) {
    if (signal && signal.aborted) throw abortError();
  }

  function sleep(ms, signal) {
    return new Promise((resolve, reject) => {
      if (signal && signal.aborted) return reject(abortError());
      const timer = setTimeout(() => {
        if (signal) signal.removeEventListener('abort', onAbort);
        resolve();
      }, ms);
      const onAbort = () => {
        clearTimeout(timer);
        reject(abortError());
      };
      if (signal) signal.addEventListener('abort', onAbort, { once: true });
    });
  }

  function formatBytes(bytes) {
    if (!bytes) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB'];
    let i = 0;
    let n = bytes;
    while (n >= 1024 && i < units.length - 1) {
      n /= 1024;
      i++;
    }
    const digits = n >= 100 || i === 0 ? 0 : n >= 10 ? 1 : 2;
    return n.toFixed(digits) + ' ' + units[i];
  }

  function sanitizePart(value) {
    return String(value)
      .replace(/[\\/:*?"<>|\u0000-\u001f]/g, '-')
      .replace(/\s+/g, ' ')
      .replace(/^[.\s]+|[.\s]+$/g, '')
      .slice(0, 100) || 'download';
  }

  function normalizeBasePath(value) {
    const parts = String(value || '')
      .replace(/\\/g, '/')
      .split('/')
      .filter((part) => part && part !== '.');
    if (parts.some((part) => part === '..')) throw new AppError('文件夹路径无效', 'BAD_PATH');
    return parts.join('/');
  }

  function encodeRef(ref) {
    return String(ref)
      .split('/')
      .map((part) => encodeURIComponent(part))
      .join('/');
  }

  function encodePath(path) {
    return String(path)
      .split('/')
      .map((part) => encodeURIComponent(part))
      .join('/');
  }

  function rawFileUrl({ owner, repo, ref, path }) {
    return (
      RAW_ROOT +
      '/' +
      encodeURIComponent(owner) +
      '/' +
      encodeURIComponent(repo) +
      '/' +
      encodeRef(ref) +
      '/' +
      encodePath(path)
    );
  }

  function validateJob(job) {
    const owner = String(job.owner || '').trim();
    const repo = String(job.repo || '').trim();
    const ref = String(job.ref || '').trim();
    if (!owner || !repo || !ref) throw new AppError('页面信息不完整，请刷新 GitHub 页面后重试', 'BAD_JOB');
    if (!/^[\w.-]+$/.test(owner) || !/^[\w.-]+$/.test(repo)) {
      throw new AppError('仓库名称无效', 'BAD_JOB');
    }
    return {
      owner,
      repo,
      ref,
      path: normalizeBasePath(job.path),
    };
  }

  function shouldCompress(relPath, size) {
    if (size === 0) return false;
    const dot = relPath.lastIndexOf('.');
    const ext = dot >= 0 ? relPath.slice(dot + 1).toLowerCase() : '';
    if (STORE_EXTENSIONS.has(ext)) return false;
    if (TEXT_EXTENSIONS.has(ext)) return size < 32 * 1024 * 1024;
    return size < 8 * 1024 * 1024;
  }

  function zipLayout({ repo, ref, base }) {
    if (base) {
      const folderName = base.split('/').pop();
      return {
        root: sanitizePart(folderName),
        filename: sanitizePart(repo + '-' + folderName) + '.zip',
      };
    }
    const suffix = sanitizePart(ref);
    return {
      root: sanitizePart(repo + '-' + suffix),
      filename: sanitizePart(repo + '-' + suffix) + '.zip',
    };
  }

  async function fetchWithRetry(url, options = {}) {
    const { signal, attempts = 3, headers = {}, what = '文件' } = options;
    let lastError = null;
    for (let attempt = 1; attempt <= attempts; attempt++) {
      checkAbort(signal);
      const timeout = AbortSignal.timeout(DOWNLOAD_TIMEOUT_MS);
      const combined = signal ? AbortSignal.any([signal, timeout]) : timeout;
      try {
        const response = await fetch(url, {
          signal: combined,
          headers,
          cache: 'no-store',
          credentials: 'omit',
        });
        if (response.ok) return response;
        if (response.status === 404) {
          throw new AppError(`${what}不存在或无法访问`, 'NOT_FOUND');
        }
        if (response.status === 401 || response.status === 403 || response.status === 429) {
          // Rate limits are handled by the caller for API calls; for raw files just retry once.
          if (attempt >= attempts) {
            throw new AppError(`GitHub 拒绝访问（${response.status}），请稍后再试`, 'HTTP_' + response.status);
          }
        } else if (attempt >= attempts) {
          throw new AppError(`GitHub 返回错误（${response.status}）`, 'HTTP_' + response.status);
        }
        lastError = new AppError(`HTTP ${response.status}`, 'HTTP_' + response.status);
      } catch (e) {
        if (signal && signal.aborted) throw abortError();
        if (e instanceof AppError && e.code === 'NOT_FOUND') throw e;
        lastError = e;
        if (attempt >= attempts) {
          if (e instanceof AppError) throw e;
          throw new AppError(`网络请求失败：${e.message || e}`, 'NETWORK');
        }
      }
      const delay = 500 * Math.pow(2, attempt - 1) + Math.floor(Math.random() * 250);
      await sleep(delay, signal);
    }
    throw lastError instanceof AppError ? lastError : new AppError('网络请求失败', 'NETWORK');
  }

  async function fetchTree({ owner, repo, ref, signal, update }) {
    const url =
      API_ROOT +
      '/repos/' +
      encodeURIComponent(owner) +
      '/' +
      encodeURIComponent(repo) +
      '/git/trees/' +
      encodeURIComponent(ref) +
      '?recursive=1';
    let response;
    try {
      response = await fetch(url, {
        signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(DOWNLOAD_TIMEOUT_MS)]) : AbortSignal.timeout(DOWNLOAD_TIMEOUT_MS),
        headers: {
          Accept: 'application/vnd.github+json',
          'X-GitHub-Api-Version': '2022-11-28',
        },
        cache: 'no-store',
        credentials: 'omit',
      });
    } catch (e) {
      if (signal && signal.aborted) throw abortError();
      if (e.name === 'TimeoutError') throw new AppError('GitHub 接口超时，请稍后再试', 'NETWORK');
      throw new AppError('无法连接 GitHub 接口，请检查网络后重试', 'NETWORK');
    }

    const remaining = Number(response.headers.get('x-ratelimit-remaining'));
    const limit = Number(response.headers.get('x-ratelimit-limit'));
    const resetAt = Number(response.headers.get('x-ratelimit-reset'));
    const rate = {
      remaining: Number.isFinite(remaining) ? remaining : null,
      limit: Number.isFinite(limit) ? limit : null,
      resetAt: Number.isFinite(resetAt) ? resetAt : null,
    };

    if (response.status === 403 || response.status === 429) {
      let body = null;
      try { body = await response.json(); } catch (e) {}
      const isRateLimit = rate.remaining === 0 || /rate limit/i.test(String(body && body.message));
      if (isRateLimit) {
        const when = rate.resetAt ? new Date(rate.resetAt * 1000).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }) : '';
        throw new FallbackError(
          `GitHub 接口额度已用完${when ? `（约 ${when} 恢复）` : ''}`,
          'RATE_LIMIT'
        );
      }
      throw new AppError(body && body.message ? `GitHub 接口拒绝请求：${body.message}` : 'GitHub 接口拒绝请求', 'API_403');
    }

    if (response.status === 404) {
      throw new AppError('找不到这个仓库或分支。未登录时只能下载公开仓库，请确认链接有效。', 'NOT_FOUND');
    }
    if (response.status === 409) {
      throw new AppError('仓库是空的，没有文件可下载。', 'EMPTY_REPO');
    }
    if (!response.ok) {
      throw new AppError(`GitHub 接口返回错误（${response.status}）`, 'HTTP_' + response.status);
    }

    let data;
    try {
      data = await response.json();
    } catch (e) {
      throw new AppError('GitHub 接口返回了无法解析的数据', 'BAD_RESPONSE');
    }
    if (!data || !Array.isArray(data.tree)) {
      throw new AppError('GitHub 接口返回了意外的数据', 'BAD_RESPONSE');
    }
    if (data.truncated) {
      throw new FallbackError('仓库文件太多，GitHub 单次返回的文件列表被截断', 'TRUNCATED');
    }

    if (update) {
      update({ phase: 'list', text: '已找到文件列表，正在整理…', rate });
    }
    return data.tree;
  }

  function listFolder(tree, base) {
    const prefix = base ? base + '/' : '';
    const files = [];
    let submodules = 0;
    for (const item of tree) {
      if (base && !item.path.startsWith(prefix)) continue;
      if (item.type === 'commit') {
        submodules++;
        continue;
      }
      if (item.type !== 'blob') continue;
      files.push({
        path: item.path,
        relPath: base ? item.path.slice(prefix.length) : item.path,
        size: Number(item.size) || 0,
        sha: item.sha || '',
      });
    }
    files.sort((a, b) => a.relPath.localeCompare(b.relPath, 'en'));
    return { files, submodules };
  }

  async function downloadOneFile({ owner, repo, ref, file, signal }) {
    const url = rawFileUrl({ owner, repo, ref, path: file.path });
    const response = await fetchWithRetry(url, {
      signal,
      attempts: 4,
      what: `文件 ${file.relPath}`,
    });
    const buffer = await response.arrayBuffer();
    return new Uint8Array(buffer);
  }

  async function downloadFiles({ owner, repo, ref, files, signal, onProgress }) {
    if (files.length === 0) return { results: [], failed: [] };
    const totalBytes = files.reduce((sum, file) => sum + file.size, 0);
    const results = new Array(files.length);
    const failed = [];
    let index = 0;
    let done = 0;
    let bytes = 0;

    const worker = async () => {
      while (true) {
        const current = index++;
        if (current >= files.length) return;
        checkAbort(signal);
        const file = files[current];
        try {
          const data = await downloadOneFile({ owner, repo, ref, file, signal });
          results[current] = { ...file, data };
          bytes += data.length;
        } catch (e) {
          if (signal && signal.aborted) throw abortError();
          if (e instanceof AppError && e.code === 'NOT_FOUND') {
            failed.push({ path: file.relPath, reason: '文件不存在（可能已被删除）' });
          } else {
            failed.push({ path: file.relPath, reason: e.message || String(e) });
          }
        }
        done++;
        onProgress({ done, total: files.length, bytes, totalBytes, file: file.relPath });
      }
    };

    const workers = Array.from({ length: Math.min(CONCURRENCY, files.length) }, () => worker());
    await Promise.all(workers);

    const successfully = results.filter(Boolean);
    if (successfully.length === 0 && failed.length > 0) {
      throw new AppError(`所有文件都下载失败：${failed[0].reason}`, 'ALL_FILES_FAILED');
    }
    return { results: successfully, failed };
  }

  async function buildZip({ files, root, signal, onProgress }) {
    const { ZipBuilder } = global.GHFDZip;
    const builder = new ZipBuilder({ compress: true });
    let done = 0;
    for (const file of files) {
      checkAbort(signal);
      const name = root + '/' + file.relPath;
      await builder.addFile(name, file.data, {
        compress: shouldCompress(file.relPath, file.data.length),
      });
      done++;
      if (done % 10 === 0 || done === files.length) {
        onProgress({ done, total: files.length });
      }
    }
    return builder.finish();
  }

  async function readResponseWithProgress(response, { signal, update, maxBytes }) {
    const totalHeader = Number(response.headers.get('content-length'));
    const totalBytes = Number.isFinite(totalHeader) && totalHeader > 0 ? totalHeader : 0;
    if (totalBytes > maxBytes) {
      throw new AppError(`整仓压缩包太大（${formatBytes(totalBytes)}），超过 300 MB 的备用方案上限。`, 'ARCHIVE_TOO_BIG');
    }
    if (!response.body) {
      const buffer = new Uint8Array(await response.arrayBuffer());
      if (buffer.length > maxBytes) throw new AppError('整仓压缩包超过 300 MB 上限。', 'ARCHIVE_TOO_BIG');
      return buffer;
    }
    const reader = response.body.getReader();
    const onAbort = () => { reader.cancel().catch(() => {}); };
    if (signal) signal.addEventListener('abort', onAbort, { once: true });
    const chunks = [];
    let received = 0;
    let lastReport = 0;
    try {
      for (;;) {
        checkAbort(signal);
        const { done, value } = await reader.read();
        if (done) break;
        if (value) {
          chunks.push(value);
          received += value.length;
          if (received > maxBytes) {
            try { await reader.cancel(); } catch (e) {}
            throw new AppError(`整仓压缩包超过 ${formatBytes(maxBytes)} 上限，已停止下载。`, 'ARCHIVE_TOO_BIG');
          }
          const now = Date.now();
          if (update && now - lastReport > 200) {
            lastReport = now;
            update({
              phase: 'archive-download',
              text: `正在下载整仓压缩包 ${formatBytes(received)}${totalBytes ? ' / ' + formatBytes(totalBytes) : ''}`,
              bytes: received,
              totalBytes,
            });
          }
        }
      }
      checkAbort(signal);
      const buffer = new Uint8Array(received);
      let offset = 0;
      for (const chunk of chunks) {
        buffer.set(chunk, offset);
        offset += chunk.length;
      }
      return buffer;
    } finally {
      if (signal) signal.removeEventListener('abort', onAbort);
    }
  }

  async function runArchiveDownload({ owner, repo, ref, path: base }, { signal, update = () => {}, reason }) {
    const url = CODELOAD_ROOT + '/' + encodeURIComponent(owner) + '/' + encodeURIComponent(repo) + '/zip/' + encodeRef(ref);
    update({
      phase: 'archive-download',
      text: '正在下载整个仓库的 ZIP（备用方案）…',
      note: reason || '',
    });

    let response;
    try {
      response = await fetch(url, {
        signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(10 * 60 * 1000)]) : AbortSignal.timeout(10 * 60 * 1000),
        cache: 'no-store',
        credentials: 'omit',
      });
    } catch (e) {
      if (signal && signal.aborted) throw abortError();
      if (e.name === 'TimeoutError') throw new AppError('整仓压缩包下载超时，请稍后再试。', 'NETWORK');
      throw new AppError('无法下载整仓压缩包，请检查网络。', 'NETWORK');
    }
    if (response.status === 404) {
      throw new AppError('无法获取整仓压缩包：分支或仓库不存在。', 'NOT_FOUND');
    }
    if (!response.ok) {
      throw new AppError(`整仓压缩包下载失败（HTTP ${response.status}），请稍后再试。`, 'HTTP_' + response.status);
    }

    const archive = await readResponseWithProgress(response, { signal, update, maxBytes: MAX_ARCHIVE_BYTES });
    checkAbort(signal);

    update({ phase: 'archive-extract', text: '正在读取整仓压缩包…', done: 0, total: 0 });

    const { parseZipDirectory, readZipEntryRaw } = global.GHFDZip;
    let entries;
    try {
      entries = parseZipDirectory(archive);
    } catch (e) {
      throw new AppError('整仓压缩包格式无法解析：' + (e.message || e), 'BAD_ARCHIVE');
    }

    const firstFile = entries.find((entry) => entry.name.includes('/'));
    if (!firstFile) throw new AppError('整仓压缩包里没有文件。', 'EMPTY_ARCHIVE');
    const archiveRoot = firstFile.name.split('/')[0];
    const prefix = archiveRoot + '/' + (base ? base + '/' : '');
    const selected = entries.filter((entry) => !entry.isDirectory && entry.name.startsWith(prefix));

    if (selected.length === 0) {
      throw new AppError('整仓压缩包里没有找到这个文件夹，可能分支已更新，请刷新页面重试。', 'FOLDER_NOT_FOUND');
    }

    const outputTotal = selected.reduce((sum, entry) => sum + entry.uncompSize, 0);
    if (outputTotal > MAX_OUTPUT_BYTES) {
      throw new AppError(`该文件夹解压后约 ${formatBytes(outputTotal)}，超过 1.5 GB 的打包上限。`, 'TOO_BIG');
    }

    const layout = zipLayout({ repo, ref, base });
    const builder = new global.GHFDZip.ZipBuilder({ compress: false });
    let done = 0;
    let outBytes = 0;
    let lastReport = 0;
    for (const entry of selected) {
      checkAbort(signal);
      const relPath = entry.name.slice(prefix.length);
      let rawEntry;
      try {
        rawEntry = readZipEntryRaw(archive, entry);
      } catch (e) {
        throw new AppError(`解压失败（${relPath}）：${e.message || e}`, 'BAD_ARCHIVE');
      }
      outBytes += entry.uncompSize;
      builder.addRawFile(layout.root + '/' + relPath, rawEntry.data, rawEntry);
      done++;
      const now = Date.now();
      if (now - lastReport > 150 || done === selected.length) {
        lastReport = now;
        update({
          phase: 'archive-extract',
          text: `正在从整仓压缩包中提取 ${done}/${selected.length} 个文件`,
          done,
          total: selected.length,
          bytes: outBytes,
          totalBytes: outputTotal,
          note: reason || '',
        });
      }
    }

    const blob = builder.finish();
    return {
      blob,
      filename: layout.filename,
      fileCount: selected.length,
      totalBytes: outBytes,
      mode: 'archive',
      skipped: [],
      note: '已从整仓 ZIP 中提取（未消耗 GitHub API 额度）',
    };
  }

  async function runFolderJob(job, options) {
    const { signal, update = () => {} } = options || {};
    const normalized = validateJob(job);
    const start = Date.now();
    try {
      let listing;
      try {
        listing = await listFolderForJob(normalized, signal, update);
      } catch (e) {
        if (signal && signal.aborted) throw abortError();
        if (e instanceof FallbackError || e.code === 'RATE_LIMIT' || e.code === 'TRUNCATED') {
          const reason =
            e.code === 'RATE_LIMIT'
              ? e.message + '，自动改用整仓 ZIP 提取（约需下载整个仓库）'
              : '文件列表过大，自动改用整仓 ZIP 提取';
          const result = await runArchiveDownload(normalized, { signal, update, reason });
          return { ...result, elapsed: Date.now() - start };
        }
        throw e;
      }

      const result = await runTreeDownloadWithListing(normalized, listing, { signal, update });
      return { ...result, elapsed: Date.now() - start };
    } catch (e) {
      if (signal && signal.aborted) throw abortError();
      if (e instanceof AppError) throw e;
      throw new AppError(e.message || String(e), 'UNEXPECTED');
    }
  }

  async function listFolderForJob({ owner, repo, ref, path }, signal, update) {
    update({ phase: 'list', text: '正在向 GitHub 查询文件列表…' });
    const tree = await fetchTree({ owner, repo, ref, signal, update });
    return listFolder(tree, path);
  }

  async function runTreeDownloadWithListing({ owner, repo, ref, path: base }, { files, submodules }, { signal, update }) {
    if (files.length === 0) {
      throw new AppError(
        submodules > 0
          ? '这个文件夹里只有子模块（submodule），没有可直接下载的文件。'
          : '这个文件夹是空的，没有可下载的文件。',
        'EMPTY'
      );
    }
    const totalBytes = files.reduce((sum, file) => sum + file.size, 0);
    if (totalBytes > MAX_OUTPUT_BYTES) {
      throw new AppError(`文件夹太大（约 ${formatBytes(totalBytes)}），超过扩展 1.5 GB 的打包上限。`, 'TOO_BIG');
    }

    const note = submodules > 0 ? `已跳过 ${submodules} 个子模块（GitHub 不提供其文件内容）` : '';
    update({
      phase: 'download',
      text: `开始下载 ${files.length} 个文件（共 ${formatBytes(totalBytes)}）…`,
      done: 0,
      total: files.length,
      bytes: 0,
      totalBytes,
      note,
    });

    const { results, failed } = await downloadFiles({
      owner, repo, ref, files, signal,
      onProgress: (progress) => {
        update({
          phase: 'download',
          text: `正在下载文件 ${progress.done}/${progress.total}`,
          done: progress.done,
          total: progress.total,
          bytes: progress.bytes,
          totalBytes: progress.totalBytes,
          file: progress.file,
          note,
        });
      },
    });
    if (results.length === 0) throw new AppError('没有成功下载任何文件', 'ALL_FILES_FAILED');

    const layout = zipLayout({ repo, ref, base });
    update({ phase: 'zip', text: '正在打包 ZIP…', done: 0, total: results.length, note });
    const blob = await buildZip({
      files: results,
      root: layout.root,
      signal,
      onProgress: (p) => update({ phase: 'zip', text: '正在打包 ZIP…', done: p.done, total: p.total, note }),
    });

    return {
      blob,
      filename: layout.filename,
      fileCount: results.length,
      totalBytes: results.reduce((sum, file) => sum + file.data.length, 0),
      mode: 'tree',
      skipped: failed,
      note: failed.length ? `${failed.length} 个文件下载失败，已跳过` : note,
    };
  }

  global.GHFD = {
    AppError,
    FallbackError,
    formatBytes,
    rawFileUrl,
    validateJob,
    runFolderJob,
    runArchiveDownload,
    listFolder,
    fetchTree,
    shouldCompress,
    zipLayout,
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = global.GHFD;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);

/* GitHub 文件夹下载器 - content script */
(() => {
  'use strict';

  const CHANNEL = 'ghfd';
  const ICON_DOWNLOAD =
    '<svg aria-hidden="true" viewBox="0 0 16 16" width="16" height="16" fill="currentColor">' +
    '<path d="M2.75 14A1.75 1.75 0 0 1 1 12.25v-2.5a.75.75 0 0 1 1.5 0v2.5c0 .138.112.25.25.25h10.5a.25.25 0 0 0 .25-.25v-2.5a.75.75 0 0 1 1.5 0v2.5A1.75 1.75 0 0 1 13.25 14Z"></path>' +
    '<path d="M7.25 7.389V2a.75.75 0 0 1 1.5 0v5.389l2.72-2.72a.751.751 0 0 1 1.06 1.06l-4 4a.751.751 0 0 1-1.06 0l-4-4a.751.751 0 0 1 1.06-1.06Z"></path>' +
    '</svg>';
  const ICON_SMALL =
    '<svg aria-hidden="true" viewBox="0 0 16 16" width="15" height="15" fill="currentColor">' +
    '<path d="M2.75 14A1.75 1.75 0 0 1 1 12.25v-2.5a.75.75 0 0 1 1.5 0v2.5c0 .138.112.25.25.25h10.5a.25.25 0 0 0 .25-.25v-2.5a.75.75 0 0 1 1.5 0v2.5A1.75 1.75 0 0 1 13.25 14Z"></path>' +
    '<path d="M7.25 7.389V2a.75.75 0 0 1 1.5 0v5.389l2.72-2.72a.751.751 0 0 1 1.06 1.06l-4 4a.751.751 0 0 1-1.06 0l-4-4a.751.751 0 0 1 1.06-1.06Z"></path>' +
    '</svg>';

  let fab = null;
  let toast = null;
  let toastTimer = null;
  let activeJob = null;
  let lastRequest = null;
  let lastScriptText = '';
  let lastEmbedded = null;
  let lastHref = '';
  let refreshQueued = false;

  const $ = (sel, root = document) => root.querySelector(sel);

  function safeDecode(value) {
    try {
      return decodeURIComponent(value);
    } catch (e) {
      return value;
    }
  }

  function normalizePath(value) {
    return String(value || '')
      .replace(/\\/g, '/')
      .split('/')
      .filter((part) => part && part !== '.')
      .join('/');
  }

  function joinPath(base, name) {
    return [normalizePath(base), normalizePath(name)].filter(Boolean).join('/');
  }

  function readEmbedded() {
    const script = document.querySelector('react-app[app-name="code-view"] script[data-target="react-app.embeddedData"]');
    if (!script) return null;
    if (script.textContent === lastScriptText) return lastEmbedded;
    lastScriptText = script.textContent || '';
    try {
      lastEmbedded = JSON.parse(lastScriptText);
    } catch (e) {
      lastEmbedded = null;
    }
    return lastEmbedded;
  }

  function readEmbeddedInfo() {
    const data = readEmbedded();
    const payload = data && data.payload;
    if (!payload) return {};
    const repo = payload.codeViewLayoutRoute && payload.codeViewLayoutRoute.repo;
    const tree = payload.codeViewTreeRoute;
    return {
      defaultBranch: repo && repo.defaultBranch,
      repoName: repo && repo.name,
      ownerLogin: repo && repo.ownerLogin,
      refName: tree && tree.refInfo && tree.refInfo.name,
      treePath: tree && tree.path,
    };
  }

  function readRefLabel() {
    const button = document.querySelector('#ref-picker-repos-header-ref-selector');
    if (!button) return '';
    const label = (button.getAttribute('aria-label') || button.textContent || '').trim().replace(/^Commit\s+/i, '');
    const match = label.match(/^(?:Commit\s+)?(.+?)\s+(branch|tag)$/i);
    return match ? match[1].trim() : label;
  }

  function resolveRoute(owner, repo) {
    const parts = location.pathname.split('/').filter(Boolean).map(safeDecode);
    if (parts.length < 2) return null;
    if (parts[0].toLowerCase() !== owner.toLowerCase() || parts[1].toLowerCase() !== repo.toLowerCase()) return null;

    const info = readEmbeddedInfo();
    const labelRef = readRefLabel();

    if (parts.length === 2) {
      const ref = labelRef || info.refName || info.defaultBranch || '';
      if (!ref) return null;
      return { owner, repo, ref, path: '' };
    }

    if (parts[2] !== 'tree' || parts.length < 4) return null;
    const rest = parts.slice(3).join('/');
    if (!rest) return null;

    const candidates = [];
    if (labelRef) candidates.push(labelRef);
    if (info.refName) candidates.push(info.refName);

    for (const candidate of candidates) {
      if (!candidate) continue;
      if (rest === candidate) return { owner, repo, ref: candidate, path: '' };
      if (rest.startsWith(candidate + '/')) {
        return { owner, repo, ref: candidate, path: normalizePath(rest.slice(candidate.length + 1)) };
      }
    }

    // Commit pages show a shortened SHA in the ref picker; the URL has the full one.
    const firstSegment = rest.split('/')[0];
    if (
      /^[0-9a-f]{40}$/i.test(firstSegment) &&
      labelRef &&
      /^[0-9a-f]{7,12}$/i.test(labelRef) &&
      firstSegment.toLowerCase().startsWith(labelRef.toLowerCase())
    ) {
      return { owner, repo, ref: firstSegment, path: normalizePath(rest.slice(firstSegment.length + 1)) };
    }

    return null;
  }
  function readContext() {
    const meta = document.querySelector('meta[name="octolytics-dimension-repository_nwo"]');
    if (!meta || !meta.content) return null;
    const [owner, repo] = meta.content.split('/');
    if (!owner || !repo) return null;

    const route = resolveRoute(owner, repo);
    if (!route) return null;
    const folderName = route.path ? route.path.split('/').pop() : repo;
    return {
      ...route,
      folderName,
      isRoot: !route.path,
      key: owner + '/' + repo + '@' + route.ref + '/' + route.path,
    };
  }

  /* ---------------- floating button ---------------- */

  function ensureFab() {
    if (fab) return fab;
    fab = document.createElement('div');
    fab.id = 'ghfd-fab';
    fab.className = 'ghfd-fab';
    fab.hidden = true;
    fab.innerHTML =
      '<button type="button" class="ghfd-fab-btn" aria-label="下载当前文件夹">' +
      '<span class="ghfd-fab-icon">' + ICON_DOWNLOAD + '</span>' +
      '<span class="ghfd-fab-label">下载此文件夹</span>' +
      '</button>';
    fab.querySelector('button').addEventListener('click', onFabClick);
    document.body.appendChild(fab);
    return fab;
  }

  function updateFab(context) {
    ensureFab();
    if (!context) {
      fab.hidden = true;
      return;
    }
    fab.hidden = false;
    const button = fab.querySelector('button');
    const label = fab.querySelector('.ghfd-fab-label');
    const busy = activeJob && !activeJob.finished;
    button.disabled = !!busy;
    button.classList.toggle('is-busy', !!busy);
    label.textContent = busy ? '正在下载…' : '下载此文件夹';
    button.title = context.path
      ? `打包 ${context.owner}/${context.repo} 中的 ${context.path}/`
      : `打包整个仓库 ${context.owner}/${context.repo}`;
    fab.dataset.contextKey = context.key;
  }

  function onFabClick() {
    if (activeJob && !activeJob.finished) return;
    const context = readContext();
    if (!context) {
      showErrorToast({ message: '还没有读取到当前文件夹信息，请稍后再试或刷新页面。' });
      return;
    }
    startJob(context, context.path, context.folderName);
  }

  /* ---------------- row buttons ---------------- */

  function injectRowButtons() {
    const rows = document.querySelectorAll('tr.react-directory-row');
    if (!rows.length) return;
    for (const row of rows) {
      if (row.querySelector('.ghfd-row-btn')) continue;
      if (!row.querySelector('svg.icon-directory')) continue;
      const link = row.querySelector('.react-directory-truncate a[title]');
      const name = link && link.getAttribute('title');
      if (!name) continue;

      const cell = document.createElement('td');
      cell.className = 'ghfd-row-action-cell';
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'ghfd-row-btn';
      button.title = `下载「${name}」文件夹`;
      button.setAttribute('aria-label', `下载 ${name} 文件夹`);
      button.innerHTML = ICON_SMALL;
      const stop = (event) => {
        event.preventDefault();
        event.stopPropagation();
      };
      button.addEventListener('pointerdown', stop);
      button.addEventListener('mousedown', stop);
      button.addEventListener('click', (event) => {
        stop(event);
        if (activeJob && !activeJob.finished) return;
        const context = readContext();
        if (!context) return;
        startJob(context, joinPath(context.path, name), name);
      });
      cell.appendChild(button);
      row.appendChild(cell);
    }
  }

  /* ---------------- toast ---------------- */

  function ensureToast() {
    if (toast) return toast;
    toast = document.createElement('div');
    toast.id = 'ghfd-toast';
    toast.className = 'ghfd-toast';
    toast.hidden = true;
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');
    toast.innerHTML =
      '<div class="ghfd-toast-head">' +
      '  <div class="ghfd-toast-title">下载</div>' +
      '  <button type="button" class="ghfd-toast-close" aria-label="关闭">' +
      '    <svg viewBox="0 0 16 16" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.751.751 0 1 1 1.06 1.06L9.06 8l3.22 3.22a.751.751 0 1 1-1.06 1.06L8 9.06l-3.22 3.22a.751.751 0 0 1-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path></svg>' +
      '  </button>' +
      '</div>' +
      '<div class="ghfd-toast-progress"><span class="ghfd-toast-bar"></span></div>' +
      '<div class="ghfd-toast-status"></div>' +
      '<div class="ghfd-toast-detail"></div>' +
      '<div class="ghfd-toast-note"></div>' +
      '<div class="ghfd-toast-actions">' +
      '  <button type="button" class="ghfd-btn ghfd-btn-secondary ghfd-toast-cancel">取消</button>' +
      '  <button type="button" class="ghfd-btn ghfd-btn-primary ghfd-toast-retry" hidden>重试</button>' +
      '  <button type="button" class="ghfd-btn ghfd-btn-secondary ghfd-toast-hide" hidden>关闭</button>' +
      '</div>';
    document.body.appendChild(toast);

    $('.ghfd-toast-close', toast).addEventListener('click', hideToast);
    $('.ghfd-toast-hide', toast).addEventListener('click', hideToast);
    $('.ghfd-toast-cancel', toast).addEventListener('click', cancelJob);
    $('.ghfd-toast-retry', toast).addEventListener('click', retryJob);
    return toast;
  }

  function setToastVisible(visible) {
    const node = ensureToast();
    node.hidden = !visible;
    if (visible) node.classList.add('is-visible');
    else node.classList.remove('is-visible');
  }

  function clearToastTimer() {
    if (toastTimer) {
      clearTimeout(toastTimer);
      toastTimer = null;
    }
  }

  function hideToast() {
    clearToastTimer();
    if (toast) toast.hidden = true;
  }

  function scheduleHide(ms) {
    clearToastTimer();
    toastTimer = setTimeout(hideToast, ms);
  }

  function setToastPhase(phase) {
    const node = ensureToast();
    node.classList.remove('is-running', 'is-done', 'is-error', 'is-indeterminate');
    if (phase === 'running' || phase === 'indeterminate') node.classList.add('is-running');
    if (phase === 'indeterminate') node.classList.add('is-indeterminate');
    if (phase === 'done') node.classList.add('is-done');
    if (phase === 'error') node.classList.add('is-error');
  }

  function setProgress(percent, indeterminate) {
    const node = ensureToast();
    const bar = $('.ghfd-toast-bar', node);
    if (indeterminate) {
      bar.style.width = '35%';
      node.classList.add('is-indeterminate');
    } else {
      node.classList.remove('is-indeterminate');
      const value = Math.max(0, Math.min(100, Number(percent) || 0));
      bar.style.width = value + '%';
    }
  }

  function requestLabel(request) {
    return request.owner + '/' + request.repo + (request.path ? ' / ' + request.path : '');
  }

  function phaseRatio(payload) {
    if (!payload) return null;
    if (payload.phase === 'download' || payload.phase === 'archive-download' || payload.phase === 'archive-extract') {
      if (payload.totalBytes > 0 && typeof payload.bytes === 'number') return (payload.bytes / payload.totalBytes) * 100;
      if (payload.total > 0 && typeof payload.done === 'number') return (payload.done / payload.total) * 100;
    }
    if (payload.phase === 'zip') {
      if (payload.total > 0) return (payload.done / payload.total) * 100;
    }
    return null;
  }

  function showRunningToast(request) {
    clearToastTimer();
    const node = ensureToast();
    setToastVisible(true);
    setToastPhase('indeterminate');
    setProgress(0, true);
    $('.ghfd-toast-title', node).textContent = '正在打包 ' + requestLabel(request);
    $('.ghfd-toast-status', node).textContent = '正在连接 GitHub…';
    $('.ghfd-toast-detail', node).textContent = '';
    $('.ghfd-toast-note', node).textContent = '无需登录，直接从 GitHub 读取公开文件';
    $('.ghfd-toast-cancel', node).hidden = false;
    $('.ghfd-toast-cancel', node).disabled = false;
    $('.ghfd-toast-retry', node).hidden = true;
    $('.ghfd-toast-hide', node).hidden = true;
    $('.ghfd-toast-close', node).hidden = true;
  }

  function onProgress(payload) {
    if (!payload) return;
    const node = ensureToast();
    setToastVisible(true);

    if (payload.phase === 'list' || payload.phase === 'queued' || !payload.phase) {
      setToastPhase('indeterminate');
      setProgress(0, true);
    } else {
      setToastPhase('running');
      const ratio = phaseRatio(payload);
      if (ratio === null) setProgress(0, true);
      else setProgress(ratio, false);
    }

    const titles = {
      list: '正在获取文件列表',
      queued: '排队中',
      download: '正在下载文件',
      zip: '正在打包 ZIP',
      'archive-download': '正在下载整仓压缩包',
      'archive-extract': '正在提取文件',
    };
    if (payload.text) {
      $('.ghfd-toast-status', node).textContent = payload.text;
    } else if (titles[payload.phase]) {
      $('.ghfd-toast-status', node).textContent = titles[payload.phase] + '…';
    }

    const detail = [];
    if (payload.total > 0 && typeof payload.done === 'number') {
      detail.push(payload.done + ' / ' + payload.total + ' 个文件');
    }
    if (payload.file) detail.push(payload.file);
    $('.ghfd-toast-detail', node).textContent = detail.join(' · ');
    $('.ghfd-toast-note', node).textContent = payload.note || '';
  }

  function onDone(result) {
    if (!activeJob) return;
    const request = activeJob.request;
    activeJob.finished = true;
    updateFab(readContext());
    setToastVisible(true);
    setToastPhase('done');
    setProgress(100, false);
    const node = ensureToast();
    $('.ghfd-toast-title', node).textContent = '下载完成';
    $('.ghfd-toast-status', node).textContent = '已开始保存 ' + (result.filename || 'ZIP 文件');
    const parts = [];
    if (result.fileCount) parts.push(result.fileCount + ' 个文件');
    if (result.totalBytes) parts.push(formatBytes(result.totalBytes));
    if (result.elapsed) parts.push('用时 ' + Math.max(1, Math.round(result.elapsed / 1000)) + ' 秒');
    $('.ghfd-toast-detail', node).textContent = parts.join(' · ');
    $('.ghfd-toast-note', node).textContent = result.note || '';
    $('.ghfd-toast-cancel', node).hidden = true;
    $('.ghfd-toast-retry', node).hidden = true;
    $('.ghfd-toast-hide', node).hidden = false;
    $('.ghfd-toast-close', node).hidden = false;
    scheduleHide(12000);
    activeJob = null;
    lastRequest = null;
    updateFab(readContext());
  }

  function onError(error) {
    const node = ensureToast();
    setToastVisible(true);
    setToastPhase('error');
    setProgress(100, false);
    const message = (error && error.message) || String(error) || '未知错误';
    $('.ghfd-toast-title', node).textContent = '下载失败';
    $('.ghfd-toast-status', node).textContent = message;
    $('.ghfd-toast-detail', node).textContent = errorHint(error);
    $('.ghfd-toast-note', node).textContent = '';
    $('.ghfd-toast-cancel', node).hidden = true;
    $('.ghfd-toast-retry', node).hidden = !lastRequest;
    $('.ghfd-toast-hide', node).hidden = false;
    $('.ghfd-toast-close', node).hidden = false;
    if (activeJob) {
      activeJob.finished = true;
      activeJob = null;
    }
    updateFab(readContext());
  }

  function showErrorToast(error) {
    lastRequest = null;
    onError(error);
  }

  function errorHint(error) {
    const code = error && error.code;
    if (code === 'RATE_LIMIT') return 'GitHub 接口额度已用完，请稍后再试。';
    if (code === 'NOT_FOUND') return '确认仓库是公开的，且分支仍然存在。';
    if (code === 'ARCHIVE_TOO_BIG') return '可以稍等接口额度恢复后再试文件接口方式。';
    if (code === 'ALL_FILES_FAILED' || code === 'NETWORK') return '检查网络后点击“重试”。';
    return '';
  }

  function formatBytes(bytes) {
    if (!bytes) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB'];
    let value = bytes;
    let index = 0;
    while (value >= 1024 && index < units.length - 1) {
      value /= 1024;
      index++;
    }
    return value.toFixed(value >= 10 || index === 0 ? 0 : 1) + ' ' + units[index];
  }

  function cancelJob() {
    if (!activeJob) return;
    const node = ensureToast();
    $('.ghfd-toast-cancel', node).disabled = true;
    $('.ghfd-toast-status', node).textContent = '正在取消…';
    try {
      chrome.runtime.sendMessage({ channel: CHANNEL, type: 'cancel', jobId: activeJob.id });
    } catch (e) {
      // The job may already have finished.
    }
  }

  function retryJob() {
    if (!lastRequest) return;
    const request = lastRequest;
    hideToast();
    startJob(request, request.path, request.folderName);
  }

  function startJob(context, path, folderName) {
    if (activeJob && !activeJob.finished) return;
    const request = {
      owner: context.owner,
      repo: context.repo,
      ref: context.ref,
      path: normalizePath(path),
      folderName: folderName || (path ? String(path).split('/').pop() : context.repo),
    };
    lastRequest = request;
    const id = (globalThis.crypto && crypto.randomUUID) ? crypto.randomUUID() : Date.now() + '-' + Math.random().toString(16).slice(2);
    activeJob = { id, request, finished: false };
    showRunningToast(request);
    updateFab(readContext());

    const message = {
      channel: CHANNEL,
      type: 'start',
      job: {
        id,
        owner: request.owner,
        repo: request.repo,
        ref: request.ref,
        path: request.path,
        folderName: request.folderName,
        pageUrl: location.href,
      },
    };
    try {
      chrome.runtime.sendMessage(message).then((response) => {
        if (response && response.ok === false) {
          onError({ message: response.error || '无法启动下载', code: response.code });
        }
      }).catch((error) => {
        onError({ message: '无法连接扩展后台：' + (error.message || error), code: 'BG' });
      });
    } catch (error) {
      onError({ message: '扩展需要重新加载，请刷新页面后重试', code: 'BG' });
    }
  }

  /* ---------------- messages ---------------- */

  try {
    chrome.runtime.onMessage.addListener((message) => {
      if (!message || message.channel !== CHANNEL) return;
      if (!activeJob || message.jobId !== activeJob.id) return;
      if (message.type === 'progress') {
        onProgress(message.payload);
      } else if (message.type === 'done') {
        onDone(message.result || {});
      } else if (message.type === 'error') {
        onError(message.error || { message: '下载失败' });
      } else if (message.type === 'cancelled') {
        if (activeJob) activeJob.finished = true;
        activeJob = null;
        setToastPhase('running');
        setProgress(0, false);
        const node = ensureToast();
        $('.ghfd-toast-title', node).textContent = '已取消';
        $('.ghfd-toast-status', node).textContent = '下载已取消';
        $('.ghfd-toast-detail', node).textContent = '';
        $('.ghfd-toast-cancel', node).hidden = true;
        $('.ghfd-toast-retry', node).hidden = !lastRequest;
        $('.ghfd-toast-hide', node).hidden = false;
        $('.ghfd-toast-close', node).hidden = false;
        updateFab(readContext());
        scheduleHide(6000);
      }
    });
  } catch (e) {
    // Extension was reloaded; the page needs a refresh.
  }

  /* ---------------- refresh loop ---------------- */

  function refresh() {
    if (location.href !== lastHref) {
      lastHref = location.href;
      lastScriptText = '';
      lastEmbedded = null;
    }
    const context = readContext();
    if (!context) {
      if (fab) fab.hidden = true;
      return;
    }
    injectRowButtons();
    updateFab(context);
  }

  function queueRefresh() {
    if (refreshQueued) return;
    refreshQueued = true;
    setTimeout(() => {
      refreshQueued = false;
      refresh();
    }, 120);
  }

  const observer = new MutationObserver(queueRefresh);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  document.addEventListener('turbo:load', queueRefresh, true);
  document.addEventListener('pjax:end', queueRefresh, true);
  window.addEventListener('popstate', queueRefresh, true);
  setInterval(refresh, 800);
  refresh();
})();

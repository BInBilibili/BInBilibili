main.floors.MT22=
{
    "floorId": "MT22",
    "title": "魔塔 第22层",
    "name": "第 22 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,332,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  0, 87,  0,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  0,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  0,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  0, 88,  0,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 3,
    "defaultGround": "ground",
    "bgm": "section3.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,4": [
            "\r[gold]记事本可以开关自动拾取和自动清怪哦！\n\r[purple]【请注意开启时机，但魔王不会吞前两层捡到的属性了】",
            "想要修改三区怪物或穞堵臸猭畍强度吗?\n【不过自定义不能计入榜单！】\n（输入1为100%，请不要输入\"小数\"以及小于等于0的数哦喵）",
            {
                "type": "confirm",
                "text": "确认要修改怪物强度吗?",
                "yes": [
                    {
                        "type": "setValue",
                        "name": "flag:customize",
                        "value": "1"
                    },
                    {
                        "type": "confirm",
                        "text": "确认要修改三区怪物强度吗?\n（指6只史莱姆）",
                        "yes": [
                            {
                                "type": "input",
                                "text": "请输入一个数"
                            },
                            {
                                "type": "if",
                                "condition": "(flag:input<0)",
                                "true": [
                                    "都说了不要输入小于等于0的数！",
                                    {
                                        "type": "setValue",
                                        "name": "flag:set3",
                                        "value": "100"
                                    }
                                ],
                                "false": [
                                    {
                                        "type": "setValue",
                                        "name": "flag:set3",
                                        "value": "flag:input"
                                    }
                                ]
                            }
                        ],
                        "no": [
                            {
                                "type": "setValue",
                                "name": "flag:set3",
                                "value": "1"
                            }
                        ]
                    },
                    {
                        "type": "confirm",
                        "text": "确认要修改穞堵臸猭畍强度吗?",
                        "yes": [
                            {
                                "type": "input",
                                "text": "请输入一个数"
                            },
                            {
                                "type": "if",
                                "condition": "(flag:input<0)",
                                "true": [
                                    "都说了不要输入小于等于0的数！",
                                    {
                                        "type": "setValue",
                                        "name": "flag:set6",
                                        "value": "100"
                                    }
                                ],
                                "false": [
                                    {
                                        "type": "setValue",
                                        "name": "flag:set6",
                                        "value": "flag:input"
                                    }
                                ]
                            }
                        ],
                        "no": [
                            {
                                "type": "setValue",
                                "name": "flag:set6",
                                "value": "1"
                            }
                        ]
                    }
                ],
                "no": []
            }
        ]
    },
    "changeFloor": {
        "6,6": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "downFloor": [
        6,
        10
    ],
    "upFloor": [
        6,
        7
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}
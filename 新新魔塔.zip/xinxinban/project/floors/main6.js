main.floors.main6=
{
    "floorId": "main6",
    "title": "主塔  6F",
    "name": "6",
    "canFlyTo": true,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3, 40,  0, 87,  2,  2, 88,  2,217,  0,  0,  0,  3],
    [  3,  2,213,  2,  2,  2,  0,  2,  0,  2,  0,  2,  3],
    [  3, 23,210,  0,  0,  2,  0,  2,  0,  2,209,  0,  3],
    [  3,  2,  2,  2, 81,  2, 22,  2,  0,  2,  2,  0,  3],
    [  3,  0,206,  0,  0,  2, 21,  2,203,  2,  0,205,  3],
    [  3,  0,  2,  2,  2,  2,  0,  2,  0,  2, 81,  2,  3],
    [  3,  0,221, 81,  0,  2, 32,  2,  0,  2,  0,  0,  3],
    [  3,  2,  0,  2,  0,  2, 27,  2,  0,  2,  2,  0,  3],
    [  3,  2,  0,  2,  0,  2,  0,205,  0,  2,  0,217,  3],
    [  3,  2,253,  2,  0,  2,  0,  2,  2,  2,  0,  2,  3],
    [  3,  2, 27,  2,  0,203,  0,  2, 87,  0,  0, 31,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {},
    "changeFloor": {
        "3,1": {
            "floorId": "main7",
            "loc": [
                3,
                1
            ]
        },
        "8,11": {
            "floorId": "main7",
            "loc": [
                8,
                11
            ]
        },
        "6,1": {
            "floorId": "main5",
            "stair": "upFloor"
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "upFloor": [
        8,
        11
    ],
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "bgmap": [

],
    "fgmap": [

]
}
main.floors.base11=
{
    "floorId": "base11",
    "title": "地下  11F",
    "name": "-11",
    "canFlyTo": true,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3, 21, 21,  1,121, 87,  1,  1, 27, 27, 28, 28,  3],
    [  3, 21, 21,  1,  0,  0,219,  1, 31, 31, 31, 22,  3],
    [  3,  0,220,  1,  1,  1,219,  1, 59,  0,  0,  0,  3],
    [  3,122,  0,220, 58,  1,  0,  1,  1,  1, 85,  1,  3],
    [  3,  1, 82,  1,  1,  1,  0,  1,  0,230,  0,230,  3],
    [  3,  0,  0,231,  0,222,  0,222,  0,  0,  0,  0,  3],
    [  3,  0,231,  1,  1,  1, 81,  1,  1,  1,231,  1,  3],
    [  3,  1,231,  1, 21,  1, 81,  1, 21,  1, 81, 81,  3],
    [  3,  0,  0,  1,  0,225,212,225,  0,  1,  1, 81,  3],
    [  3, 82,  1,  1,  1,  1,  1,  1,  1,  1,  0,231,  3],
    [  3,219,  0,219,  0, 88,  1, 88,  0,219,  0,  0,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {
        "4,1": [
            "\t[老人,man]每个章只能安装对应的增幅器，而他们各自具有一种潜在能力，能不能用出来就看你的本事了。"
        ],
        "1,4": [
            "\t[商人,women]你和一些防御力超高的怪物战斗时，完全伤害不了它？\n这与攻击临界有关，当怪物防御大于你的“攻击力＋攻击临界”时，你就无法伤害到它。"
        ],
        "10,4": [
            {
                "type": "if",
                "condition": "flag:doorB11==2",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            10,
                            4
                        ]
                    }
                ],
                "false": []
            }
        ]
    },
    "changeFloor": {
        "5,1": {
            "floorId": "base10",
            "stair": "downFloor"
        },
        "5,11": {
            "floorId": "base12",
            "loc": [
                5,
                11
            ]
        },
        "7,11": {
            "floorId": "base12",
            "loc": [
                7,
                11
            ]
        }
    },
    "afterBattle": {
        "11,5": [
            {
                "type": "setValue",
                "name": "flag:doorB11",
                "value": "flag:doorB11+1"
            }
        ],
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:doorB11",
                "value": "flag:doorB11+1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "downFloor": [
        7,
        11
    ],
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

]
}
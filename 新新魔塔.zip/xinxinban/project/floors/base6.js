main.floors.base6=
{
    "floorId": "base6",
    "title": "地下  6F",
    "name": "-6",
    "canFlyTo": true,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3, 88,  1, 27,  1, 31,  1, 31,  1, 21,  1, 87,  3],
    [  3,212,  1,  0,  1,246,  1,231,  1,231,  1,  0,  3],
    [  3,  0,212,  0,  1,  0,  1,  0,  0,  0,  1,  0,  3],
    [  3,  0,  1, 81,  0,  0,  1,  0,  1, 81, 81,232,  3],
    [  3,  0,  1, 21,  1,  1,  1,  0,  1,  1,  1,  0,  3],
    [  3,  0,  1,  1,  1, 21,  1,232,  1,  0, 81,214,  3],
    [  3,  0, 81,  0,  1, 81, 81, 81,  1,  0,  1,  0,  3],
    [  3,  0,  1,  0,  1,222,  1, 21,  1,  0,  1,  0,  3],
    [  3,  0,  1,  0,  1,  0,  1,  1,  1,  0,  1,  0,  3],
    [  3,212,  1,222, 81,  0,  1,231,  0,  0,  1,  0,  3],
    [  3, 28,  1,  0,  1,  0,  1, 22,  1,222,  1,  0,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": "base5",
            "stair": "downFloor"
        },
        "1,1": {
            "floorId": "base7",
            "stair": "upFloor"
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

]
}
main.floors.base15=
{
    "floorId": "base15",
    "title": "地下  15F",
    "name": "-15",
    "canFlyTo": true,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3,  0,  0, 11, 11, 11,227,227,227,  0,  0,  0,  3],
    [  3,  0,  1,  1,  1,  1,  1,223,  1,  1,  1,  1,  3],
    [  3,  0,  1, 64,  1, 31,  1, 81,  1, 21,  1, 42,  3],
    [  3,  0,  1, 83,  1, 31,  1, 81,  1, 21,  1, 83,  3],
    [  3, 88,  1, 83, 83, 31, 82,223, 82, 21, 83, 83,  3],
    [  3,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  3],
    [  3,  0,225,225,225,  0,  0, 11,  0,  0,  0, 21,  3],
    [  3, 11,  1,  0,  1,230,  1,  1,  1,220,  1,  1,  3],
    [  3, 11,  1,  0,  1, 11,  1,  0,  0,220,  0,  0,  3],
    [  3,230,  1,  0,  1,230,  1,219,  1,  1,  1,219,  3],
    [  3, 28,  1, 88,  1, 27,  1,  0,  0, 87,  0,  0,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {},
    "changeFloor": {
        "9,11": {
            "floorId": "base14",
            "stair": "downFloor"
        },
        "3,11": {
            "floorId": "base16",
            "loc": [
                3,
                11
            ]
        },
        "1,5": {
            "floorId": "base16",
            "loc": [
                1,
                5
            ]
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "downFloor": [
        3,
        11
    ],
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

]
}
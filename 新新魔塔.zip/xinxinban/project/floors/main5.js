main.floors.main5=
{
    "floorId": "main5",
    "title": "主塔  5F",
    "name": "5",
    "canFlyTo": true,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3,  2, 59, 58, 31,  2, 87,  2,122,  0, 21, 22,  3],
    [  3,  2,205,206,205,  2,202,  2,  0,  0,  0,  0,  3],
    [  3,  2,  0,  0,  0,  2,203,  2,  0,  0,  0,  0,  3],
    [  3,  2,  0,203,  2,  2,202,  2,  2,  0,  0, 31,  3],
    [  3,  2,  2, 86,  2,  0,  0,125,  2,205,  2,  2,  3],
    [  3,  0,  0,217,209,  0, 88,  0,  0,  0,203, 81,  3],
    [  3,  2,  2, 81,  2,  0,  0,  0,  2, 82,  2, 81,  3],
    [  3,  2,  2,  0,  2,  2,  0,  2,  2,206,  0,  0,  3],
    [  3,  2, 27, 23, 28,  2,  0,  2,  0,209,209,209,  3],
    [  3,  2,  2, 29,  2,  2,  0,  2,  0,  0,  0,  0,  3],
    [  3,  2,  2,  2,  2,  2,121,  2,  0,  0, 31, 21,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {
        "6,11": [
            "\t[神秘老人,man]我在这本想为能来到这里的勇者送去一种可以窥探怪物能力的宝物——心镜，但你的魔物法典功效与心镜完全相同，我便不将心镜送给你了。\n能得到这种宝物的人一定并非凡人……所以我相信你能救出公主，加油！",
            {
                "type": "hide",
                "time": 500
            }
        ],
        "8,1": [
            {
                "type": "choices",
                "text": "\t[宝石商人,woman]我这里有两颗红宝石，想要吗？\n那就40金币卖给你吧！",
                "choices": [
                    {
                        "text": "要",
                        "action": [
                            {
                                "type": "if",
                                "condition": "status:money>=40",
                                "true": [
                                    {
                                        "type": "setValue",
                                        "name": "status:money",
                                        "value": "status:money-40"
                                    },
                                    {
                                        "type": "function",
                                        "function": "function(){\ncore.status.hero.atk += core.values.redJewel *2\n}"
                                    },
                                    {
                                        "type": "tip",
                                        "text": "获得 两颗红宝石，攻击力 +4",
                                        "icon": "redJewel"
                                    },
                                    {
                                        "type": "playSound",
                                        "name": "shop.mp3"
                                    },
                                    {
                                        "type": "update"
                                    },
                                    {
                                        "type": "hide",
                                        "time": 500
                                    },
                                    {
                                        "type": "exit"
                                    }
                                ],
                                "false": [
                                    "\t[宝石商人,woman]你没有足够的金币！",
                                    {
                                        "type": "revisit"
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "text": "不要",
                        "action": [
                            {
                                "type": "exit"
                            }
                        ]
                    }
                ]
            }
        ],
        "7,5": [
            "\t[作者提示]发现新版极速模式下，可以秒杀怪物的时候，依然会受到伤害了么？",
            "\t[作者提示]因为怪物敏捷的存在，总会有MISS的时候，新计算方式考虑到了这点"
        ]
    },
    "changeFloor": {
        "6,1": {
            "floorId": "main6",
            "stair": "downFloor"
        },
        "6,6": {
            "floorId": "main4",
            "stair": "upFloor"
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "bgmap": [

],
    "fgmap": [

]
}
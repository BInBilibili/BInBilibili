main.floors.main7=
{
    "floorId": "main7",
    "title": "主塔  7F",
    "name": "7",
    "canFlyTo": true,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3,  2,  2, 88,  2, 21, 21,  2,  0,  0,  0,  2,  3],
    [  3,  2,215, 83,  2, 21,210,  2,  0,  2,  0,  0,  3],
    [  3, 21,  0,  2,  2,  2, 81,  2,215,  2,206,  2,  3],
    [  3,  2,209,221,  0,  2, 22,  2, 81,  2,221,  0,  3],
    [  3,  2,253,  2, 21,  2,  0,  2,  0,  2,  0,  2,  3],
    [  3, 87,  0,  2,  2,  2,  0,  2,253,  2,  0,  0,  3],
    [  3,  2,209,217,  0, 81,205,  2, 31,  2,  0,  2,  3],
    [  3,  2, 31,  2, 31,  2,205,  2, 32,  2,209,  0,  3],
    [  3,  2,  2,  2,  2,  2,  0,  2,  2,  2,  0,  2,  3],
    [  3,  2,  9,130, 10,  2,  0,  0,  0,  0, 81,  0,  3],
    [  3,  2, 28,  0, 27, 82,209,  2, 88,  2,  0,  2,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {
        "3,10": [
            {
                "type": "openShop",
                "id": "expShop7F"
            }
        ]
    },
    "changeFloor": {
        "1,6": {
            "floorId": "main8",
            "stair": "downFloor"
        },
        "3,1": {
            "floorId": "main6",
            "loc": [
                3,
                1
            ]
        },
        "8,11": {
            "floorId": "main6",
            "loc": [
                8,
                11
            ]
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "downFloor": [
        8,
        11
    ],
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "bgmap": [

],
    "fgmap": [

]
}
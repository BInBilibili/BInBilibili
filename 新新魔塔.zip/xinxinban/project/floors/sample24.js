main.floors.sample24=
{
    "floorId": "sample24",
    "title": "地下  24F",
    "name": "-24",
    "width": 13,
    "height": 13,
    "canFlyTo": false,
    "canUseQuickShop": false,
    "images": [],
    "item_ratio": 1,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "7,1": [
            "\t[勇士,hero]发生了什么……怎么到处都是熔岩！\n看来附近一定有我还没发现的密道。",
            {
                "type": "hide",
                "time": 1
            }
        ]
    },
    "changeFloor": {
        "6,1": {
            "floorId": "base25",
            "loc": [
                6,
                1
            ],
            "time": 500
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3,  5,  5,  5,  5,  5, 88,  0,  5,  5,  5,  5,  3],
    [  3,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  3],
    [  3,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  3],
    [  3,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  3],
    [  3,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  3],
    [  3,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  3],
    [  3,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  3],
    [  3,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  3],
    [  3,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  3],
    [  3,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  3],
    [  3,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "bgmap": [

],
    "fgmap": [

],
    "cannotViewMap": true
}
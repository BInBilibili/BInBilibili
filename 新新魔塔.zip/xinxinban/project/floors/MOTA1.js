main.floors.MOTA1=
{
    "floorId": "MOTA1",
    "title": "魔塔  1F",
    "name": "1",
    "canFlyTo": false,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3, 27,  3,  3,  3,  3, 87,  3,  3,  3,  3, 28,  3],
    [  3,204,  3,  3,  3,  3,  0,  3,  3,  3,  3,204,  3],
    [  3,  0,  3,  3,  3,  3,204,  3,  3,  3,  3,  0,  3],
    [  3,  0,  3,  3,  3,  3,  0,  3,  3,  3,  3,  0,  3],
    [  3, 83,  3,  3,  3,  3, 83,  3,  3,  3,  3, 83,  3],
    [  3,203,  3,  3,  3,  3,203,  3,  3,  3,  3,203,  3],
    [  3,  0,202,202,  0,  0,  0,  0,  0,202,202,  0,  3],
    [  3,  3,  3,  3,  3,  3, 81,  3,  3,  3,  3,  3,  3],
    [  3,  3,  3,  3,  3,  3,201,  3,  3,  3,  3,  3,  3],
    [  3,  3,  3,  3,  3,  3,  0,  3,  3,  3,  3,  3,  3],
    [  3,  3,  3,  3,  3,  4, 93,  4,  3,  3,  3,  3,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": null,
    "events": {
        "6,10": null,
        "9,2": null,
        "0,0": [
            {
                "type": "if",
                "condition": "false",
                "true": [
                    {
                        "type": "pauseBgm"
                    },
                    {
                        "type": "stopSound"
                    },
                    {
                        "type": "playSound",
                        "name": "gameover.mp3"
                    },
                    {
                        "type": "showImage",
                        "code": 41,
                        "image": "gameover.png",
                        "loc": [
                            -30,
                            0
                        ],
                        "opacity": 0,
                        "time": 0
                    },
                    {
                        "type": "moveImage",
                        "code": 41,
                        "to": [
                            0,
                            0
                        ],
                        "opacity": 1,
                        "time": 500
                    },
                    {
                        "type": "moveImage",
                        "code": 41,
                        "to": [
                            30,
                            0
                        ],
                        "opacity": 0,
                        "time": 4000
                    },
                    {
                        "type": "hideImage",
                        "code": 41,
                        "time": 1
                    },
                    {
                        "type": "confirm",
                        "text": "你想读取存档吗？",
                        "yes": [
                            {
                                "type": "callLoad"
                            }
                        ],
                        "no": []
                    },
                    {
                        "type": "restart"
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "6,2": null,
        "6,1": {
            "floorId": "MOTA2",
            "loc": [
                6,
                1
            ]
        },
        "6,11": {
            "floorId": "main17",
            "loc": [
                4,
                1
            ]
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "bgmap": [

],
    "fgmap": [

]
}
main.floors.base25=
{
    "floorId": "base25",
    "title": "地下  25F",
    "name": "-25",
    "canFlyTo": false,
    "canUseQuickShop": false,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3,  5,  5,  1, 23, 23, 87, 23, 23,  1,  5,  5,  3],
    [  3,  5,  5,  1,  1,  1,  0,  1,  1,  1,  5,  5,  3],
    [  3,  5,  5,  1,  1,  1,  0,125,  1,  1,  5,  5,  3],
    [  3,  5,  5,  1, 32,  0,  0,  0, 32,  1,  5,  5,  3],
    [  3,  5,  5,  1,  1, 28,  0, 27,  1,  1,  5,  5,  3],
    [  3,  5,  5,  1,  1,  1, 83,  1,  1,  1,  5,  5,  3],
    [  3,  5,  5,  1,  1, 23,350, 23,  1,  1,  5,  5,  3],
    [  3,  5,  5,  1,  1,  0,  0,  0,  1,  1,  5,  5,  3],
    [  3,  5,  5,  1,  1,  1, 83,  1,  1,  1,  5,  5,  3],
    [  3,  5,  5,  1,  1,  1,132,  1,  1,  1,  5,  5,  3],
    [  3,  5,  5,  1,  1,  1,331,  1,  1,  1,  5,  5,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {
        "6,7": null,
        "6,10": [
            "\t[勇者,hero]是公主？",
            "\t[公主,princess]你是来救我的？太好了，我们走吧！回国后我一定让父王大赏你。",
            "\t[勇者,hero]是真正的公主。太好了！我们走吧！",
            {
                "type": "setCurtain",
                "color": [
                    0,
                    0,
                    0,
                    1
                ],
                "time": 2000
            },
            {
                "type": "showImage",
                "code": 3,
                "image": "plot.png",
                "loc": [
                    0,
                    0
                ],
                "opacity": 1,
                "time": 0
            },
            {
                "type": "showImage",
                "code": 4,
                "image": "plotEndFalse.png",
                "loc": [
                    0,
                    0
                ],
                "opacity": 1,
                "time": 0
            },
            {
                "type": "setCurtain",
                "time": 1000
            },
            {
                "type": "wait"
            },
            {
                "type": "hideImage",
                "code": 4,
                "time": 1000
            },
            {
                "type": "setValue",
                "name": "flag:doNotDisplayGameover",
                "value": "true"
            },
            {
                "type": "lose",
                "reason": "救出假公主"
            }
        ],
        "6,11": [
            {
                "type": "if",
                "condition": "core.terrainExists(6,11, 'flower')",
                "true": [
                    {
                        "type": "setValue",
                        "name": "flag:doNotPlaySoundWhileChangingFloor",
                        "value": "true"
                    },
                    {
                        "type": "changeFloor",
                        "floorId": "MOTA8",
                        "loc": [
                            6,
                            11
                        ],
                        "time": 0
                    },
                    {
                        "type": "playSound",
                        "name": "teleport.mp3"
                    }
                ]
            }
        ],
        "6,1": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": false,
            "data": []
        },
        "7,3": [
            "\t[作者提示]新版经典模式，新版极速模式下，魔王格勒第的暴击由20调整为30（flash原版似乎还不止30）"
        ]
    },
    "changeFloor": {
        "6,11": null,
        "6,1": {
            "floorId": "sample24",
            "loc": [
                6,
                1
            ],
            "time": 500
        }
    },
    "afterBattle": {
        "6,10": [
            "\t[勇士,hero]又是假的！可恶……",
            "\t[恶魔首领]！！！\n我居然会输给你们这些人类……",
            "\t[勇士,hero]只怪你演技太差了！\n快说，\n真正的公主在哪里？",
            "\t[恶魔首领]我是不会说的！有本事自己去找！\n不过，就算你找到了也一定救不了她的！\n哈哈哈哈哈！……",
            {
                "type": "show",
                "loc": [
                    [
                        6,
                        1
                    ]
                ],
                "time": 1
            }
        ]
    },
    "afterGetItem": {
        "7,4": null
    },
    "afterOpenDoor": {
        "6,11": [
            {
                "type": "setBlock",
                "number": 168
            },
            {
                "type": "show",
                "loc": [
                    [
                        6,
                        11
                    ]
                ],
                "time": 500
            }
        ],
        "6,6": [
            "\t[魔王·格勒第]看来你的运气不错，竟然能到达这里……\n不过……这里就是你的终点了！",
            "\t[勇士,hero]这当然是终点，我将击败你救出公主！",
            "\t[魔王·格勒第]看来你并未真正明白……",
            "\t[勇士,hero]除了击败你之外，我还需要明白什么？！",
            "\t[魔王·格勒第]……",
            "\t[魔王·格勒第].....算了，放马过来吧。",
            {
                "type": "hide",
                "time": 500
            }
        ]
    },
    "cannotMove": {},
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "bgmap": [

],
    "fgmap": [

]
}
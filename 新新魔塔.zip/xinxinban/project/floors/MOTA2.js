main.floors.MOTA2=
{
    "floorId": "MOTA2",
    "title": "魔塔  2F",
    "name": "0",
    "canFlyTo": false,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3,  0,  0,217,  0,  0, 88,  0,  0,217,  0,  0,  3],
    [  3,  0,  3,  3,  3,  3,  3,  3,  3,  3,  3,  0,  3],
    [  3,  0,  3, 31, 28,  3,218, 86,217, 21,  3,  0,  3],
    [  3,  0,  3,  0,218,  3,  0,  3,  0, 59,  3,  0,  3],
    [  3,217,  3,  3, 86,  3, 83,  3,  3,  3,  3,217,  3],
    [  3,253,  0,  0,  0,  0,219,  0,  0,  0,  0,253,  3],
    [  3,217,  3,  3,  3,  3, 81,  3,  3,  3,  3,217,  3],
    [  3,  0,  3,  0,218, 86,253,  3, 23, 58,  3,  0,  3],
    [  3,  0,  3, 32, 27,  3,  0,  3,218,  0,  3,  0,  3],
    [  3,  0,  3,  3,  3,  3,  3,  3, 86,  3,  3,  0,  3],
    [  3,  0,  0,218,  0,  0, 87,  0,  0,218,  0,  0,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": "MOTA1",
            "stair": "upFloor"
        },
        "6,11": {
            "floorId": "MOTA3",
            "stair": "downFloor"
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "bgmap": [

],
    "fgmap": [

]
}
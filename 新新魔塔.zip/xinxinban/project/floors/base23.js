main.floors.base23=
{
    "floorId": "base23",
    "title": "地下  23F",
    "name": "-23",
    "canFlyTo": true,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3, 88,  0,  0, 81,  0,256,  0,256,  0,234,  0,  3],
    [  3,  0,  1,228,  1,  0,  1,228,  1,228,  1,  0,  3],
    [  3,  0,  1, 29,  1,  0,331,  0,  1,  0,  1,  0,  3],
    [  3,  0,  1,  1,  1,  0,  1,  0,  1,  0,  1,  0,  3],
    [  3,  0,  1, 24,  1,  0,  1,  0,331,  0,331,  0,  3],
    [  3,  0,  1, 82,  1,  0,  1,228,  1,228,  1,  0,  3],
    [  3,  0,  0,254,  0,  0,234,  0,235,  0,235,  0,  3],
    [  3,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  0,  3],
    [  3,  0,236,236,236, 21, 22, 23,236,236,236,  0,  3],
    [  3,  0,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  3],
    [  3,  0,  0,254,254, 31, 31, 31,254,254,  0, 87,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": "base22",
            "stair": "downFloor"
        },
        "1,1": {
            "floorId": "base24",
            "stair": "upFloor"
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

]
}
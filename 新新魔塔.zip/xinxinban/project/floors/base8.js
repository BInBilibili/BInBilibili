main.floors.base8=
{
    "floorId": "base8",
    "title": "地下  8F",
    "name": "-8",
    "canFlyTo": true,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3,  0,  0,  0,  0,  0,222,  0,  0,  0,  0,  0,  3],
    [  3,246,  1,  1,  1,  1,  1,  1,  1,  1, 31,  0,  3],
    [  3,  0,  0,  0,  0,212, 31,  1, 32,  1,  1,  0,  3],
    [  3, 87,  1,  1,  1,212, 31,  1, 27, 28,  1, 81,  3],
    [  3,  0,331,320,  1,  1,  1,  1,231,219,  1,  0,  3],
    [  3,  1,  1,  1,  1, 21, 21,  1,  1, 82,  1,  0,  3],
    [  3,  0,  0,  0, 81,246,231,  0,  1,  0,  1,  0,  3],
    [  3, 81,  1,  1,  1,  1,  1, 88,  1,222, 81,  0,  3],
    [  3, 81,  1,  1,  1,  1,  1,  1,  1,222,  1,  0,  3],
    [  3,  0,  0,246,  0,  0,232,  0,  0,  0,  1,  0,  3],
    [  3,  0,  0,246,  0,  0,232,  0,  0,  0,  1,121,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {
        "11,11": [
            "\t[老人,man]告诉你吧，霸者之证对魔法师无效。"
        ]
    },
    "changeFloor": {
        "1,4": {
            "floorId": "base7",
            "stair": "downFloor"
        },
        "7,8": {
            "floorId": "base9",
            "stair": "upFloor"
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

]
}
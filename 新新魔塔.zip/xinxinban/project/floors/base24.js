main.floors.base24=
{
    "floorId": "base24",
    "title": "地下  24F",
    "name": "-24",
    "canFlyTo": true,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3, 87,  1,  5,  5,  1, 88, 11, 11, 11, 11, 11,  3],
    [  3, 86,  1,  5,  5,  1,  1,  1,  1,  1,  1, 11,  3],
    [  3,236,  1,  5,  5,  5,  5,  5,  5,  5,  1, 11,  3],
    [  3,236,  1,  5,  5,  5,  5,  5,  5,  5,  1, 11,  3],
    [  3,236,  1,  5,  5,  5,  5,  5,  5,  5,  5, 11,  3],
    [  3,  0,228,256,256,234,234,235,235, 86,245,320,  3],
    [  3,236,  1,  5,  5,  5,  5,  5,  5,  5,  5,  5,  3],
    [  3,236,  1,  5,  5,  5,  5,  5,  5,  5,  5,  5,  3],
    [  3,  0,  1,  5,  5,  5,  5,  5,  5,  5,  5,  5,  3],
    [  3, 86,  1,  1,  1,  1,  1,  1,  5,  5,  5,  5,  3],
    [  3,327,331,331,331,331,320,  1,  5,  5,  5,  5,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": null,
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": "base23",
            "stair": "downFloor"
        },
        "6,1": {
            "floorId": "base25",
            "loc": [
                6,
                1
            ]
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

]
}
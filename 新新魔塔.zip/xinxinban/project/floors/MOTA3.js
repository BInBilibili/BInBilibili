main.floors.MOTA3=
{
    "floorId": "MOTA3",
    "title": "魔塔  3F",
    "name": "0",
    "canFlyTo": false,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3, 28,  3,  0,  0,  3, 87,  3,  0,  0,  3, 28,  3],
    [  3, 31,207,  0,  0,  3,206,207,207,  0,207, 31,  3],
    [  3, 21,  3,  0,207,207, 86,  3,  0,  0,  3, 21,  3],
    [  3,  3,  3,  3,  3,  3, 86,  3,  3,  3,  3,  3,  3],
    [  3,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  3],
    [  3,  0,  3,  3,  3,  3,  3,  3,  3,  3,  3,  0,  3],
    [  3,206,  0,206,  0,  0,  0,  0,206,205,  0,  0,  3],
    [  3, 86,  3, 86,  3,  3, 86,  3,  3, 86,  3, 86,  3],
    [  3,207,  0,207,  3,  3,205,  3,  3,207,207,207,  3],
    [  3,  0,  0,  0,  3,  0,  0,  0,  3,  3,207,  3,  3],
    [  3, 21, 22, 21,  3,  0, 88,  0,  3,  3, 23,  3,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": "MOTA4",
            "stair": "downFloor"
        },
        "6,11": {
            "floorId": "MOTA2",
            "stair": "upFloor"
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "bgmap": [

],
    "fgmap": [

]
}
main.floors.MOTA9=
{
    "floorId": "MOTA9",
    "title": "魔塔  9F",
    "name": "0",
    "canFlyTo": false,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3,  3,  3,  3,  3,  3, 43,  3,  3,  3,  3,  3,  3],
    [  3,  3,  0,  0,  0,  3, 83,  3,  0,  0,  0,  3,  3],
    [  3,  3,  3,  3,  3,  3, 83,  3,  3,  3,  3,  3,  3],
    [  3,  3,  0,  0,  3,316,317,318,  3,  0,  0,  3,  3],
    [  3,  3,  0,  0,  3,319,332,333,  3,  0,  0,  3,  3],
    [  3,  3,  3,  3,  3,334,336,335,  3,  3,  3,  3,  3],
    [  3,  3,  0,  0,  3,  3,  0,  3,  3,  0,  0,  3,  3],
    [  3,  3,  0,  3,  0,  3,  0,  3,  0,  3,  0,  3,  3],
    [  3,  3,  0,  3,  0,  3,  0,  3,  0,  3,  0,  3,  3],
    [  3,  3,  0,  3,  0,  3,  0,  3,  0,  3,  0,  3,  3],
    [  3,  3,  0,  3,  0,  4, 93,  4,  0,  3,  0,  3,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": "base22",
            "loc": [
                11,
                1
            ]
        }
    },
    "afterBattle": {
        "6,6": [
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        6
                    ]
                ],
                "time": 0
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        6
                    ]
                ],
                "time": 0
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        5
                    ]
                ],
                "time": 0
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        5
                    ]
                ],
                "time": 0
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        5
                    ]
                ],
                "time": 0
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        4
                    ]
                ],
                "time": 0
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        4
                    ]
                ],
                "time": 0
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        4
                    ]
                ],
                "time": 0
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "bgmap": [

],
    "fgmap": [

]
}
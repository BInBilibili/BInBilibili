main.floors.base4=
{
    "floorId": "base4",
    "title": "地下  4F",
    "name": "-4",
    "canFlyTo": true,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3,  0, 81,  0,  1,246, 88,246, 82,224,  0,224,  3],
    [  3,232,  1, 88,  1,  0,246,  0,  1,  0,214,  0,  3],
    [  3,246,  1,  1,  1, 28,  0,  0,  1,  0,  0,  0,  3],
    [  3,232,  1, 27,  1,  1,  1,  1,  1,  0,  0,  0,  3],
    [  3,  0,  1,232,  0,  0,  0,  0,  0, 28, 28,  0,  3],
    [  3,  0,  0,  0,  0,224,  1,  1,  1,  1,  1,  0,  3],
    [  3,  1, 81,  1,  1, 81,  1, 31, 21, 21,  1,  0,  3],
    [  3,  1, 81,  1, 31, 31, 81,214,  0,  0,  1,  0,  3],
    [  3,  1,  0,  1, 31, 31,  1,  0,  0,  1,  1, 81,  3],
    [  3,  1,  0,  1,  1,  1,  1,  1,  1,  1,  0,  0,  3],
    [  3, 22,224,  0,224,246,224,  0,  0, 81,  0, 87,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": "base3",
            "stair": "downFloor"
        },
        "3,2": {
            "floorId": "base5",
            "loc": [
                3,
                2
            ]
        },
        "6,1": {
            "floorId": "base5",
            "loc": [
                6,
                1
            ]
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "downFloor": [
        6,
        1
    ],
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

]
}
main.floors.base3=
{
    "floorId": "base3",
    "title": "地下  3F",
    "name": "-3",
    "canFlyTo": true,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3, 87,  1, 21, 21, 21,  1, 31, 31, 31,  0,  1,  3],
    [  3,  0,  1,  0,  0,  0,  1,  0,  0,  0,  1, 31,  3],
    [  3,  0,  1,  1,  0,246,  0,246,  0,  1, 28,  0,  3],
    [  3,  0,  1, 31,  1,  0,  0,  0,  1, 27,  0,  0,  3],
    [  3,  0,  1,  0,  0,  1,224,  1, 81,  0,  0,  0,  3],
    [  3,  0,  1,  0,  0,214, 81,218,246,  1,  1,  1,  3],
    [  3,207,  1,  0,  1,  1,  0,  1, 81,  0,  0,  0,  3],
    [  3,  0,  1, 31,  1,  0,  0,  1,  1,  0,  0,  0,  3],
    [  3,  0,  1,  1,  1,  1,  0,  1, 21, 21, 21,  0,  3],
    [  3,  0,218,  0,  1,  1, 82,  1,  1,  1,  1,  1,  3],
    [  3,  1,  1,  0,  0,224,  0,224,  0,207,  0, 88,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": "base2",
            "stair": "downFloor"
        },
        "11,11": {
            "floorId": "base4",
            "stair": "upFloor"
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

]
}
main.floors.main0=
{
    "floorId": "main0",
    "title": "主塔  入口",
    "name": "0",
    "canFlyTo": true,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  3],
    [  3,  2,  2,123,  2,  2, 87,  2,  0,122,  2,  2,  3],
    [  3,  2,  0,  0,  2,  2,201,  2,  0,  0,  0,  2,  3],
    [  3,  2,  0,  0,  0,  0,  0,  0,  0,  0,  0,  2,  3],
    [  3,  2,  0,  0,  0,  0,  0,  0,  0,  0,  0,  2,  3],
    [  3,  2,  0,  0,  0,  0,  0,  0,  0,  0,  0,  2,  3],
    [  3,  2,  2,  2,  2,  2, 86,  2,  2,  2,  2,  2,  3],
    [  3,  2,  5,  2,  5,  2,  0,125,  5,  2,  5,  2,  3],
    [  3,  5,  5,  5,  5,  2,  0,  2,  5,  5,  5,  5,  3],
    [  3,  5,  5,  5,  5,  2,  0,  2,  5,  5,  5,  5,  3],
    [  3,  5,  5,  5,  5,  2,  0,  2,  5,  5,  5,  5,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [
        {
            "type": "setText",
            "position": "down",
            "offset": 5
        },
        {
            "type": "setValue",
            "name": "flag:customStatusBarHidden",
            "value": "false"
        },
        {
            "type": "if",
            "condition": "flag:fastStart>0",
            "true": [
                {
                    "type": "hideImage",
                    "code": 1,
                    "time": 50
                },
                {
                    "type": "if",
                    "condition": "!flag:aStupidWay",
                    "true": [
                        {
                            "type": "showStatusBar"
                        }
                    ]
                },
                {
                    "type": "showHero"
                },
                {
                    "type": "hide",
                    "loc": [
                        [
                            6,
                            10
                        ]
                    ],
                    "time": 0
                },
                {
                    "type": "hide",
                    "loc": [
                        [
                            6,
                            7
                        ]
                    ],
                    "time": 0
                },
                {
                    "type": "changePos",
                    "direction": "up"
                },
                {
                    "type": "moveHero",
                    "time": 60,
                    "steps": [
                        "up",
                        "up",
                        "up"
                    ]
                },
                {
                    "type": "showImage",
                    "code": 10,
                    "image": "flap.png",
                    "loc": [
                        0,
                        0
                    ],
                    "opacity": 1,
                    "time": 0,
                    "async": true
                },
                {
                    "type": "hide",
                    "loc": [
                        [
                            6,
                            7
                        ]
                    ],
                    "time": 0,
                    "async": true
                },
                {
                    "type": "animate",
                    "name": "handC",
                    "loc": [
                        6,
                        7
                    ],
                    "async": true
                },
                {
                    "type": "moveImage",
                    "code": 10,
                    "to": [
                        0,
                        -320
                    ],
                    "time": 199,
                    "async": true
                },
                {
                    "type": "waitAsync"
                },
                {
                    "type": "hideImage",
                    "code": 10,
                    "time": 1
                },
                {
                    "type": "moveHero",
                    "time": 60,
                    "steps": [
                        "up",
                        "up",
                        "up",
                        "up"
                    ]
                }
            ],
            "false": [
                {
                    "type": "pauseBgm"
                },
                {
                    "type": "showImage",
                    "code": 2,
                    "image": "plotStartPlot.png",
                    "loc": [
                        0,
                        0
                    ],
                    "opacity": 1,
                    "time": 0
                },
                {
                    "type": "wait"
                },
                {
                    "type": "hideImage",
                    "code": 2,
                    "time": 500
                },
                {
                    "type": "hideImage",
                    "code": 1,
                    "time": 500
                },
                {
                    "type": "resumeBgm"
                },
                {
                    "type": "if",
                    "condition": "!flag:aStupidWay",
                    "true": [
                        {
                            "type": "showStatusBar"
                        }
                    ]
                },
                {
                    "type": "showHero"
                }
            ]
        },
        {
            "type": "if",
            "condition": "core.getFlag(\"useBattleAnimate\")",
            "true": [
                {
                    "type": "setBlock",
                    "number": "sliver",
                    "loc": [
                        [
                            6,
                            4
                        ]
                    ],
                    "floorId": "MOTA7"
                },
                {
                    "type": "setBlock",
                    "number": "sliver",
                    "loc": [
                        [
                            6,
                            3
                        ]
                    ],
                    "floorId": "base18"
                },
                {
                    "type": "setBlock",
                    "number": "sliver",
                    "loc": [
                        [
                            11,
                            5
                        ]
                    ],
                    "floorId": "base22"
                },
                {
                    "type": "setBlock",
                    "number": "sliver",
                    "loc": [
                        [
                            1,
                            9
                        ]
                    ],
                    "floorId": "base24"
                },
                {
                    "type": "setBlock",
                    "number": "sliver",
                    "loc": [
                        [
                            6,
                            6
                        ]
                    ],
                    "floorId": "MOTA8"
                },
                {
                    "type": "setBlock",
                    "number": "gold",
                    "loc": [
                        [
                            6,
                            5
                        ]
                    ],
                    "floorId": "MOTA8"
                }
            ]
        },
        {
            "type": "if",
            "condition": "!core.getFlag(\"useBattleAnimate\")",
            "true": [
                {
                    "type": "choices",
                    "text": "\t[极速模式]是否选择新版极速模式？",
                    "choices": [
                        {
                            "text": "新版极速模式（更接近flash原版的平均伤害）",
                            "action": [
                                {
                                    "type": "addValue",
                                    "name": "flag:xinji",
                                    "value": "1"
                                },
                                {
                                    "type": "setBlock",
                                    "number": "sliver",
                                    "loc": [
                                        [
                                            6,
                                            4
                                        ]
                                    ],
                                    "floorId": "MOTA7"
                                },
                                {
                                    "type": "setBlock",
                                    "number": "sliver",
                                    "loc": [
                                        [
                                            6,
                                            3
                                        ]
                                    ],
                                    "floorId": "base18"
                                },
                                {
                                    "type": "setBlock",
                                    "number": "sliver",
                                    "loc": [
                                        [
                                            11,
                                            5
                                        ]
                                    ],
                                    "floorId": "base22"
                                },
                                {
                                    "type": "setBlock",
                                    "number": "sliver",
                                    "loc": [
                                        [
                                            1,
                                            9
                                        ]
                                    ],
                                    "floorId": "base24"
                                },
                                {
                                    "type": "setBlock",
                                    "number": "sliver",
                                    "loc": [
                                        [
                                            6,
                                            6
                                        ]
                                    ],
                                    "floorId": "MOTA8"
                                },
                                {
                                    "type": "setBlock",
                                    "number": "gold",
                                    "loc": [
                                        [
                                            6,
                                            5
                                        ]
                                    ],
                                    "floorId": "MOTA8"
                                }
                            ]
                        },
                        {
                            "text": "旧版极速模式",
                            "action": []
                        }
                    ]
                }
            ],
            "false": [
                {
                    "type": "choices",
                    "text": "\t[经典]是否选择新版经典模式？",
                    "choices": [
                        {
                            "text": "新版经典模式（更接近flash原版）",
                            "action": [
                                {
                                    "type": "addValue",
                                    "name": "flag:xinjing",
                                    "value": "1"
                                },
                                {
                                    "type": "setBlock",
                                    "number": "sliver",
                                    "loc": [
                                        [
                                            6,
                                            4
                                        ]
                                    ],
                                    "floorId": "MOTA7"
                                },
                                {
                                    "type": "setBlock",
                                    "number": "sliver",
                                    "loc": [
                                        [
                                            6,
                                            3
                                        ]
                                    ],
                                    "floorId": "base18"
                                },
                                {
                                    "type": "setBlock",
                                    "number": "sliver",
                                    "loc": [
                                        [
                                            11,
                                            5
                                        ]
                                    ],
                                    "floorId": "base22"
                                },
                                {
                                    "type": "setBlock",
                                    "number": "sliver",
                                    "loc": [
                                        [
                                            1,
                                            9
                                        ]
                                    ],
                                    "floorId": "base24"
                                },
                                {
                                    "type": "setBlock",
                                    "number": "sliver",
                                    "loc": [
                                        [
                                            6,
                                            6
                                        ]
                                    ],
                                    "floorId": "MOTA8"
                                },
                                {
                                    "type": "setBlock",
                                    "number": "gold",
                                    "loc": [
                                        [
                                            6,
                                            5
                                        ]
                                    ],
                                    "floorId": "MOTA8"
                                }
                            ]
                        },
                        {
                            "text": "旧版经典模式",
                            "action": []
                        }
                    ]
                }
            ]
        }
    ],
    "events": {
        "6,10": [
            "\t[勇士,hero]就是这里了……\n攻进去！",
            {
                "type": "hide",
                "time": 0
            }
        ],
        "9,2": [
            {
                "type": "if",
                "condition": "core.status.hero.lv>=20&&core.hasItem('proof_brave')&&core.getFlag('proof_lv')==1",
                "true": [
                    {
                        "type": "choices",
                        "text": "\t[奸商,woman]一阶勇者？我有个能让你变强的增幅器，但我不能把它送给你。\n不过，如果你肯付我500金币的话……",
                        "choices": [
                            {
                                "text": "是",
                                "action": [
                                    {
                                        "type": "if",
                                        "condition": "status:money>=500",
                                        "true": [
                                            {
                                                "type": "setValue",
                                                "name": "status:money",
                                                "value": "status:money-500"
                                            },
                                            {
                                                "type": "function",
                                                "function": "function(){\ncore.setFlag('proof_lv',core.getFlag('proof_lv')+1)\n}"
                                            },
                                            {
                                                "type": "update"
                                            },
                                            "章的等级升为${core.getFlag('proof_lv')}",
                                            {
                                                "type": "playSound",
                                                "name": "shop.mp3"
                                            }
                                        ],
                                        "false": [
                                            "\t[奸商,woman]你没有足够的金币。"
                                        ]
                                    }
                                ]
                            },
                            {
                                "text": "否",
                                "action": [
                                    {
                                        "type": "exit"
                                    }
                                ]
                            }
                        ]
                    }
                ],
                "false": [
                    "\t[奸商,woman]又是挑战者吗？\n希望你能活着回去，嘻嘻嘻……"
                ]
            }
        ],
        "9,3": null,
        "3,2": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "data": [
                {
                    "type": "openShop",
                    "id": "keyShop"
                }
            ]
        },
        "2,2": [
            {
                "type": "if",
                "condition": "core.terrainExists(2,2, 'downFloor')",
                "true": [
                    {
                        "type": "changeFloor",
                        "floorId": "base1",
                        "loc": [
                            2,
                            2
                        ],
                        "time": 500
                    }
                ],
                "false": []
            }
        ],
        "6,5": null,
        "7,6": null,
        "7,8": [
            "\t[作者提示]此NPC用于提示新版的一些特性"
        ]
    },
    "changeFloor": {
        "6,2": {
            "floorId": "main1",
            "stair": "downFloor"
        },
        "2,2": null
    },
    "afterBattle": {},
    "afterGetItem": {
        "3,5": null
    },
    "afterOpenDoor": {
        "7,6": null
    },
    "cannotMove": {},
    "downFloor": null,
    "upFloor": null,
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "bgmap": [

],
    "fgmap": [

],
    "bgm": null
}
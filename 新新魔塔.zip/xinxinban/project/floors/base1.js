main.floors.base1=
{
    "floorId": "base1",
    "title": "地下  1F",
    "name": "-1",
    "canFlyTo": true,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3,  1,  1,  1,225, 27,  1,  1,  0,  1,  0,  0,  3],
    [  3,  1, 87,  1,  0,  1,  0,  1,  0,219,225,  0,  3],
    [  3,  1,  0,  1,  0,  0,219,  0,222,  1, 31, 22,  3],
    [  3,  1,  0,  1,  0,  0,  0,  1,  0,  1, 59, 58,  3],
    [  3,  1,218,  1,  1,  1,  1,  1, 82,  1,  1,  1,  3],
    [  3,  1,  0,  0,218,  0,  0,  0,224,  0,  0,  0,  3],
    [  3,  1,  1,  1, 82,  1,  1,  1,  1,  1,  1,  0,  3],
    [  3,  0,  0,222,  0,  1,  0,  0,212,  0,  1,  0,  3],
    [  3,  0,  0,  1,232,  1,  0,  1, 32,  0,  1,207,  3],
    [  3,  0,  0,  1,  0,  1,  0,  0,  1,  0,  1,  0,  3],
    [  3, 26,121,  1,  0,212,  0,225, 21,  0,  1, 88,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {
        "2,11": [
            "\t[老人,man]看到圣水不要着急去取，\n因为你的体力越多，圣水的效果越明显！"
        ]
    },
    "changeFloor": {
        "11,11": {
            "floorId": "base2",
            "stair": "upFloor"
        },
        "2,2": {
            "floorId": "main0",
            "stair": "downFloor"
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "downFloor": null,
    "upFloor": null,
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "bgmap": [

],
    "fgmap": [

],
    "underGround": true
}
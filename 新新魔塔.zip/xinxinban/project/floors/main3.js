main.floors.main3=
{
    "floorId": "main3",
    "title": "主塔  3F",
    "name": "3",
    "canFlyTo": true,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  3],
    [  3,  2, 87,  0,205,  2,  0,  0,217, 82, 28,  2,  3],
    [  3,  2,  0,  2,  0,  2,202,  2,  2,  2, 59,  2,  3],
    [  3,  2,205,  0,  0,202,205,  0,  0,  2, 58,  2,  3],
    [  3,  2,  2,  2,  2,  2,  2,  2,  0,  2,  0,  2,  3],
    [  3, 87,  0,  0,205,  0,  0, 82,  0,  2,  0,  2,  3],
    [  3,  2,  2,  2,  2,  2,  2,  2,  0,  2, 81,  2,  3],
    [  3,  2,  2,  7,131,  8,  0,  2,  0,  2,209,  2,  3],
    [  3,  2, 87,201,202,  0,  0,202,  0,  2,  0,  2,  3],
    [  3,  2,  2, 32,  0,  0,  0,  2, 88,  2, 88,  2,  3],
    [  3,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {
        "4,8": [
            {
                "type": "openShop",
                "id": "moneyShop3F"
            }
        ]
    },
    "changeFloor": {
        "1,6": {
            "floorId": "main4",
            "loc": [
                1,
                6
            ]
        },
        "2,2": {
            "floorId": "main4",
            "loc": [
                2,
                2
            ]
        },
        "2,9": {
            "floorId": "main4",
            "loc": [
                2,
                9
            ]
        },
        "8,10": {
            "floorId": "main2",
            "loc": [
                8,
                10
            ]
        },
        "10,10": {
            "floorId": "main2",
            "loc": [
                10,
                10
            ]
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "downFloor": [
        8,
        10
    ],
    "upFloor": [
        2,
        9
    ],
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "bgmap": [

],
    "fgmap": [

]
}
main.floors.MOTA4=
{
    "floorId": "MOTA4",
    "title": "魔塔  4F",
    "name": "0",
    "canFlyTo": false,
    "canUseQuickShop": true,
    "defaultGround": "ground",
    "images": [],
    "item_ratio": 1,
    "map": [
    [  3,  3,  3,  3,  3, 17, 17, 17,  3,  3,  3,  3,  3],
    [  3, 22, 21,231,  0,  3, 88,  3,  3, 21,231,  0,  3],
    [  3,  3,  3,  3,246,  3,246,  3,  3,  3,  3,246,  3],
    [  3,  0,  0,  0,  0,  0, 86,  0,  0,  0,  0,  0,  3],
    [  3,  3,  3,  3, 86,  3,246,  3,  3, 86,  3,  3,  3],
    [  3,  3,  0,  0,  0,  3, 27,  3,  3,  0,  0,  3,  3],
    [  3,  3, 86,  3,  3,  3,  3,  3,  3,  3, 86,  3,  3],
    [  3, 31,  0,  0, 21,  3,  3,  3, 21,  0,  0, 32,  3],
    [  3,  3,  3, 86,  3,  3, 28,  3,  3, 86,  3,  3,  3],
    [  3,  3,  0,  0,  3,  3, 86,  3,  3,  0,  0,  3,  3],
    [  3,  3,  0,  3,  3,  0,231,  0,  3,  3,  0,  3,  3],
    [  3,  0,  0, 86,  0,  0, 87,  0,  0, 86,  0,  0,  3],
    [  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3]
],
    "firstArrive": [],
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": "MOTA3",
            "stair": "upFloor"
        },
        "6,11": {
            "floorId": "MOTA5",
            "stair": "downFloor"
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "bgmap": [

],
    "fgmap": [

]
}
var data_a1e2fb4a_e986_4524_b0da_9b7ba7c0874d = 
{
	"main": {
		"floorIds": [
			"base25",
			"base24",
			"base23",
			"base22",
			"base21",
			"base20",
			"base19",
			"base18",
			"base17",
			"base16",
			"base15",
			"base14",
			"base13",
			"base12",
			"base11",
			"base10",
			"base9",
			"base8",
			"base7",
			"base6",
			"base5",
			"base4",
			"base3",
			"base2",
			"base1",
			"main0",
			"main1",
			"main2",
			"main3",
			"main4",
			"main5",
			"main6",
			"main7",
			"main8",
			"main9",
			"main10",
			"main11",
			"main12",
			"main13",
			"main14",
			"main15",
			"main16",
			"main17",
			"main18",
			"main19",
			"main20",
			"MOTA1",
			"MOTA2",
			"MOTA3",
			"MOTA4",
			"MOTA5",
			"MOTA6",
			"MOTA7",
			"MOTA8",
			"MOTA9",
			"MOTA10",
			"sample0",
			"sample24"
		],
		"images": [
			"bg.jpg",
			"gengxin1.jpg",
			"gengxin2.jpg",
			"gengxin3.jpg",
			"winskin.png",
			"hero1.png",
			"hero2.png",
			"hero3.png",
			"transparent.png",
			"startBackground.png",
			"startHover.png",
			"startHoverC.png",
			"startButtonsLit.png",
			"startButtons.png",
			"startCursorLarge.png",
			"startCursorSmall.png",
			"instructions.png",
			"aboutMonsters.png",
			"aboutMonstersHover3.png",
			"aboutMonstersHover2.png",
			"aboutMonstersHover1.png",
			"plotStart.png",
			"plotStartCursor1.png",
			"plotStartCursor2.png",
			"plotStartPlot.png",
			"plotEndFalse.png",
			"plotEndTrue.png",
			"plot.png",
			"flap.png",
			"menu_pc.png",
			"menu_pc_cover.png",
			"menu_proof1.png",
			"menu_proof2.png",
			"menu_proof3.png",
			"menu_proofSage.png",
			"menu_proofTyrant.png",
			"menu_proofBrave.png",
			"menu_proofNull.png",
			"menu_pc_debuffNull.png",
			"menu_pc_debuffPoison.png",
			"menu_pc_debuffWeak.png",
			"menu_pc_modeSpeedy.png",
			"menu_pc_modeClassic.png",
			"vs.png",
			"miss.png",
			"gameover.png",
			"blueWall.png",
			"menu_mobile.png",
			"menu_mobile_cover.png",
			"menu_mobile_debuffNull.png",
			"menu_mobile_debuffWeak.png",
			"menu_mobile_debuffPoison.png",
			"menu_mobile_modeSpeedy.png",
			"menu_mobile_modeClassic.png",
			"menu_pc_cheated.png",
			"menu_mobile_cheated.png",
			"menu_mobile_toolbar.png",
			"advancedOperationsHint_pc.png",
			"advancedOperationsHint_mobile.png",
			"hint_brave.png",
			"hint_sage.png",
			"hint_tyrant.png",
			"hint_proof.png",
			"hint_status1.png",
			"hint_status2.png",
			"hint_status3.png",
			"hint_mode.png"
		],
		"tilesets": [
			"magictower.png"
		],
		"animates": [
			"hand",
			"sword",
			"zone",
			"waterN",
			"waterC",
			"swordN",
			"swordC",
			"bzz2",
			"handN",
			"handC",
			"magicN",
			"magicC",
			"hmagicN",
			"hmagicC",
			"darkN",
			"darkC",
			"biteN",
			"biteC",
			"fireN",
			"fireC",
			"tyrant",
			"mega",
			"windN",
			"windC",
			"bombN",
			"bombC",
			"bossN",
			"bossC",
			"thunderN",
			"thunderC",
			"tyrantfang",
			"tyrantfan",
			"sagefang",
			"sagefan",
			"bravefang",
			"sagehp",
			"block"
		],
		"bgms": [
			"mota.mp3",
			"main.mp3",
			"base.mp3"
		],
		"sounds": [
			"floor.mp3",
			"attack.mp3",
			"door.mp3",
			"item.mp3",
			"equip.mp3",
			"zone.mp3",
			"jump.mp3",
			"pickaxe.mp3",
			"bomb.mp3",
			"centerFly.mp3",
			"miss.mp3",
			"waterN.mp3",
			"waterC.mp3",
			"swordN.mp3",
			"swordC.mp3",
			"handN.mp3",
			"handC.mp3",
			"magicN.mp3",
			"magicC.mp3",
			"tygt.mp3",
			"darkN.mp3",
			"biteN.mp3",
			"biteC.mp3",
			"fireN.mp3",
			"tyrant.mp3",
			"mega.mp3",
			"windN.mp3",
			"windC.mp3",
			"bombN.mp3",
			"bombC.mp3",
			"bossN.mp3",
			"bossNn.mp3",
			"bossC.mp3",
			"block.mp3",
			"lava.mp3",
			"gameover.mp3",
			"slide.mp3",
			"shop.mp3",
			"heal.mp3",
			"teleport.mp3",
			"thunderN.mp3",
			"thunderC.mp3",
			"selector.mp3",
			"cancel.mp3",
			"startgame.mp3",
			"warning.mp3",
			"sagefang.mp3",
			"bravefang.mp3",
			"tyrantfang.mp3",
			"tyrantfan.mp3",
			"sagefan.mp3",
			"cursor.mp3",
			"confirm.mp3",
			"step.mp3"
		],
		"nameMap": {
			"背景图.jpg": "bg.jpg",
			"背景音乐.mp3": "bgm.mp3"
		},
		"startBackground": "bg.jpg",
		"startLogoStyle": "color: white",
		"levelChoose": [
			[
				"简单",
				"Easy"
			],
			[
				"普通",
				"Normal"
			],
			[
				"困难",
				"Hard"
			],
			[
				"噩梦",
				"Hell"
			]
		],
		"equipName": [
			"武器",
			"盾牌"
		],
		"startBgm": null,
		"statusLeftBackground": "black",
		"statusTopBackground": "url('project/images/ground.png') repeat",
		"toolsBackground": "url('project/images/menu_mobile_toolbar.png') 0 0/100% 100% no-repeat",
		"borderColor": "#66EEF0",
		"statusBarColor": "white",
		"hardLabelColor": "red",
		"floorChangingBackground": "black",
		"floorChangingTextColor": "white",
		"font": "Verdana",
		"startButtonsStyle": "background-color: #32369F; opacity: 0.85; color: #FFFFFF; border: #FFFFFF 2px solid; caret-color: #cccccc;"
	},
	"firstData": {
		"title": "新新魔塔",
		"name": "xinxin",
		"version": "Ver 2.6.6",
		"floorId": "main0",
		"hero": {
			"name": "勇士",
			"lv": 1,
			"hpmax": 999999,
			"hp": 1000,
			"manamax": -1,
			"mana": 0,
			"atk": 10,
			"def": 10,
			"mdef": 0,
			"money": 0,
			"experience": 0,
			"equipment": [],
			"items": {
				"keys": {
					"yellowKey": 1,
					"blueKey": 1,
					"redKey": 1
				},
				"constants": {
					"book": 1
				},
				"tools": {},
				"equips": {}
			},
			"loc": {
				"direction": "up",
				"x": 6,
				"y": 11
			},
			"flags": {
				"proof_lv": 1,
				"atkm": 0,
				"defm": 1000
			},
			"steps": 0
		},
		"startCanvas": [
			{
				"type": "setValue",
				"name": "flag:ah",
				"value": "0"
			},
			{
				"type": "setValue",
				"name": "flag:doNotPlaySoundWhileChangingFloor",
				"value": "false"
			},
			{
				"type": "setValue",
				"name": "flag:customStatusBarHidden",
				"value": "true"
			},
			{
				"type": "setValue",
				"name": "flag:aStupidWay",
				"value": "true"
			},
			{
				"type": "setValue",
				"name": "flag:battleAutoEnds",
				"value": "true"
			},
			{
				"type": "pauseBgm"
			},
			{
				"type": "stopSound"
			},
			{
				"type": "hideStatusBar"
			},
			{
				"type": "hideHero"
			},
			{
				"type": "if",
				"condition": "true",
				"true": [
					{
						"type": "showImage",
						"code": 1,
						"image": "startBackground.png",
						"loc": [
							0,
							0
						],
						"opacity": 0,
						"time": 750
					},
					{
						"type": "moveImage",
						"code": 1,
						"to": [
							0,
							0
						],
						"opacity": 1,
						"time": 300
					},
					{
						"type": "showImage",
						"code": 2,
						"image": "startHover.png",
						"loc": [
							-100,
							0
						],
						"opacity": 0,
						"time": 650
					},
					{
						"type": "moveImage",
						"code": 2,
						"to": [
							-50,
							0
						],
						"opacity": 0.67,
						"time": 100
					},
					{
						"type": "moveImage",
						"code": 2,
						"to": [
							0,
							0
						],
						"opacity": 1,
						"time": 100
					},
					{
						"type": "showImage",
						"code": 3,
						"image": "startHoverC.png",
						"loc": [
							-30,
							0
						],
						"opacity": 0,
						"time": 150
					},
					{
						"type": "moveImage",
						"code": 3,
						"to": [
							0,
							0
						],
						"opacity": 1,
						"time": 100
					},
					{
						"type": "showImage",
						"code": 4,
						"image": "startButtons.png",
						"loc": [
							0,
							-10
						],
						"opacity": 0,
						"time": 250
					},
					{
						"type": "moveImage",
						"code": 4,
						"to": [
							0,
							0
						],
						"opacity": 1,
						"time": 100
					},
					{
						"type": "showImage",
						"code": 5,
						"image": "startButtonsLit.png",
						"loc": [
							0,
							0
						],
						"opacity": 0,
						"time": 100
					},
					{
						"type": "moveImage",
						"code": 5,
						"to": [
							0,
							0
						],
						"opacity": 1,
						"time": 100
					},
					{
						"type": "sleep",
						"time": 150
					},
					{
						"type": "hideImage",
						"code": 5,
						"time": 0
					},
					{
						"type": "comment",
						"text": "光标显示在第5层"
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:startCycle",
				"value": "true"
			},
			{
				"type": "setValue",
				"name": "flag:startChosen",
				"value": "0"
			},
			{
				"type": "setValue",
				"name": "flag:fastStart",
				"value": "0"
			},
			{
				"type": "while",
				"condition": "flag:startCycle",
				"data": [
					{
						"type": "wait",
						"data": [
							{
								"case": "keyboard",
								"keycode": 32,
								"action": [
									{
										"type": "comment",
										"text": "空格"
									},
									{
										"type": "switch",
										"condition": "flag:startChosen",
										"caseList": [
											{
												"case": "1",
												"action": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "setValue",
														"name": "flag:startCycle",
														"value": "false"
													}
												]
											},
											{
												"case": "2",
												"action": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "callLoad"
													}
												]
											},
											{
												"case": "3",
												"action": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "if",
														"condition": "!core.isReplaying()",
														"true": [
															{
																"type": "function",
																"function": "function(){\ncore.chooseReplayFile()\n}"
															}
														]
													}
												]
											},
											{
												"case": "4",
												"action": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "showImage",
														"code": 6,
														"image": "instructions.png",
														"loc": [
															0,
															0
														],
														"opacity": 1,
														"time": 0
													},
													{
														"type": "wait"
													},
													{
														"type": "hideImage",
														"code": 6,
														"time": 0
													}
												]
											},
											{
												"case": "5",
												"action": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "showImage",
														"code": 6,
														"image": "aboutMonsters.png",
														"loc": [
															0,
															0
														],
														"opacity": 1,
														"time": 0
													},
													{
														"type": "setValue",
														"name": "flag:startAboutMonstersCurrentPage",
														"value": "1"
													},
													{
														"type": "showImage",
														"code": 7,
														"image": "aboutMonstersHover1.png",
														"loc": [
															0,
															0
														],
														"opacity": 1,
														"time": 0
													},
													{
														"type": "while",
														"condition": "true",
														"data": [
															{
																"type": "wait",
																"data": [
																	{
																		"case": "keyboard",
																		"keycode": 13,
																		"action": [
																			{
																				"type": "comment",
																				"text": "点击中间"
																			},
																			{
																				"type": "playSound",
																				"name": "confirm.mp3"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "hideImage",
																				"code": 6,
																				"time": 0
																			},
																			{
																				"type": "break"
																			}
																		]
																	},
																	{
																		"case": "mouse",
																		"px": [
																			105,
																			311
																		],
																		"py": [
																			0,
																			416
																		],
																		"action": [
																			{
																				"type": "comment",
																				"text": "点击中间"
																			},
																			{
																				"type": "playSound",
																				"name": "confirm.mp3"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "hideImage",
																				"code": 6,
																				"time": 0
																			},
																			{
																				"type": "break"
																			}
																		]
																	},
																	{
																		"case": "keyboard",
																		"keycode": 37,
																		"action": [
																			{
																				"type": "playSound",
																				"name": "cursor.mp3"
																			},
																			{
																				"type": "comment",
																				"text": "点击左边"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "addValue",
																				"name": "flag:startAboutMonstersCurrentPage",
																				"value": "-1"
																			},
																			{
																				"type": "if",
																				"condition": "(flag:startAboutMonstersCurrentPage<1)",
																				"true": [
																					{
																						"type": "setValue",
																						"name": "flag:startAboutMonstersCurrentPage",
																						"value": "3"
																					}
																				]
																			},
																			{
																				"type": "switch",
																				"condition": "flag:startAboutMonstersCurrentPage",
																				"caseList": [
																					{
																						"case": "2",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover2.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "3",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover3.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "default",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover1.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					}
																				]
																			}
																		]
																	},
																	{
																		"case": "mouse",
																		"px": [
																			0,
																			104
																		],
																		"py": [
																			0,
																			416
																		],
																		"action": [
																			{
																				"type": "playSound",
																				"name": "cursor.mp3"
																			},
																			{
																				"type": "comment",
																				"text": "点击左边"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "addValue",
																				"name": "flag:startAboutMonstersCurrentPage",
																				"value": "-1"
																			},
																			{
																				"type": "if",
																				"condition": "(flag:startAboutMonstersCurrentPage<1)",
																				"true": [
																					{
																						"type": "setValue",
																						"name": "flag:startAboutMonstersCurrentPage",
																						"value": "3"
																					}
																				]
																			},
																			{
																				"type": "switch",
																				"condition": "flag:startAboutMonstersCurrentPage",
																				"caseList": [
																					{
																						"case": "2",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover2.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "3",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover3.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "default",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover1.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					}
																				]
																			}
																		]
																	},
																	{
																		"case": "keyboard",
																		"keycode": 39,
																		"action": [
																			{
																				"type": "playSound",
																				"name": "cursor.mp3"
																			},
																			{
																				"type": "comment",
																				"text": "点击右边"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "addValue",
																				"name": "flag:startAboutMonstersCurrentPage",
																				"value": "1"
																			},
																			{
																				"type": "if",
																				"condition": "(flag:startAboutMonstersCurrentPage>3)",
																				"true": [
																					{
																						"type": "setValue",
																						"name": "flag:startAboutMonstersCurrentPage",
																						"value": "1"
																					}
																				]
																			},
																			{
																				"type": "switch",
																				"condition": "flag:startAboutMonstersCurrentPage",
																				"caseList": [
																					{
																						"case": "2",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover2.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "3",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover3.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "default",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover1.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					}
																				]
																			}
																		]
																	},
																	{
																		"case": "mouse",
																		"px": [
																			312,
																			416
																		],
																		"py": [
																			0,
																			416
																		],
																		"action": [
																			{
																				"type": "playSound",
																				"name": "cursor.mp3"
																			},
																			{
																				"type": "comment",
																				"text": "点击右边"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "addValue",
																				"name": "flag:startAboutMonstersCurrentPage",
																				"value": "1"
																			},
																			{
																				"type": "if",
																				"condition": "(flag:startAboutMonstersCurrentPage>3)",
																				"true": [
																					{
																						"type": "setValue",
																						"name": "flag:startAboutMonstersCurrentPage",
																						"value": "1"
																					}
																				]
																			},
																			{
																				"type": "switch",
																				"condition": "flag:startAboutMonstersCurrentPage",
																				"caseList": [
																					{
																						"case": "2",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover2.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "3",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover3.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "default",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover1.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					}
																				]
																			}
																		]
																	}
																]
															}
														]
													}
												]
											},
											{
												"case": "default",
												"action": [
													{
														"type": "setValue",
														"name": "flag:startChosen",
														"value": "1"
													},
													{
														"type": "showImage",
														"code": 5,
														"image": "startCursorLarge.png",
														"loc": [
															0,
															0
														],
														"opacity": 1,
														"time": 0
													}
												]
											}
										]
									}
								]
							},
							{
								"case": "keyboard",
								"keycode": 13,
								"action": [
									{
										"type": "comment",
										"text": "回车"
									},
									{
										"type": "switch",
										"condition": "flag:startChosen",
										"caseList": [
											{
												"case": "1",
												"action": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "setValue",
														"name": "flag:startCycle",
														"value": "false"
													}
												]
											},
											{
												"case": "2",
												"action": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "callLoad"
													}
												]
											},
											{
												"case": "3",
												"action": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "if",
														"condition": "!core.isReplaying()",
														"true": [
															{
																"type": "function",
																"function": "function(){\ncore.chooseReplayFile()\n}"
															}
														]
													}
												]
											},
											{
												"case": "4",
												"action": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "showImage",
														"code": 6,
														"image": "instructions.png",
														"loc": [
															0,
															0
														],
														"opacity": 1,
														"time": 0
													},
													{
														"type": "wait"
													},
													{
														"type": "hideImage",
														"code": 6,
														"time": 0
													}
												]
											},
											{
												"case": "5",
												"action": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "showImage",
														"code": 6,
														"image": "aboutMonsters.png",
														"loc": [
															0,
															0
														],
														"opacity": 1,
														"time": 0
													},
													{
														"type": "setValue",
														"name": "flag:startAboutMonstersCurrentPage",
														"value": "1"
													},
													{
														"type": "showImage",
														"code": 7,
														"image": "aboutMonstersHover1.png",
														"loc": [
															0,
															0
														],
														"opacity": 1,
														"time": 0
													},
													{
														"type": "while",
														"condition": "true",
														"data": [
															{
																"type": "wait",
																"data": [
																	{
																		"case": "keyboard",
																		"keycode": 13,
																		"action": [
																			{
																				"type": "comment",
																				"text": "点击中间"
																			},
																			{
																				"type": "playSound",
																				"name": "confirm.mp3"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "hideImage",
																				"code": 6,
																				"time": 0
																			},
																			{
																				"type": "break"
																			}
																		]
																	},
																	{
																		"case": "mouse",
																		"px": [
																			105,
																			311
																		],
																		"py": [
																			0,
																			416
																		],
																		"action": [
																			{
																				"type": "comment",
																				"text": "点击中间"
																			},
																			{
																				"type": "playSound",
																				"name": "confirm.mp3"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "hideImage",
																				"code": 6,
																				"time": 0
																			},
																			{
																				"type": "break"
																			}
																		]
																	},
																	{
																		"case": "keyboard",
																		"keycode": 37,
																		"action": [
																			{
																				"type": "playSound",
																				"name": "cursor.mp3"
																			},
																			{
																				"type": "comment",
																				"text": "点击左边"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "addValue",
																				"name": "flag:startAboutMonstersCurrentPage",
																				"value": "-1"
																			},
																			{
																				"type": "if",
																				"condition": "(flag:startAboutMonstersCurrentPage<1)",
																				"true": [
																					{
																						"type": "setValue",
																						"name": "flag:startAboutMonstersCurrentPage",
																						"value": "3"
																					}
																				]
																			},
																			{
																				"type": "switch",
																				"condition": "flag:startAboutMonstersCurrentPage",
																				"caseList": [
																					{
																						"case": "2",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover2.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "3",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover3.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "default",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover1.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					}
																				]
																			}
																		]
																	},
																	{
																		"case": "mouse",
																		"px": [
																			0,
																			104
																		],
																		"py": [
																			0,
																			416
																		],
																		"action": [
																			{
																				"type": "playSound",
																				"name": "cursor.mp3"
																			},
																			{
																				"type": "comment",
																				"text": "点击左边"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "addValue",
																				"name": "flag:startAboutMonstersCurrentPage",
																				"value": "-1"
																			},
																			{
																				"type": "if",
																				"condition": "(flag:startAboutMonstersCurrentPage<1)",
																				"true": [
																					{
																						"type": "setValue",
																						"name": "flag:startAboutMonstersCurrentPage",
																						"value": "3"
																					}
																				]
																			},
																			{
																				"type": "switch",
																				"condition": "flag:startAboutMonstersCurrentPage",
																				"caseList": [
																					{
																						"case": "2",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover2.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "3",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover3.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "default",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover1.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					}
																				]
																			}
																		]
																	},
																	{
																		"case": "keyboard",
																		"keycode": 39,
																		"action": [
																			{
																				"type": "playSound",
																				"name": "cursor.mp3"
																			},
																			{
																				"type": "comment",
																				"text": "点击右边"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "addValue",
																				"name": "flag:startAboutMonstersCurrentPage",
																				"value": "1"
																			},
																			{
																				"type": "if",
																				"condition": "(flag:startAboutMonstersCurrentPage>3)",
																				"true": [
																					{
																						"type": "setValue",
																						"name": "flag:startAboutMonstersCurrentPage",
																						"value": "1"
																					}
																				]
																			},
																			{
																				"type": "switch",
																				"condition": "flag:startAboutMonstersCurrentPage",
																				"caseList": [
																					{
																						"case": "2",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover2.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "3",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover3.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "default",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover1.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					}
																				]
																			}
																		]
																	},
																	{
																		"case": "mouse",
																		"px": [
																			312,
																			416
																		],
																		"py": [
																			0,
																			416
																		],
																		"action": [
																			{
																				"type": "playSound",
																				"name": "cursor.mp3"
																			},
																			{
																				"type": "comment",
																				"text": "点击右边"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "addValue",
																				"name": "flag:startAboutMonstersCurrentPage",
																				"value": "1"
																			},
																			{
																				"type": "if",
																				"condition": "(flag:startAboutMonstersCurrentPage>3)",
																				"true": [
																					{
																						"type": "setValue",
																						"name": "flag:startAboutMonstersCurrentPage",
																						"value": "1"
																					}
																				]
																			},
																			{
																				"type": "switch",
																				"condition": "flag:startAboutMonstersCurrentPage",
																				"caseList": [
																					{
																						"case": "2",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover2.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "3",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover3.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "default",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover1.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					}
																				]
																			}
																		]
																	}
																]
															}
														]
													}
												]
											},
											{
												"case": "default",
												"action": [
													{
														"type": "setValue",
														"name": "flag:startChosen",
														"value": "1"
													},
													{
														"type": "showImage",
														"code": 5,
														"image": "startCursorLarge.png",
														"loc": [
															0,
															0
														],
														"opacity": 1,
														"time": 0
													}
												]
											}
										]
									}
								]
							},
							{
								"case": "keyboard",
								"keycode": 37,
								"action": [
									{
										"type": "comment",
										"text": "左"
									},
									{
										"type": "playSound",
										"name": "cursor.mp3"
									},
									{
										"type": "if",
										"condition": "flag:startChosen==0",
										"true": [
											{
												"type": "setValue",
												"name": "flag:startChosen",
												"value": "1"
											},
											{
												"type": "showImage",
												"code": 5,
												"image": "startCursorLarge.png",
												"loc": [
													0,
													0
												],
												"opacity": 1,
												"time": 0
											}
										],
										"false": [
											{
												"type": "hideImage",
												"code": 5,
												"time": 0
											},
											{
												"type": "switch",
												"condition": "flag:startChosen",
												"caseList": [
													{
														"case": "3",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "2"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorSmall.png",
																"loc": [
																	0,
																	0
																],
																"opacity": 1,
																"time": 0
															}
														]
													},
													{
														"case": "4",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "3"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorSmall.png",
																"loc": [
																	168,
																	0
																],
																"opacity": 1,
																"time": 0
															}
														]
													},
													{
														"case": "5",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "4"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorSmall.png",
																"loc": [
																	0,
																	48
																],
																"opacity": 1,
																"time": 0
															}
														]
													},
													{
														"case": "1",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "5"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorSmall.png",
																"loc": [
																	168,
																	48
																],
																"opacity": 1,
																"time": 0
															}
														]
													},
													{
														"case": "default",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "1"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorLarge.png",
																"loc": [
																	0,
																	0
																],
																"opacity": 1,
																"time": 0
															}
														]
													}
												]
											}
										]
									}
								]
							},
							{
								"case": "keyboard",
								"keycode": 40,
								"action": [
									{
										"type": "comment",
										"text": "下"
									},
									{
										"type": "playSound",
										"name": "cursor.mp3"
									},
									{
										"type": "if",
										"condition": "flag:startChosen==0",
										"true": [
											{
												"type": "setValue",
												"name": "flag:startChosen",
												"value": "1"
											},
											{
												"type": "showImage",
												"code": 5,
												"image": "startCursorLarge.png",
												"loc": [
													0,
													0
												],
												"opacity": 1,
												"time": 0
											}
										],
										"false": [
											{
												"type": "hideImage",
												"code": 5,
												"time": 0
											},
											{
												"type": "switch",
												"condition": "flag:startChosen",
												"caseList": [
													{
														"case": "1",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "2"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorSmall.png",
																"loc": [
																	0,
																	0
																],
																"opacity": 1,
																"time": 0
															}
														]
													},
													{
														"case": "2",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "4"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorSmall.png",
																"loc": [
																	0,
																	48
																],
																"opacity": 1,
																"time": 0
															}
														]
													},
													{
														"case": "3",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "5"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorSmall.png",
																"loc": [
																	168,
																	48
																],
																"opacity": 1,
																"time": 0
															}
														]
													},
													{
														"case": "default",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "1"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorLarge.png",
																"loc": [
																	0,
																	0
																],
																"opacity": 1,
																"time": 0
															}
														]
													}
												]
											}
										]
									}
								]
							},
							{
								"case": "keyboard",
								"keycode": 39,
								"action": [
									{
										"type": "comment",
										"text": "右"
									},
									{
										"type": "playSound",
										"name": "cursor.mp3"
									},
									{
										"type": "if",
										"condition": "flag:startChosen==0",
										"true": [
											{
												"type": "setValue",
												"name": "flag:startChosen",
												"value": "1"
											},
											{
												"type": "showImage",
												"code": 5,
												"image": "startCursorLarge.png",
												"loc": [
													0,
													0
												],
												"opacity": 1,
												"time": 0
											}
										],
										"false": [
											{
												"type": "hideImage",
												"code": 5,
												"time": 0
											},
											{
												"type": "switch",
												"condition": "flag:startChosen",
												"caseList": [
													{
														"case": "1",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "2"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorSmall.png",
																"loc": [
																	0,
																	0
																],
																"opacity": 1,
																"time": 0
															}
														]
													},
													{
														"case": "2",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "3"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorSmall.png",
																"loc": [
																	168,
																	0
																],
																"opacity": 1,
																"time": 0
															}
														]
													},
													{
														"case": "3",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "4"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorSmall.png",
																"loc": [
																	0,
																	48
																],
																"opacity": 1,
																"time": 0
															}
														]
													},
													{
														"case": "4",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "5"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorSmall.png",
																"loc": [
																	168,
																	48
																],
																"opacity": 1,
																"time": 0
															}
														]
													},
													{
														"case": "default",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "1"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorLarge.png",
																"loc": [
																	0,
																	0
																],
																"opacity": 1,
																"time": 0
															}
														]
													}
												]
											}
										]
									}
								]
							},
							{
								"case": "keyboard",
								"keycode": 38,
								"action": [
									{
										"type": "comment",
										"text": "上"
									},
									{
										"type": "playSound",
										"name": "cursor.mp3"
									},
									{
										"type": "if",
										"condition": "flag:startChosen==0",
										"true": [
											{
												"type": "setValue",
												"name": "flag:startChosen",
												"value": "1"
											},
											{
												"type": "showImage",
												"code": 5,
												"image": "startCursorLarge.png",
												"loc": [
													0,
													0
												],
												"opacity": 1,
												"time": 0
											}
										],
										"false": [
											{
												"type": "hideImage",
												"code": 5,
												"time": 0
											},
											{
												"type": "switch",
												"condition": "flag:startChosen",
												"caseList": [
													{
														"case": "1",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "5"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorSmall.png",
																"loc": [
																	168,
																	48
																],
																"opacity": 1,
																"time": 0
															}
														]
													},
													{
														"case": "4",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "2"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorSmall.png",
																"loc": [
																	0,
																	0
																],
																"opacity": 1,
																"time": 0
															}
														]
													},
													{
														"case": "5",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "3"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorSmall.png",
																"loc": [
																	168,
																	0
																],
																"opacity": 1,
																"time": 0
															}
														]
													},
													{
														"case": "default",
														"action": [
															{
																"type": "setValue",
																"name": "flag:startChosen",
																"value": "1"
															},
															{
																"type": "showImage",
																"code": 5,
																"image": "startCursorLarge.png",
																"loc": [
																	0,
																	0
																],
																"opacity": 1,
																"time": 0
															}
														]
													}
												]
											}
										]
									}
								]
							},
							{
								"case": "keyboard",
								"keycode": 188,
								"action": [
									{
										"type": "comment",
										"text": "按下逗号快速以经典开始"
									},
									{
										"type": "setValue",
										"name": "flag:startCycle",
										"value": "false"
									},
									{
										"type": "setValue",
										"name": "flag:fastStart",
										"value": "1"
									}
								]
							},
							{
								"case": "keyboard",
								"keycode": 190,
								"action": [
									{
										"type": "comment",
										"text": "按下句号快速以极速开始"
									},
									{
										"type": "setValue",
										"name": "flag:startCycle",
										"value": "false"
									},
									{
										"type": "setValue",
										"name": "flag:fastStart",
										"value": "2"
									}
								]
							},
							{
								"case": "mouse",
								"px": [
									44,
									371
								],
								"py": [
									184,
									223
								],
								"action": [
									{
										"type": "comment",
										"text": "开始游戏"
									},
									{
										"type": "if",
										"condition": "(flag:startChosen>0)",
										"true": [
											{
												"type": "if",
												"condition": "(flag:startChosen==1)",
												"true": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "setValue",
														"name": "flag:startCycle",
														"value": "false"
													}
												],
												"false": [
													{
														"type": "hideImage",
														"code": 5,
														"time": 0
													},
													{
														"type": "setValue",
														"name": "flag:startChosen",
														"value": "1"
													},
													{
														"type": "showImage",
														"code": 5,
														"image": "startCursorLarge.png",
														"loc": [
															0,
															0
														],
														"opacity": 1,
														"time": 0
													},
													{
														"type": "playSound",
														"name": "cursor.mp3"
													}
												]
											}
										],
										"false": [
											{
												"type": "setValue",
												"name": "flag:startChosen",
												"value": "1"
											},
											{
												"type": "showImage",
												"code": 5,
												"image": "startCursorLarge.png",
												"loc": [
													0,
													0
												],
												"opacity": 1,
												"time": 0
											},
											{
												"type": "playSound",
												"name": "cursor.mp3"
											}
										]
									}
								]
							},
							{
								"case": "keyboard",
								"keycode": 68,
								"action": [
									{
										"type": "comment",
										"text": "读取存档"
									},
									{
										"type": "if",
										"condition": "(flag:startChosen>0)",
										"true": [
											{
												"type": "if",
												"condition": "(flag:startChosen==2)",
												"true": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "callLoad"
													}
												],
												"false": [
													{
														"type": "hideImage",
														"code": 5,
														"time": 0
													},
													{
														"type": "setValue",
														"name": "flag:startChosen",
														"value": "2"
													},
													{
														"type": "showImage",
														"code": 5,
														"image": "startCursorSmall.png",
														"loc": [
															0,
															0
														],
														"opacity": 1,
														"time": 0
													},
													{
														"type": "playSound",
														"name": "cursor.mp3"
													}
												]
											}
										],
										"false": [
											{
												"type": "setValue",
												"name": "flag:startChosen",
												"value": "2"
											},
											{
												"type": "showImage",
												"code": 5,
												"image": "startCursorSmall.png",
												"loc": [
													0,
													0
												],
												"opacity": 1,
												"time": 0
											},
											{
												"type": "playSound",
												"name": "cursor.mp3"
											}
										]
									}
								]
							},
							{
								"case": "mouse",
								"px": [
									44,
									203
								],
								"py": [
									232,
									271
								],
								"action": [
									{
										"type": "comment",
										"text": "读取存档"
									},
									{
										"type": "if",
										"condition": "(flag:startChosen>0)",
										"true": [
											{
												"type": "if",
												"condition": "(flag:startChosen==2)",
												"true": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "callLoad"
													}
												],
												"false": [
													{
														"type": "hideImage",
														"code": 5,
														"time": 0
													},
													{
														"type": "setValue",
														"name": "flag:startChosen",
														"value": "2"
													},
													{
														"type": "showImage",
														"code": 5,
														"image": "startCursorSmall.png",
														"loc": [
															0,
															0
														],
														"opacity": 1,
														"time": 0
													},
													{
														"type": "playSound",
														"name": "cursor.mp3"
													}
												]
											}
										],
										"false": [
											{
												"type": "setValue",
												"name": "flag:startChosen",
												"value": "2"
											},
											{
												"type": "showImage",
												"code": 5,
												"image": "startCursorSmall.png",
												"loc": [
													0,
													0
												],
												"opacity": 1,
												"time": 0
											},
											{
												"type": "playSound",
												"name": "cursor.mp3"
											}
										]
									}
								]
							},
							{
								"case": "keyboard",
								"keycode": 82,
								"action": [
									{
										"type": "comment",
										"text": "录像回放"
									},
									{
										"type": "if",
										"condition": "(flag:startChosen>0)",
										"true": [
											{
												"type": "if",
												"condition": "(flag:startChosen==3)",
												"true": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "if",
														"condition": "!core.isReplaying()",
														"true": [
															{
																"type": "function",
																"function": "function(){\ncore.chooseReplayFile()\n}"
															}
														]
													}
												],
												"false": [
													{
														"type": "hideImage",
														"code": 5,
														"time": 0
													},
													{
														"type": "setValue",
														"name": "flag:startChosen",
														"value": "3"
													},
													{
														"type": "showImage",
														"code": 5,
														"image": "startCursorSmall.png",
														"loc": [
															168,
															0
														],
														"opacity": 1,
														"time": 0
													},
													{
														"type": "playSound",
														"name": "cursor.mp3"
													}
												]
											}
										],
										"false": [
											{
												"type": "setValue",
												"name": "flag:startChosen",
												"value": "3"
											},
											{
												"type": "showImage",
												"code": 5,
												"image": "startCursorSmall.png",
												"loc": [
													168,
													0
												],
												"opacity": 1,
												"time": 0
											},
											{
												"type": "playSound",
												"name": "cursor.mp3"
											}
										]
									}
								]
							},
							{
								"case": "mouse",
								"px": [
									212,
									371
								],
								"py": [
									232,
									271
								],
								"action": [
									{
										"type": "comment",
										"text": "录像回放"
									},
									{
										"type": "if",
										"condition": "(flag:startChosen>0)",
										"true": [
											{
												"type": "if",
												"condition": "(flag:startChosen==3)",
												"true": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "if",
														"condition": "!core.isReplaying()",
														"true": [
															{
																"type": "function",
																"function": "function(){\ncore.chooseReplayFile()\n}"
															}
														]
													}
												],
												"false": [
													{
														"type": "hideImage",
														"code": 5,
														"time": 0
													},
													{
														"type": "setValue",
														"name": "flag:startChosen",
														"value": "3"
													},
													{
														"type": "showImage",
														"code": 5,
														"image": "startCursorSmall.png",
														"loc": [
															168,
															0
														],
														"opacity": 1,
														"time": 0
													},
													{
														"type": "playSound",
														"name": "cursor.mp3"
													}
												]
											}
										],
										"false": [
											{
												"type": "setValue",
												"name": "flag:startChosen",
												"value": "3"
											},
											{
												"type": "showImage",
												"code": 5,
												"image": "startCursorSmall.png",
												"loc": [
													168,
													0
												],
												"opacity": 1,
												"time": 0
											},
											{
												"type": "playSound",
												"name": "cursor.mp3"
											}
										]
									}
								]
							},
							{
								"case": "mouse",
								"px": [
									44,
									203
								],
								"py": [
									280,
									319
								],
								"action": [
									{
										"type": "comment",
										"text": "游戏说明"
									},
									{
										"type": "if",
										"condition": "(flag:startChosen>0)",
										"true": [
											{
												"type": "if",
												"condition": "(flag:startChosen==4)",
												"true": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "showImage",
														"code": 6,
														"image": "instructions.png",
														"loc": [
															0,
															0
														],
														"opacity": 1,
														"time": 0
													},
													{
														"type": "wait"
													},
													{
														"type": "hideImage",
														"code": 6,
														"time": 0
													}
												],
												"false": [
													{
														"type": "hideImage",
														"code": 5,
														"time": 0
													},
													{
														"type": "setValue",
														"name": "flag:startChosen",
														"value": "4"
													},
													{
														"type": "showImage",
														"code": 5,
														"image": "startCursorSmall.png",
														"loc": [
															0,
															48
														],
														"opacity": 1,
														"time": 0
													},
													{
														"type": "playSound",
														"name": "cursor.mp3"
													}
												]
											}
										],
										"false": [
											{
												"type": "setValue",
												"name": "flag:startChosen",
												"value": "4"
											},
											{
												"type": "showImage",
												"code": 5,
												"image": "startCursorSmall.png",
												"loc": [
													0,
													48
												],
												"opacity": 1,
												"time": 0
											},
											{
												"type": "playSound",
												"name": "cursor.mp3"
											}
										]
									}
								]
							},
							{
								"case": "mouse",
								"px": [
									212,
									371
								],
								"py": [
									280,
									319
								],
								"action": [
									{
										"type": "comment",
										"text": "关于怪物"
									},
									{
										"type": "if",
										"condition": "(flag:startChosen>0)",
										"true": [
											{
												"type": "if",
												"condition": "(flag:startChosen==5)",
												"true": [
													{
														"type": "playSound",
														"name": "confirm.mp3"
													},
													{
														"type": "showImage",
														"code": 6,
														"image": "aboutMonsters.png",
														"loc": [
															0,
															0
														],
														"opacity": 1,
														"time": 0
													},
													{
														"type": "setValue",
														"name": "flag:startAboutMonstersCurrentPage",
														"value": "1"
													},
													{
														"type": "showImage",
														"code": 7,
														"image": "aboutMonstersHover1.png",
														"loc": [
															0,
															0
														],
														"opacity": 1,
														"time": 0
													},
													{
														"type": "while",
														"condition": "true",
														"data": [
															{
																"type": "wait",
																"data": [
																	{
																		"case": "keyboard",
																		"keycode": 13,
																		"action": [
																			{
																				"type": "comment",
																				"text": "点击中间"
																			},
																			{
																				"type": "playSound",
																				"name": "confirm.mp3"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "hideImage",
																				"code": 6,
																				"time": 0
																			},
																			{
																				"type": "break"
																			}
																		]
																	},
																	{
																		"case": "mouse",
																		"px": [
																			105,
																			311
																		],
																		"py": [
																			0,
																			416
																		],
																		"action": [
																			{
																				"type": "comment",
																				"text": "点击中间"
																			},
																			{
																				"type": "playSound",
																				"name": "confirm.mp3"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "hideImage",
																				"code": 6,
																				"time": 0
																			},
																			{
																				"type": "break"
																			}
																		]
																	},
																	{
																		"case": "keyboard",
																		"keycode": 37,
																		"action": [
																			{
																				"type": "playSound",
																				"name": "cursor.mp3"
																			},
																			{
																				"type": "comment",
																				"text": "点击左边"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "addValue",
																				"name": "flag:startAboutMonstersCurrentPage",
																				"value": "-1"
																			},
																			{
																				"type": "if",
																				"condition": "(flag:startAboutMonstersCurrentPage<1)",
																				"true": [
																					{
																						"type": "setValue",
																						"name": "flag:startAboutMonstersCurrentPage",
																						"value": "3"
																					}
																				]
																			},
																			{
																				"type": "switch",
																				"condition": "flag:startAboutMonstersCurrentPage",
																				"caseList": [
																					{
																						"case": "2",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover2.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "3",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover3.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "default",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover1.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					}
																				]
																			}
																		]
																	},
																	{
																		"case": "mouse",
																		"px": [
																			0,
																			104
																		],
																		"py": [
																			0,
																			416
																		],
																		"action": [
																			{
																				"type": "playSound",
																				"name": "cursor.mp3"
																			},
																			{
																				"type": "comment",
																				"text": "点击左边"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "addValue",
																				"name": "flag:startAboutMonstersCurrentPage",
																				"value": "-1"
																			},
																			{
																				"type": "if",
																				"condition": "(flag:startAboutMonstersCurrentPage<1)",
																				"true": [
																					{
																						"type": "setValue",
																						"name": "flag:startAboutMonstersCurrentPage",
																						"value": "3"
																					}
																				]
																			},
																			{
																				"type": "switch",
																				"condition": "flag:startAboutMonstersCurrentPage",
																				"caseList": [
																					{
																						"case": "2",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover2.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "3",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover3.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "default",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover1.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					}
																				]
																			}
																		]
																	},
																	{
																		"case": "keyboard",
																		"keycode": 39,
																		"action": [
																			{
																				"type": "playSound",
																				"name": "cursor.mp3"
																			},
																			{
																				"type": "comment",
																				"text": "点击右边"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "addValue",
																				"name": "flag:startAboutMonstersCurrentPage",
																				"value": "1"
																			},
																			{
																				"type": "if",
																				"condition": "(flag:startAboutMonstersCurrentPage>3)",
																				"true": [
																					{
																						"type": "setValue",
																						"name": "flag:startAboutMonstersCurrentPage",
																						"value": "1"
																					}
																				]
																			},
																			{
																				"type": "switch",
																				"condition": "flag:startAboutMonstersCurrentPage",
																				"caseList": [
																					{
																						"case": "2",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover2.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "3",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover3.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "default",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover1.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					}
																				]
																			}
																		]
																	},
																	{
																		"case": "mouse",
																		"px": [
																			312,
																			416
																		],
																		"py": [
																			0,
																			416
																		],
																		"action": [
																			{
																				"type": "playSound",
																				"name": "cursor.mp3"
																			},
																			{
																				"type": "comment",
																				"text": "点击右边"
																			},
																			{
																				"type": "hideImage",
																				"code": 7,
																				"time": 0
																			},
																			{
																				"type": "addValue",
																				"name": "flag:startAboutMonstersCurrentPage",
																				"value": "1"
																			},
																			{
																				"type": "if",
																				"condition": "(flag:startAboutMonstersCurrentPage>3)",
																				"true": [
																					{
																						"type": "setValue",
																						"name": "flag:startAboutMonstersCurrentPage",
																						"value": "1"
																					}
																				]
																			},
																			{
																				"type": "switch",
																				"condition": "flag:startAboutMonstersCurrentPage",
																				"caseList": [
																					{
																						"case": "2",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover2.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "3",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover3.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					},
																					{
																						"case": "default",
																						"action": [
																							{
																								"type": "showImage",
																								"code": 7,
																								"image": "aboutMonstersHover1.png",
																								"loc": [
																									0,
																									0
																								],
																								"opacity": 1,
																								"time": 0
																							}
																						]
																					}
																				]
																			}
																		]
																	}
																]
															}
														]
													}
												],
												"false": [
													{
														"type": "hideImage",
														"code": 5,
														"time": 0
													},
													{
														"type": "setValue",
														"name": "flag:startChosen",
														"value": "5"
													},
													{
														"type": "showImage",
														"code": 5,
														"image": "startCursorSmall.png",
														"loc": [
															168,
															48
														],
														"opacity": 1,
														"time": 0
													},
													{
														"type": "playSound",
														"name": "cursor.mp3"
													}
												]
											}
										],
										"false": [
											{
												"type": "setValue",
												"name": "flag:startChosen",
												"value": "5"
											},
											{
												"type": "showImage",
												"code": 5,
												"image": "startCursorSmall.png",
												"loc": [
													168,
													48
												],
												"opacity": 1,
												"time": 0
											},
											{
												"type": "playSound",
												"name": "cursor.mp3"
											}
										]
									}
								]
							}
						]
					}
				]
			},
			{
				"type": "if",
				"condition": "flag:fastStart>0",
				"true": [
					{
						"type": "hideImage",
						"code": 1,
						"time": 100,
						"async": true
					},
					{
						"type": "hideImage",
						"code": 2,
						"time": 100,
						"async": true
					},
					{
						"type": "hideImage",
						"code": 3,
						"time": 100,
						"async": true
					},
					{
						"type": "hideImage",
						"code": 4,
						"time": 100,
						"async": true
					},
					{
						"type": "hideImage",
						"code": 5,
						"time": 100,
						"async": true
					},
					{
						"type": "waitAsync"
					},
					{
						"type": "sleep",
						"time": 100
					}
				],
				"false": [
					{
						"type": "hideImage",
						"code": 1,
						"time": 100,
						"async": true
					},
					{
						"type": "hideImage",
						"code": 2,
						"time": 100,
						"async": true
					},
					{
						"type": "hideImage",
						"code": 3,
						"time": 100,
						"async": true
					},
					{
						"type": "hideImage",
						"code": 4,
						"time": 100,
						"async": true
					},
					{
						"type": "hideImage",
						"code": 5,
						"time": 100,
						"async": true
					},
					{
						"type": "waitAsync"
					},
					{
						"type": "sleep",
						"time": 667
					}
				]
			},
			{
				"type": "comment",
				"text": "开始游戏"
			},
			{
				"type": "function",
				"function": "function(){\ncore.control.checkBgm()\n}"
			},
			{
				"type": "function",
				"function": "function(){\ncore.dom.musicBtn.style.display = 'none';\n}"
			}
		],
		"startText": [
			{
				"type": "setText",
				"position": "down",
				"offset": 5
			},
			{
				"type": "function",
				"function": "function(){\ncore.status.hero.agi = 2;\ncore.status.hero.cri = 5;\n// 为了省事直接照搬\nvar oldValues = {\n\tlavaDamage: 50,\n\tpoisonDamage: 10,\n\tweakValue: 50,\n\tredJewel: 2,\n\tblueJewel: 2,\n\tgreenJewel: 1,\n\tredPotion: 150,\n\tbluePotion: 400,\n\tyellowPotion: 114514,\n\tgreenPotion: 114514,\n\tsword0: 0,\n\tshield0: 0,\n\tsword1: 8,\n\tshield1: 13,\n\tsword2: 16,\n\tshield2: 22,\n\tsword3: 30,\n\tshield3: 7,\n\tsword4: 40,\n\tshield4: 35,\n\tsword5: 50,\n\tshield5: 50,\n\tmoneyPocket: 200,\n\tbreakArmor: 0.9,\n\tcounterAttack: 0.1,\n\tpurify: 3,\n\thatred: 2,\n\tmaxValidHp: null,\n\tanimateSpeed: 200\n};\nfor (var k in oldValues) {\n\tif (!core.values[k]) core.values[k] = oldValues[k];\n}\nfor (var key in core.values) {\n\tif (oldValues[key]) core.values[key] = oldValues[key];\n}\n}"
			},
			{
				"type": "showImage",
				"code": 1,
				"image": "gengxin1.jpg",
				"sloc": [
					0,
					0,
					null
				],
				"loc": [
					0,
					0,
					null
				],
				"opacity": 1,
				"time": 0
			},
			"按键继续",
			{
				"type": "hideImage",
				"code": 1,
				"time": 0
			},
			{
				"type": "showImage",
				"code": 2,
				"image": "gengxin2.jpg",
				"sloc": [
					0,
					0,
					null
				],
				"loc": [
					0,
					0,
					null
				],
				"opacity": 1,
				"time": 0
			},
			"按键继续",
			{
				"type": "hideImage",
				"code": 2,
				"time": 0
			},
			{
				"type": "showImage",
				"code": 3,
				"image": "gengxin3.jpg",
				"sloc": [
					0,
					0,
					null
				],
				"loc": [
					0,
					0,
					null
				],
				"opacity": 1,
				"time": 0
			},
			"按键继续",
			{
				"type": "hideImage",
				"code": 3,
				"time": 0
			},
			{
				"type": "if",
				"condition": "false",
				"true": [
					"本塔和原版新新魔塔的区别（包括但不限于）如下：\n - 瞬间战斗模式下，战斗伤害计算时取平均数学期望值（每1点敏捷提供1%减伤，每1点暴击提供1%伤害增幅）。\n - 可被任意门变为黄门的墙和普通墙的材质略有不同（只有这样的墙壁才能被变为黄门）。\n - 勇者之证：1级暴击增加，2级连击次数增加，3级附带额外伤害。\n - 霸者之证：1级攻防增加并反弹非魔攻怪物伤害，2级获得额外防御，3级减少对方防御。\n - 贤者之证：1级敏捷增加并造成额外伤害，2级以后会有一定生命回复。\n - 白银怪被删除；-22F的四个逻辑门需要手动使用宝石锄头。\n - 衰弱改成固定数值50点（原版可以SL避免，因此直接改成50）。\n如果有任何问题请加群539113091进行反馈。"
				]
			},
			{
				"type": "showImage",
				"code": 8,
				"image": "plotStart.png",
				"loc": [
					0,
					0
				],
				"opacity": 0,
				"time": 0
			},
			{
				"type": "setValue",
				"name": "flag:startCycle",
				"value": "true"
			},
			{
				"type": "setValue",
				"name": "flag:startChosen",
				"value": "0"
			},
			{
				"type": "switch",
				"condition": "flag:fastStart",
				"caseList": [
					{
						"case": "1",
						"action": [
							{
								"type": "setValue",
								"name": "flag:useBattleAnimate",
								"value": "true"
							},
							{
								"type": "setGlobalValue",
								"name": "weakValue",
								"value": 0.5
							},
							{
								"type": "hideImage",
								"code": 8,
								"time": 1
							},
							{
								"type": "hideImage",
								"code": 9,
								"time": 100
							}
						]
					},
					{
						"case": "2",
						"action": [
							{
								"type": "playSound",
								"name": "confirm.mp3"
							},
							{
								"type": "setValue",
								"name": "flag:useBattleAnimate",
								"value": "false"
							},
							{
								"type": "setGlobalValue",
								"name": "weakValue",
								"value": 50
							},
							{
								"type": "hideImage",
								"code": 8,
								"time": 1
							},
							{
								"type": "hideImage",
								"code": 9,
								"time": 100
							}
						]
					},
					{
						"case": "default",
						"action": [
							{
								"type": "moveImage",
								"code": 8,
								"to": [
									0,
									0
								],
								"opacity": 1,
								"time": 667
							},
							{
								"type": "while",
								"condition": "flag:startCycle",
								"data": [
									{
										"type": "wait",
										"data": [
											{
												"case": "keyboard",
												"keycode": 13,
												"action": [
													{
														"type": "comment",
														"text": "回车"
													},
													{
														"type": "switch",
														"condition": "flag:startChosen",
														"caseList": [
															{
																"case": "1",
																"action": [
																	{
																		"type": "playSound",
																		"name": "confirm.mp3"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:startCycle",
																		"value": "false"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:useBattleAnimate",
																		"value": "true"
																	},
																	{
																		"type": "setGlobalValue",
																		"name": "weakValue",
																		"value": 0.5
																	}
																]
															},
															{
																"case": "2",
																"action": [
																	{
																		"type": "playSound",
																		"name": "confirm.mp3"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:startCycle",
																		"value": "false"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:useBattleAnimate",
																		"value": "false"
																	},
																	{
																		"type": "setGlobalValue",
																		"name": "weakValue",
																		"value": 50
																	}
																]
															},
															{
																"case": "default",
																"action": [
																	{
																		"type": "showImage",
																		"code": 9,
																		"image": "plotStartCursor1.png",
																		"loc": [
																			0,
																			0
																		],
																		"opacity": 1,
																		"time": 0
																	},
																	{
																		"type": "playSound",
																		"name": "cursor.mp3"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:startChosen",
																		"value": "1"
																	}
																]
															}
														]
													}
												]
											},
											{
												"case": "keyboard",
												"keycode": 32,
												"action": [
													{
														"type": "comment",
														"text": "空格"
													},
													{
														"type": "switch",
														"condition": "flag:startChosen",
														"caseList": [
															{
																"case": "1",
																"action": [
																	{
																		"type": "playSound",
																		"name": "confirm.mp3"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:startCycle",
																		"value": "false"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:useBattleAnimate",
																		"value": "true"
																	},
																	{
																		"type": "setGlobalValue",
																		"name": "weakValue",
																		"value": 0.5
																	}
																]
															},
															{
																"case": "2",
																"action": [
																	{
																		"type": "playSound",
																		"name": "confirm.mp3"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:startCycle",
																		"value": "false"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:useBattleAnimate",
																		"value": "false"
																	},
																	{
																		"type": "setGlobalValue",
																		"name": "weakValue",
																		"value": 50
																	}
																]
															},
															{
																"case": "default",
																"action": [
																	{
																		"type": "showImage",
																		"code": 9,
																		"image": "plotStartCursor1.png",
																		"loc": [
																			0,
																			0
																		],
																		"opacity": 1,
																		"time": 0
																	},
																	{
																		"type": "playSound",
																		"name": "cursor.mp3"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:startChosen",
																		"value": "1"
																	}
																]
															}
														]
													}
												]
											},
											{
												"case": "mouse",
												"px": [
													0,
													208
												],
												"py": [
													0,
													416
												],
												"action": [
													{
														"type": "comment",
														"text": "点击左侧"
													},
													{
														"type": "switch",
														"condition": "flag:startChosen",
														"caseList": [
															{
																"case": "1",
																"action": [
																	{
																		"type": "playSound",
																		"name": "confirm.mp3"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:startCycle",
																		"value": "false"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:useBattleAnimate",
																		"value": "true"
																	},
																	{
																		"type": "setGlobalValue",
																		"name": "weakValue",
																		"value": 0.5
																	}
																]
															},
															{
																"case": "2",
																"action": [
																	{
																		"type": "hideImage",
																		"code": 9,
																		"time": 1
																	},
																	{
																		"type": "showImage",
																		"code": 9,
																		"image": "plotStartCursor1.png",
																		"loc": [
																			0,
																			0
																		],
																		"opacity": 1,
																		"time": 0
																	},
																	{
																		"type": "playSound",
																		"name": "cursor.mp3"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:startChosen",
																		"value": "1"
																	}
																]
															},
															{
																"case": "default",
																"action": [
																	{
																		"type": "showImage",
																		"code": 9,
																		"image": "plotStartCursor1.png",
																		"loc": [
																			0,
																			0
																		],
																		"opacity": 1,
																		"time": 0
																	},
																	{
																		"type": "playSound",
																		"name": "cursor.mp3"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:startChosen",
																		"value": "1"
																	}
																]
															}
														]
													}
												]
											},
											{
												"case": "keyboard",
												"keycode": 39,
												"action": [
													{
														"type": "comment",
														"text": "左右键"
													},
													{
														"type": "switch",
														"condition": "flag:startChosen",
														"caseList": [
															{
																"case": "1",
																"action": [
																	{
																		"type": "hideImage",
																		"code": 9,
																		"time": 1
																	},
																	{
																		"type": "showImage",
																		"code": 9,
																		"image": "plotStartCursor2.png",
																		"loc": [
																			0,
																			0
																		],
																		"opacity": 1,
																		"time": 0
																	},
																	{
																		"type": "playSound",
																		"name": "cursor.mp3"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:startChosen",
																		"value": "2"
																	}
																]
															},
															{
																"case": "default",
																"action": [
																	{
																		"type": "showImage",
																		"code": 9,
																		"image": "plotStartCursor1.png",
																		"loc": [
																			0,
																			0
																		],
																		"opacity": 1,
																		"time": 0
																	},
																	{
																		"type": "playSound",
																		"name": "cursor.mp3"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:startChosen",
																		"value": "1"
																	}
																]
															}
														]
													}
												]
											},
											{
												"case": "keyboard",
												"keycode": 37,
												"action": [
													{
														"type": "comment",
														"text": "左右键"
													},
													{
														"type": "switch",
														"condition": "flag:startChosen",
														"caseList": [
															{
																"case": "1",
																"action": [
																	{
																		"type": "hideImage",
																		"code": 9,
																		"time": 1
																	},
																	{
																		"type": "showImage",
																		"code": 9,
																		"image": "plotStartCursor2.png",
																		"loc": [
																			0,
																			0
																		],
																		"opacity": 1,
																		"time": 0
																	},
																	{
																		"type": "playSound",
																		"name": "cursor.mp3"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:startChosen",
																		"value": "2"
																	}
																]
															},
															{
																"case": "default",
																"action": [
																	{
																		"type": "showImage",
																		"code": 9,
																		"image": "plotStartCursor1.png",
																		"loc": [
																			0,
																			0
																		],
																		"opacity": 1,
																		"time": 0
																	},
																	{
																		"type": "playSound",
																		"name": "cursor.mp3"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:startChosen",
																		"value": "1"
																	}
																]
															}
														]
													}
												]
											},
											{
												"case": "mouse",
												"px": [
													209,
													416
												],
												"py": [
													0,
													416
												],
												"action": [
													{
														"type": "comment",
														"text": "点击右侧"
													},
													{
														"type": "switch",
														"condition": "flag:startChosen",
														"caseList": [
															{
																"case": "2",
																"action": [
																	{
																		"type": "playSound",
																		"name": "confirm.mp3"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:startCycle",
																		"value": "false"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:useBattleAnimate",
																		"value": "false"
																	},
																	{
																		"type": "setGlobalValue",
																		"name": "weakValue",
																		"value": 50
																	}
																]
															},
															{
																"case": "1",
																"action": [
																	{
																		"type": "hideImage",
																		"code": 9,
																		"time": 1
																	},
																	{
																		"type": "showImage",
																		"code": 9,
																		"image": "plotStartCursor2.png",
																		"loc": [
																			0,
																			0
																		],
																		"opacity": 1,
																		"time": 0
																	},
																	{
																		"type": "playSound",
																		"name": "cursor.mp3"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:startChosen",
																		"value": "2"
																	}
																]
															},
															{
																"case": "default",
																"action": [
																	{
																		"type": "showImage",
																		"code": 9,
																		"image": "plotStartCursor2.png",
																		"loc": [
																			0,
																			0
																		],
																		"opacity": 1,
																		"time": 0
																	},
																	{
																		"type": "playSound",
																		"name": "cursor.mp3"
																	},
																	{
																		"type": "setValue",
																		"name": "flag:startChosen",
																		"value": "2"
																	}
																]
															}
														]
													}
												]
											}
										]
									}
								]
							},
							{
								"type": "hideImage",
								"code": 8,
								"time": 1
							},
							{
								"type": "hideImage",
								"code": 9,
								"time": 999
							}
						]
					}
				]
			},
			{
				"type": "showImage",
				"code": 1,
				"image": "plot.png",
				"loc": [
					0,
					0
				],
				"opacity": 1,
				"time": 0
			},
			{
				"type": "setValue",
				"name": "flag:godMode",
				"value": "0"
			},
			{
				"type": "setValue",
				"name": "flag:battleAutoEnds",
				"value": "true"
			},
			{
				"type": "setValue",
				"name": "flag:gameStart",
				"value": "true"
			}
		],
		"shops": [
			{
				"id": "moneyShop3F",
				"name": "贪婪之神",
				"icon": "blueShop",
				"textInList": "3F金币商店",
				"commonTimes": false,
				"mustEnable": true,
				"use": "money",
				"need": "20+1*times",
				"text": "人类啊！如果你愿意给我 ${need} 金币的话，我就可以提升你的战斗力！",
				"choices": [
					{
						"text": "体力 +500",
						"effect": "status:hp+=500"
					},
					{
						"text": "攻击力 +3",
						"effect": "status:atk+=3"
					},
					{
						"text": "防御力 +3",
						"effect": "status:def+=3"
					}
				]
			},
			{
				"id": "moneyShopB5F",
				"name": "贪婪之神",
				"icon": "blueShop",
				"textInList": "B5F金币商店",
				"commonTimes": false,
				"mustEnable": true,
				"use": "money",
				"need": "50+2*times",
				"text": "又是你吗？如果你愿意给我 ${need} 金币的话，我就可以大幅提升你的能力！",
				"choices": [
					{
						"text": "体力 +800",
						"effect": "status:hp+=800"
					},
					{
						"text": "攻击力 +6",
						"effect": "status:atk+=6"
					},
					{
						"text": "防御力 +6",
						"effect": "status:def+=6"
					}
				]
			},
			{
				"id": "expShop7F",
				"name": "战斗之神",
				"icon": "pinkShop",
				"textInList": "7F经验商店",
				"commonTimes": false,
				"mustEnable": true,
				"use": "experience",
				"need": "-1",
				"text": "可怜的勇者啊！我可以将你积累得来的经验化作你的力量！",
				"choices": [
					{
						"text": "等级 +1",
						"need": "70",
						"effect": "status:lv+=1;status:hp+=250;status:atk+=3;status:def+=3"
					},
					{
						"text": "攻击力 +1",
						"need": "20",
						"effect": "status:atk+=1"
					},
					{
						"text": "防御力 +2",
						"need": "20",
						"effect": "status:def+=2"
					}
				]
			},
			{
				"id": "expShopB7F",
				"name": "战斗之神",
				"icon": "pinkShop",
				"textInList": "B7F经验商店",
				"commonTimes": false,
				"mustEnable": true,
				"use": "experience",
				"need": "-1",
				"text": "我们又见面了！这次我可以将你的经验转化为更多力量！",
				"choices": [
					{
						"text": "等级 +3",
						"need": "190",
						"effect": "status:lv+=3;status:hp+=600;status:atk+=10;status:def+=10"
					},
					{
						"text": "攻击力 +3",
						"need": "50",
						"effect": "status:atk+=3"
					},
					{
						"text": "防御力 +5",
						"need": "50",
						"effect": "status:def+=5"
					}
				]
			},
			{
				"id": "keyShop",
				"name": "盗贼",
				"icon": "thief",
				"textInList": "盗贼（出售钥匙）",
				"commonTimes": false,
				"mustEnable": true,
				"use": "money",
				"need": "-1",
				"text": "手上缺钥匙了吗？我这里有大把的！",
				"choices": [
					{
						"text": "黄钥匙",
						"need": "20",
						"effect": "item:yellowKey+=1"
					},
					{
						"text": "蓝钥匙",
						"need": "80",
						"effect": "item:blueKey+=1"
					}
				]
			},
			{
				"id": "keyAcquirer",
				"textInList": "钥匙商人（收购钥匙）",
				"mustEnable": true,
				"commonEvent": "回收钥匙商店"
			},
			{
				"id": "keydoorShop",
				"name": "老人",
				"icon": "man",
				"textInList": "老人（出售任意门）",
				"commonTimes": false,
				"mustEnable": true,
				"use": "money",
				"need": "-1",
				"text": "150 金币就可以补充一次任意门，需要吗？",
				"choices": [
					{
						"text": "补充",
						"need": "150",
						"effect": "item:keydoor+=1"
					}
				]
			}
		],
		"levelUp": [
			{
				"need": "0",
				"title": "",
				"action": [
					{
						"type": "comment",
						"text": "此处是初始等级，只需填写称号"
					}
				]
			}
		]
	},
	"values": {
		"lavaDamage": 50,
		"poisonDamage": 10,
		"weakValue": 50,
		"redJewel": 2,
		"blueJewel": 2,
		"greenJewel": 1,
		"redPotion": 150,
		"bluePotion": 400,
		"yellowPotion": 500,
		"greenPotion": 800,
		"breakArmor": 0.9,
		"counterAttack": 0.1,
		"purify": 3,
		"hatred": 2,
		"moveSpeed": 100,
		"animateSpeed": 200,
		"floorChangeTime": 800
	},
	"flags": {
		"enableFloor": false,
		"enableName": false,
		"enableLv": true,
		"enableHPMax": false,
		"enableMana": false,
		"enableMDef": true,
		"enableMoney": true,
		"enableExperience": true,
		"enableLevelUp": false,
		"levelUpLeftMode": false,
		"enableKeys": true,
		"enablePZF": false,
		"enableDebuff": true,
		"enableSkill": true,
		"flyNearStair": false,
		"flyRecordPosition": false,
		"pickaxeFourDirections": false,
		"bombFourDirections": false,
		"snowFourDirections": false,
		"bigKeyIsBox": false,
		"steelDoorWithoutKey": true,
		"itemFirstText": false,
		"equipment": false,
		"equipboxButton": false,
		"iconInEquipbox": false,
		"enableAddPoint": false,
		"enableNegativeDamage": false,
		"hatredDecrease": true,
		"betweenAttackCeil": false,
		"betweenAttackMax": false,
		"useLoop": true,
		"startUsingCanvas": true,
		"startDirectly": true,
		"statusCanvas": true,
		"statusCanvasRowsOnMobile": 3,
		"displayEnemyDamage": true,
		"displayCritical": true,
		"displayExtraDamage": true,
		"enableGentleClick": true,
		"potionWhileRouting": false,
		"ignoreChangeFloor": true,
		"canGoDeadZone": true,
		"enableMoveDirectly": true,
		"enableDisabledShop": false,
		"disableShopOnDamage": false,
		"blurFg": false,
		"checkConsole": false
	}
}
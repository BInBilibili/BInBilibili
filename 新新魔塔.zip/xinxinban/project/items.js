var items_296f5d02_12fd_4166_a7c1_b5e830c9ee3a = 
{
	"items": {
		"yellowKey": {
			"cls": "keys",
			"name": "黄钥匙"
		},
		"blueKey": {
			"cls": "keys",
			"name": "蓝钥匙"
		},
		"redKey": {
			"cls": "keys",
			"name": "红钥匙"
		},
		"redJewel": {
			"cls": "items",
			"name": "红宝石"
		},
		"blueJewel": {
			"cls": "items",
			"name": "蓝宝石"
		},
		"greenJewel": {
			"cls": "items",
			"name": "绿宝石"
		},
		"yellowJewel": {
			"cls": "items",
			"name": "黄宝石"
		},
		"redPotion": {
			"cls": "items",
			"name": "伤药"
		},
		"bluePotion": {
			"cls": "items",
			"name": "高级伤药"
		},
		"yellowPotion": {
			"cls": "items",
			"name": "黄血瓶"
		},
		"greenPotion": {
			"cls": "items",
			"name": "绿血瓶"
		},
		"sword1": {
			"cls": "items",
			"name": "铁剑",
			"text": "一把很普通的铁剑"
		},
		"sword2": {
			"cls": "items",
			"name": "长剑",
			"text": "一把很普通的银剑"
		},
		"sword3": {
			"cls": "items",
			"name": "宝石剑",
			"text": "一把很普通的骑士剑"
		},
		"sword4": {
			"cls": "items",
			"name": "灵光剑",
			"text": "一把很普通的圣剑"
		},
		"sword5": {
			"cls": "items",
			"name": "勇者之剑",
			"text": "一把很普通的神圣剑"
		},
		"shield1": {
			"cls": "items",
			"name": "铁盾",
			"text": "一个很普通的铁盾"
		},
		"shield2": {
			"cls": "items",
			"name": "光之盾",
			"text": "一个很普通的银盾"
		},
		"shield3": {
			"cls": "items",
			"name": "皮革盾",
			"text": "一个很普通的骑士盾"
		},
		"shield4": {
			"cls": "items",
			"name": "圣光十字盾",
			"text": "一个很普通的圣盾"
		},
		"shield5": {
			"cls": "items",
			"name": "勇者之盾",
			"text": "一个很普通的神圣盾"
		},
		"superPotion": {
			"cls": "items",
			"name": "圣水"
		},
		"moneyPocket": {
			"cls": "items",
			"name": "金块"
		},
		"sword0": {
			"cls": "constants",
			"name": "折断的剑",
			"text": "没有任何作用的剑，相当于脱掉装备。"
		},
		"shield0": {
			"cls": "constants",
			"name": "残破的盾",
			"text": "没有任何作用的盾，相当于脱掉装备。"
		},
		"book": {
			"cls": "constants",
			"name": "魔物法典",
			"text": "可以查看当前楼层所有怪物的属性。"
		},
		"fly": {
			"cls": "constants",
			"name": "风之罗盘",
			"text": "可以随时传送到去过的楼层。（不能传送到魔塔中）"
		},
		"coin": {
			"cls": "constants",
			"name": "幸运金币",
			"text": "持有时打败怪物可得双倍金币"
		},
		"snow": {
			"cls": "constants",
			"name": "冰冻徽章",
			"text": "可以将四周的熔岩变成平地"
		},
		"cross": {
			"cls": "constants",
			"name": "十字架",
			"text": "死亡后以2000生命复活"
		},
		"knife": {
			"cls": "tools",
			"name": "神剑之证",
			"text": "将面前的怪物变为绿色史莱姆。"
		},
		"shoes": {
			"cls": "constants",
			"name": "冰冻徽章",
			"text": "免疫熔岩的伤害"
		},
		"bigKey": {
			"cls": "items",
			"name": "魔法之钥"
		},
		"greenKey": {
			"cls": "tools",
			"name": "宝石锄头",
			"text": "可以打开一扇绿花门。"
		},
		"steelKey": {
			"cls": "tools",
			"name": "铁门钥匙",
			"text": "可以打开一扇铁门"
		},
		"pickaxe": {
			"cls": "tools",
			"name": "锄头",
			"text": "一个盗贼丢失在塔中的锄头。"
		},
		"icePickaxe": {
			"cls": "tools",
			"name": "宝石锄头",
			"text": "可以破坏一扇绿花门。"
		},
		"bomb": {
			"cls": "tools",
			"name": "炸弹",
			"text": "可以炸掉勇士四周的怪物"
		},
		"centerFly": {
			"cls": "tools",
			"name": "中心对称飞行器",
			"text": "可以飞向当前楼层中心对称的位置"
		},
		"upFly": {
			"cls": "tools",
			"name": "上楼器",
			"text": "可以飞往楼上的相同位置"
		},
		"downFly": {
			"cls": "tools",
			"name": "下楼器",
			"text": "可以飞往楼下的相同位置"
		},
		"earthquake": {
			"cls": "tools",
			"name": "地震卷轴",
			"text": "可以破坏当前层的所有墙"
		},
		"poisonWine": {
			"cls": "items",
			"name": "抗毒剂",
			"text": "解除中毒状态。"
		},
		"weakWine": {
			"cls": "items",
			"name": "火酒",
			"text": "解除衰弱状态。"
		},
		"curseWine": {
			"cls": "tools",
			"name": "解咒药水",
			"text": "可以解除诅咒状态"
		},
		"superWine": {
			"cls": "tools",
			"name": "万能药水",
			"text": "可以解除所有不良状态"
		},
		"hammer": {
			"cls": "tools",
			"name": "圣锤",
			"text": "可以炸掉勇士面前的怪物"
		},
		"Lvupfly": {
			"cls": "items",
			"name": "跃进之翼"
		},
		"proof_brave": {
			"cls": "constants",
			"name": "镶有红宝石的章",
			"text": "一个未被鉴定的镶有红宝石的章。"
		},
		"proof_tyrant": {
			"cls": "constants",
			"name": "镶有黑珍珠的章",
			"text": "一个未被鉴定的镶有黑珍珠的章。"
		},
		"proof_sage": {
			"cls": "constants",
			"name": "镶有钻石的章",
			"text": "一个未被鉴定的镶有钻石的章。"
		},
		"magicKey": {
			"cls": "constants",
			"name": "魔法之钥",
			"text": "可以在主塔17F打开前往密室的密道。"
		},
		"keydoor": {
			"cls": "tools",
			"name": "任意门",
			"text": "可以将熔岩或脆弱的墙变为黄门。"
		},
		"magic_amulet": {
			"cls": "constants",
			"name": "魔法护符",
			"text": "在与魔法师系怪物战斗时，削弱怪物的防御力。"
		},
		"agi_fly": {
			"cls": "items",
			"name": "敏捷之翼"
		},
		"lvBoost": {
			"cls": "items",
			"name": "新物品"
		},
		"I341": {
			"cls": "items",
			"name": "新物品"
		},
		"I343": {
			"cls": "items",
			"name": "新物品"
		},
		"I344": {
			"cls": "items",
			"name": "新物品"
		},
		"I345": {
			"cls": "items",
			"name": "新物品"
		},
		"I346": {
			"cls": "constants",
			"name": "新物品"
		},
		"I347": {
			"cls": "items",
			"name": "新物品"
		},
		"I348": {
			"cls": "items",
			"name": "新物品"
		},
		"I349": {
			"cls": "items",
			"name": "新物品"
		}
	},
	"itemEffect": {
		"redJewel": "core.status.hero.atk += core.values.redJewel * ratio",
		"blueJewel": "core.status.hero.def += core.values.blueJewel * ratio",
		"greenJewel": "core.status.hero.agi += +core.values.greenJewel * ratio",
		"yellowJewel": "core.status.hero.hp+=1000;core.status.hero.atk+=6;core.status.hero.def+=6;core.status.hero.mdef+=10;",
		"redPotion": "core.status.hero.hp += core.values.redPotion * ratio",
		"bluePotion": "core.status.hero.hp += core.values.bluePotion * ratio",
		"yellowPotion": "core.status.hero.hp += core.values.yellowPotion * ratio",
		"greenPotion": "core.status.hero.hp += core.values.greenPotion * ratio",
		"sword1": "core.status.hero.atk += core.values.sword1;\ncore.setFlag('atkm',core.getFlag('atkm')+10);",
		"sword2": "core.status.hero.atk += core.values.sword2;\ncore.setFlag('atkm',core.getFlag('atkm')+20);",
		"sword3": "core.status.hero.atk += core.values.sword3;\ncore.setFlag('atkm',core.getFlag('atkm')+30);",
		"sword4": "core.status.hero.atk += core.values.sword4;\ncore.setFlag('atkm',core.getFlag('atkm')+40);",
		"sword5": "core.status.hero.atk += core.values.sword5;\ncore.setFlag('atkm',core.getFlag('atkm')+50);",
		"shield1": "core.status.hero.def += core.values.shield1;\ncore.setFlag('defm',Math.min(core.getFlag('defm'),20));",
		"shield2": "core.status.hero.def += core.values.shield2;\ncore.setFlag('defm',Math.min(core.getFlag('defm'),15));",
		"shield3": "core.status.hero.def += core.values.shield3;\ncore.setFlag('defm',Math.min(core.getFlag('defm'),25));",
		"shield4": "core.status.hero.def += core.values.shield4;\ncore.setFlag('defm',Math.min(core.getFlag('defm'),10));",
		"shield5": "core.status.hero.def += core.values.shield5;\ncore.setFlag('defm',Math.min(core.getFlag('defm'),5));",
		"bigKey": "core.status.hero.items.keys.yellowKey++;core.status.hero.items.keys.blueKey++;core.status.hero.items.keys.redKey++;",
		"superPotion": "core.status.hero.hp *= 2",
		"moneyPocket": "core.status.hero.money += core.values.moneyPocket",
		"Lvupfly": "core.status.hero.lv+=1;core.status.hero.hp+=400;core.status.hero.atk+=5;core.status.hero.def+=5",
		"agi_fly": "core.status.hero.agi += 3",
		"weakWine": "if (core.getFlag('weak', false)) {\n\tcore.setFlag('weak', false);\n\tif (core.values.weakValue < 1) {\n\t\tcore.setBuff(\"atk\", core.getBuff(\"atk\") + core.values.weakValue);\n\t\tcore.setBuff(\"def\", core.getBuff(\"def\") + core.values.weakValue);\n\t} else {\n\t\tcore.status.hero.atk += core.values.weakValue;\n\t\tcore.status.hero.def += core.values.weakValue;\n\t}\n}",
		"poisonWine": "core.setFlag('poison', false);"
	},
	"itemEffectTip": {
		"redJewel": "'，攻击力 +'+core.values.redJewel * ratio",
		"blueJewel": "'，防御力 +'+core.values.blueJewel * ratio",
		"greenJewel": "'，敏捷 +'+core.values.greenJewel * ratio",
		"yellowJewel": "'，全属性提升'",
		"redPotion": "'，体力 +'+core.values.redPotion * ratio",
		"bluePotion": "'，体力 +'+core.values.bluePotion * ratio",
		"yellowPotion": "'，生命+'+core.values.yellowPotion * ratio",
		"greenPotion": "'，生命+'+core.values.greenPotion * ratio",
		"sword1": "'，攻击力 +' + core.values.sword1 + '，攻击临界为 ' + core.getFlag('atkm', null)",
		"sword2": "'，攻击力 +' + core.values.sword2 + '，攻击临界为 ' + core.getFlag('atkm', null)",
		"sword3": "'，攻击力 +'+core.values.sword3+'，攻击临界为 '+core.getFlag('atkm',null)",
		"sword4": "'，攻击力 +' + core.values.sword4 + '，攻击临界为 ' + core.getFlag('atkm', null)",
		"sword5": "'，攻击力 +'+core.values.sword5+'，攻击临界为 '+core.getFlag('atkm',null)",
		"shield1": "'，防御力 +' + core.values.shield1 + '，防御临界为 ' + core.getFlag('defm', null)",
		"shield2": "'，防御力 +'+core.values.shield2+'，防御临界为 '+core.getFlag('defm',null)",
		"shield3": "'，防御力 +' + core.values.shield3 + '，防御临界为 ' + core.getFlag('defm', null)",
		"shield4": "'，防御力 +'+core.values.shield4+'，防御临界为 '+core.getFlag('defm',null)",
		"shield5": "'，防御力+'+core.values.shield5+'，防御临界为 '+core.getFlag('defm',null)",
		"bigKey": "'，三种钥匙各 +1'",
		"superPotion": "'，体力×2'",
		"moneyPocket": "'，金币 +'+core.values.moneyPocket",
		"keydoor": null,
		"agi_fly": "'，敏捷 +3（当前敏捷：' + core.status.hero.agi + '）'",
		"Lvupfly": "'，等级 +1 ( +400 / +5 / +5 )'",
		"poisonWine": "'，中毒状态解除'",
		"weakWine": "'，衰弱状态解除'"
	},
	"useItemEffect": {
		"book": "core.ui.drawBook(0);",
		"fly": "core.ui.drawFly(core.floorIds.indexOf(core.status.floorId));",
		"earthquake": "core.removeBlockByIds(core.status.floorId, core.status.event.data);\ncore.drawMap(core.status.floorId, function () {\n    core.drawHero(core.getHeroLoc('direction'), core.getHeroLoc('x'), core.getHeroLoc('y'), 'stop');\n    core.updateFg();\n    core.drawTip(core.material.items[itemId].name + '使用成功');\n});",
		"pickaxe": "core.removeBlockByIds(core.status.floorId, core.status.event.data);\ncore.drawMap(core.status.floorId, function () {\n    core.drawHero(core.getHeroLoc('direction'), core.getHeroLoc('x'), core.getHeroLoc('y'), 'stop');\n    core.updateFg();\n    core.drawTip(core.material.items[itemId].name + '使用成功');\n});",
		"icePickaxe": "core.setBlock(168, core.nextX(), core.nextY());\ncore.drawMap(core.status.floorId, function () {\n\tcore.drawHero(core.getHeroLoc('direction'), core.getHeroLoc('x'), core.getHeroLoc('y'), 'stop');\n\tcore.updateFg();\n\tcore.drawTip(core.material.items[itemId].name + '使用成功');\n});",
		"snow": "core.removeBlockByIds(core.status.floorId, core.status.event.data);\ncore.drawMap(core.status.floorId, function () {\n    core.drawHero(core.getHeroLoc('direction'), core.getHeroLoc('x'), core.getHeroLoc('y'), 'stop');\n    core.updateFg();\n    core.drawTip(core.material.items[itemId].name + '使用成功');\n});",
		"bigKey": "core.removeBlockByIds(core.status.floorId, core.status.event.data);\ncore.drawMap(core.status.floorId, function () {\n    core.drawHero(core.getHeroLoc('direction'), core.getHeroLoc('x'), core.getHeroLoc('y'), 'stop');\n    core.updateFg();\n    core.drawTip(core.material.items[itemId].name + '使用成功');\n});",
		"bomb": "core.removeBlockByIds(core.status.floorId, core.status.event.data);\ncore.drawMap(core.status.floorId, function () {\n    core.drawHero(core.getHeroLoc('direction'), core.getHeroLoc('x'), core.getHeroLoc('y'), 'stop');\n    core.updateFg();\n    core.drawTip(core.material.items[itemId].name + '使用成功');\n    core.events.afterUseBomb();\n});",
		"hammer": "core.removeBlockByIds(core.status.floorId, core.status.event.data);\ncore.drawMap(core.status.floorId, function () {\n    core.drawHero(core.getHeroLoc('direction'), core.getHeroLoc('x'), core.getHeroLoc('y'), 'stop');\n    core.updateFg();\n    core.drawTip(core.material.items[itemId].name + '使用成功');\n    core.events.afterUseBomb();\n});",
		"centerFly": "core.clearMap('hero', 0, 0, 416, 416);\ncore.setHeroLoc('x', core.status.event.data.x);\ncore.setHeroLoc('y', core.status.event.data.y);\ncore.drawHero(core.getHeroLoc('direction'), core.getHeroLoc('x'), core.getHeroLoc('y'), 'stop');\ncore.drawTip(core.material.items[itemId].name + '使用成功');",
		"upFly": "var loc = {'direction': core.status.hero.loc.direction, 'x': core.status.event.data.x, 'y': core.status.event.data.y};\ncore.changeFloor(core.status.event.data.id, null, loc, null, function (){\n    core.drawTip(core.material.items[itemId].name + '使用成功');\n    core.replay();\n});",
		"downFly": "var loc = {'direction': core.status.hero.loc.direction, 'x': core.status.event.data.x, 'y': core.status.event.data.y};\ncore.changeFloor(core.status.event.data.id, null, loc, null, function (){\n    core.drawTip(core.material.items[itemId].name + '使用成功');\n    core.replay();\n});",
		"poisonWine": "core.setFlag('poison', false);",
		"weakWine": "if (core.getFlag('weak', false)) {\n\tcore.setFlag('weak', false);\n\tif (core.status.weakValue < 1) {\n\t\tcore.setBuff(\"atk\", core.getBuff(\"atk\") + core.values.weakValue);\n\t\tcore.setBuff(\"def\", core.getBuff(\"def\") + core.values.weakValue);\n\t} else {\n\t\tcore.status.hero.atk += core.values.weakValue;\n\t\tcore.status.hero.def += core.values.weakValue;\n\t}\n}",
		"curseWine": "core.setFlag('curse', false);",
		"superWine": "core.setFlag('poison', false);\nif (core.hasFlag('weak')) {\n    core.setFlag('weak', false);\n    core.status.hero.atk += core.values.weakValue;\n    core.status.hero.def += core.values.weakValue;\n}\ncore.setFlag('curse', false);",
		"sword0": "core.plugin.useEquipment(itemId)",
		"sword1": "core.plugin.useEquipment(itemId)",
		"sword2": "core.plugin.useEquipment(itemId)",
		"sword3": "core.plugin.useEquipment(itemId)",
		"sword4": "core.plugin.useEquipment(itemId)",
		"sword5": "core.plugin.useEquipment(itemId)",
		"shield0": "core.plugin.useEquipment(itemId)",
		"shield1": "core.plugin.useEquipment(itemId)",
		"shield2": "core.plugin.useEquipment(itemId)",
		"shield3": "core.plugin.useEquipment(itemId)",
		"shield4": "core.plugin.useEquipment(itemId)",
		"shield5": "core.plugin.useEquipment(itemId)",
		"keydoor": "core.insertAction([{\"type\": \"setBlock\",\"number\":81,\"loc\": [core.nextX(), core.nextY()]}])\n",
		"knife": "core.insertAction([{\"type\": \"setBlock\",\"number\":201,\"loc\": [core.nextX(), core.nextY()]}])",
		"proof_brave": null,
		"proof_sage": null,
		"proof_tyrant": null,
		"I346": "core.insertAction([{ \"type\": \"insert\", \"loc\": [8, 5], \"floorId\": \"MOTA8\" }]);"
	},
	"canUseItemEffect": {
		"book": "true",
		"fly": "(function () {\n\tif (core.status.maps[core.status.floorId].canFlyTo && core.status.maps[core.status.floorId].floorId != \"main10\") {\n\t\treturn true;\n\t}\n\tcore.playSound(\"warning.mp3\");\n\treturn false;\n})();",
		"pickaxe": "var able=false;\n/*var ids = [];\nfor (var i in core.status.thisMap.blocks) {\n    var block = core.status.thisMap.blocks[i];\n    if (core.isset(block.event) && !(core.isset(block.enable) && !block.enable) &&\n        (block.event.id == 'yellowWall' || block.event.id=='whiteWall' || block.event.id=='blueWall')) // 能破哪些墙\n    {\n        // 四个方向\n        if (core.flags.pickaxeFourDirections) {\n            if (Math.abs(block.x-core.status.hero.loc.x)+Math.abs(block.y-core.status.hero.loc.y)<=1) {\n                ids.push(i);\n            }\n        }\n        else {\n            if (block.x == core.nextX() && block.y == core.nextY()) {\n                ids.push(i);\n            }\n        }\n    }\n}\nif (ids.length>0) {\n    core.status.event.data = ids;\n    able=true;\n}\nable//*/",
		"icePickaxe": "var able=false;\nvar nextfID=core.getBlockId(core.nextX(),core.nextY());\nif(nextfID==\"specialDoor\")\n\table=true;\nable",
		"bomb": "var able=false;\nvar ids = [];\nfor (var i in core.status.thisMap.blocks) {\n    var block = core.status.thisMap.blocks[i];\n    if (core.isset(block.event) && !(core.isset(block.enable) && !block.enable) && block.event.cls.indexOf('enemy')==0 && Math.abs(block.x-core.status.hero.loc.x)+Math.abs(block.y-core.status.hero.loc.y)<=1) {\n        var enemy = core.material.enemys[block.event.id];\n        if ((core.isset(enemy.bomb) && !enemy.bomb) || (core.isset(enemy.notBomb) && enemy.notBomb)) continue;\n        if (core.flags.bombFourDirections || (block.x==core.nextX() && block.y==core.nextY()))\n            ids.push(i);\n    }\n}\nif (ids.length>0) {\n    core.status.event.data = ids;\n    able=true;\n}\nable",
		"hammer": "var able=false;\nfor (var i in core.status.thisMap.blocks) {\n    var block = core.status.thisMap.blocks[i];\n    if (core.isset(block.event) && !(core.isset(block.enable) && !block.enable) && block.event.cls.indexOf('enemy')==0 && block.x==core.nextX() && block.y==core.nextY()) {\n        var enemy = core.material.enemys[block.event.id];\n        ((core.isset(enemy.bomb) && !enemy.bomb) || (core.isset(enemy.notBomb) && enemy.notBomb)) continue;\n        core.status.event.data = [i];\n        able=true;\n    }\n}\nable",
		"earthquake": "var able=false;\nvar ids = [];\nfor (var i in core.status.thisMap.blocks) {\n    var block = core.status.thisMap.blocks[i];\n    if (core.isset(block.event) && !(core.isset(block.enable) && !block.enable) && (block.event.id == 'yellowWall' || block.event.id == 'blueWall' || block.event.id == 'whiteWall')) // 能炸的墙壁\n        ids.push(i);\n}\nif (ids.length>0) {\n    core.status.event.data = ids;\n    able=true;\n}\nable",
		"centerFly": "var able=false;\nvar toX = 12 - core.getHeroLoc('x'), toY = 12-core.getHeroLoc('y');\nvar block = core.getBlock(toX, toY);\nif (block==null) {\n    core.status.event.data = {'x': toX, 'y': toY};\n    able = true;\n}\nable",
		"upFly": "var able=false;\nvar floorId = core.status.floorId, index = core.floorIds.indexOf(floorId);\nif (index<core.floorIds.length-1) {\n\tvar toId = core.floorIds[index+1], toX = core.getHeroLoc('x'), toY = core.getHeroLoc('y');\n\tif (core.getBlock(toX, toY, toId)==null) {\n\t\tcore.status.event.data = {'id': toId, 'x': toX, 'y': toY};\n\t\table=true;\n\t}\n}\nable",
		"downFly": "var able=false;\nvar floorId = core.status.floorId, index = core.floorIds.indexOf(floorId);\nif (index>0) {\n\tvar toId = core.floorIds[index-1], toX = core.getHeroLoc('x'), toY = core.getHeroLoc('y');\n\tif (core.getBlock(toX, toY, toId)==null) {\n\t\tcore.status.event.data = {'id': toId, 'x': toX, 'y': toY};\n\t\table=true;\n\t}\n}\nable",
		"snow": "var able=false;\nvar ids = [];\nfor (var i in core.status.thisMap.blocks) {\n    var block = core.status.thisMap.blocks[i];\n    if (core.isset(block.event) && !(core.isset(block.enable) && !block.enable) && block.event.id == 'lava' && Math.abs(block.x-core.status.hero.loc.x)+Math.abs(block.y-core.status.hero.loc.y)<=1) {\n        ids.push(i);\n    }\n}\nif (ids.length>0) {\n    core.status.event.data = ids;\n    able=true;\n}\nable",
		"bigKey": "var able=false;\nvar ids = [];\nfor (var i in core.status.thisMap.blocks) {\n    var block = core.status.thisMap.blocks[i];\n    if (core.isset(block.event) && !(core.isset(block.enable) && !block.enable) && block.event.id == 'yellowDoor') {\n        ids.push(i);\n    }\n}\nif (ids.length>0) {\n    core.status.event.data = ids;\n    able=true;\n}\nable",
		"poisonWine": "core.hasFlag('poison')",
		"weakWine": "core.hasFlag('weak')",
		"curseWine": "core.hasFlag('curse')",
		"superWine": "core.hasFlag('poison') || core.hasFlag('weak') || core.hasFlag('curse')",
		"sword0": "true",
		"sword1": "true",
		"sword2": "true",
		"sword3": "true",
		"sword4": "true",
		"sword5": "true",
		"shield0": "true",
		"shield1": "true",
		"shield2": "true",
		"shield3": "true",
		"shield4": "true",
		"shiled5": "true",
		"keydoor": "var can=false;\nvar next=core.getBlockId(core.nextX(),core.nextY());\nif(next==\"walldoor\"||next==\"walldoor3\"||next==\"lavaNet\") can=true;\ncan",
		"magic_amulet": null,
		"knife": "(core.enemyExists(core.nextX(), core.nextY()) && core.getBlockId(core.nextX(), core.nextY()) != \"greenSlime\" && core.getBlockId(core.nextX(), core.nextY()) != \"silverSlime\" && core.getBlockId(core.nextX(), core.nextY()) != \"goldSlime\") || (core.getBlockId(core.nextX(), core.nextY()) == \"princess\" && core.status.floorId == \"base25\")",
		"proof_sage": null,
		"proof_tyrant": null,
		"proof_brave": null,
		"I346": "true"
	},
	"equipCondition": {},
	"useItemEvent": {}
}